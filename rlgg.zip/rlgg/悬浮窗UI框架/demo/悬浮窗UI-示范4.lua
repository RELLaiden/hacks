--[[
floatingWindowManager
相关函数的使用文档
https://gitee.com/rlyun/rlgg/tree/master/%E6%82%AC%E6%B5%AE%E7%AA%97UI%E6%A1%86%E6%9E%B6


]]--

local function interruptThread(thread)
	if thread then
		pcall(function()
			thread:interrupt()
		end)
	end
end

function A1()
	gg.alert('我是A1的功能')
end

function A2()
	gg.alert('我是A2的功能')
end

function B1()
	while true do
		gg.toast('死循环')
		gg.sleep(1000)
	end
end

function C1()
	gg.alert('我是C1的功能')
end

function C2()
	gg.alert('我是C2的功能')
end

function C3()
	gg.clearResults()
	gg.searchNumber(100)
	gg.alert(string.format('搜索到%s个结果', gg.getResultsCount()))
end

-- 获取线程回调赋值给 onClick 可以避免UI堵塞问题

local function getASyncThreadCallbak(func) -- 异步线程回调
	return function()
		luajava.startThread(function()
			return pcall(func)
		end)
	end
end

-- 应用在101行
local task
local function getSyncThreadCallbak(func) -- 同步线程回调, 涉及gg类库的回调只能使用这种,否则可能不稳定
	return function()
		if task then
			gg.toast('正在运行其它任务,再稍后!')
			return
		end
		luajava.startThread(function()
			task = true
			pcall(func)
			task = nil
		end)
	end
end

local function callSyncThreadCallbak(func)
	return getSyncThreadCallbak(func)()
end

local floatingWindowManager = require('floatingWindowManager')
floatingWindowManager:init()

floatingWindowManager:newWindow(('FWM v%s'):format(floatingWindowManager.version), {
	onCreate = function(floatingWindow)
		floatingWindow:addlayout({
			ScrollView,
			layout_margin = '10dp',
			layout_width = 'match_parent',
			layout_height = 'match_parent',
			{
				LinearLayout,
				background = floatingWindowManager:getStateListDrawable(),
				layout_width = 'match_parent',
				layout_height = 'match_parent',
				orientation = 'vertical',
				padding = '10dp',
				{
					Button,
					background = floatingWindowManager:getStateListDrawable(),
					layout_width = 'match_parent',
					layout_margin = '5dp',
					text = '线程模式搜索测试',
					textSize = '16sp',
					onClick = getSyncThreadCallbak(C3)
				},
				{
					Button,
					background = floatingWindowManager:getStateListDrawable(),
					layout_width = 'match_parent',
					layout_margin = '5dp',
					text = '按钮功能',
					textSize = '16sp',
					onClick = function(View)
						floatingWindowManager:start('按钮功能') -- 打开 按钮功能 的窗口, 前提是 newWindow 创建好了的
					end
				},
				{
					Button,
					background = floatingWindowManager:getStateListDrawable(),
					layout_width = 'match_parent',
					layout_margin = '5dp',
					text = '开关功能',
					textSize = '16sp',
					onClick = function()
						floatingWindowManager:start('开关功能')
					end
				},
				{
					Button,
					background = floatingWindowManager:getStateListDrawable(),
					layout_width = 'match_parent',
					layout_margin = '5dp',
					text = '其它功能',
					textSize = '16sp'
				},
				{
					Button,
					background = floatingWindowManager:getStateListDrawable(),
					layout_width = 'match_parent',
					layout_margin = '5dp',
					text = '多线程功能',
					textSize = '16sp',
					onClick = function()
						floatingWindowManager:start('多线程功能')
					end
				}
			}
		})
	end,
	onDestroy = function()
		-- gg.alert('欢迎下次使用!')
	end
})

floatingWindowManager:newWindow('按钮功能', {
	onCreate = function(floatingWindow)
		floatingWindow:addlayout({
			ScrollView,
			layout_width = 'match_parent',
			layout_height = 'match_parent',
			{
				LinearLayout,
				background = floatingWindowManager:getStateListDrawable(),
				layout_width = 'match_parent',
				layout_height = 'match_parent',
				orientation = 'vertical',
				padding = '10dp',
				{
					Button,
					background = floatingWindowManager:getStateListDrawable(),
					layout_width = 'match_parent',
					layout_margin = '5dp',
					text = '按钮1',
					textSize = '16sp',
					onClick = function()
						callSyncThreadCallbak(A1)
					end
				},
				{
					Button,
					background = floatingWindowManager:getStateListDrawable(),
					layout_width = 'match_parent',
					layout_margin = '5dp',
					text = '按钮2',
					textSize = '16sp',
					onClick = function()
						callSyncThreadCallbak(A2)
					end
				}
			}
		})

	end
})

floatingWindowManager:newWindow('开关功能', {
	onCreate = function(floatingWindow)

		floatingWindow:addlayout({
			ScrollView,
			layout_width = 'match_parent',
			layout_height = 'match_parent',
			{
				LinearLayout,
				background = floatingWindowManager:getStateListDrawable(),
				layout_width = 'match_parent',
				layout_height = 'match_parent',
				orientation = 'vertical',
				padding = '10dp',
				{
					Switch,
					layout_width = 'match_parent',
					text = '开关1',
					onCheckedChange = function(CompoundButton, state)
						if state then
							callSyncThreadCallbak(C1)
						else
							gg.alert('你关闭了C1开关')
						end
					end
				},
				{
					Switch,
					layout_width = 'match_parent',
					text = '开关2',
					onCheckedChange = function(CompoundButton, state)
						if state then
							callSyncThreadCallbak(C2)
						else
							gg.alert('你关闭了C2开关')
						end
					end
				}
			}
		})
	end
})

floatingWindowManager:newWindow('多线程功能', {
	onCreate = function(floatingWindow)
		floatingWindow:addlayout({
			ScrollView,
			layout_width = 'match_parent',
			layout_height = 'match_parent',
			{
				LinearLayout,
				background = floatingWindowManager:getStateListDrawable(),
				layout_width = 'match_parent',
				layout_height = 'match_parent',
				orientation = 'vertical',
				padding = '10dp',
				{
					Switch,
					layout_width = 'match_parent',
					text = '开关1',
					onCheckedChange = function(CompoundButton, state)
						-- 同一个窗口中 cacheName 不可重复，必须是唯一，可以是随机乱写
						local cacheName = '多线程1'
						if state then
							gg.alert('线程开启')
							local thread1 = luajava.startThread(B1)
							floatingWindow:setCache(cacheName, thread1)
						else
							gg.alert('线程关闭')
							local thread1 = floatingWindow:getCache(cacheName)
							interruptThread(thread1)
						end
					end
				}
			}
		})
	end
})

-- 运行悬浮窗
floatingWindowManager:run()
