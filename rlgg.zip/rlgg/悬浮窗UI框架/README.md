## floatingWindowManager



[查看示例](demo)



### init

> 初始化悬浮窗框架（必须）



### newWindow

> 创建窗口

| 参数名       | 类型   | 必填 | 说明         |
| :----------- | ------ | ---- | ------------ |
| name         | string | 是   | 窗口名称     |
| callbackInfo | table  | 是   | 事件回调方法 |



> callbackInfo

| 字段名称  | 类型     | 回调参数       | 说明                             |
| --------- | -------- | -------------- | -------------------------------- |
| onCreate  | function | floatingWindow | 窗口创建完毕后触发该事件         |
| onStart   | function | floatingWindow | 启动窗口后触发该事件             |
| onPause   | function | floatingWindow | 当前窗口启动别的窗口后触发该事件 |
| onResume  | function | floatingWindow | 从别的窗口切换回来触发该事件     |
| onDestroy | function | floatingWindow | 窗口被销毁时触发该事件           |



### start

> 启动窗口

| 参数名 | 类型   | 必填 | 说明     |
| :----- | ------ | ---- | -------- |
| name   | string | 是   | 窗口名称 |



### error

> 抛出异常框架

| 参数名 | 类型   | 必填 | 说明     |
| :----- | ------ | ---- | -------- |
| error  | string | 是   | 错误信息 |



### exit

> 退出悬浮窗



### run

> 运行悬浮窗框架





## floatingWindow

>初始组件(默认自带的)

- 根页面(android.widget.FrameLayout)
  - 状态栏(android.widget.LinearLayout)
    - 功能栏左(android.widget.LinearLayout)
    - 标题栏(android.widget.LinearLayout)
    - 功能栏右(android.widget.LinearLayout)
  - 主页面(android.widget.LinearLayout) **ps: addlayout 就是添加到这个控件**

> 以上控件,可以通过 findViewByName 找到

~~~lua
local mainView = floatingWindow:findViewByName("主页面")
-- ...
~~~





### setTitle

> 设置标题

| 参数名 | 类型   | 必填 | 说明 |
| :----- | ------ | ---- | ---- |
| text   | string | 是   | 标题 |



### addView

> 添加一个View到主页面

| 参数名 | 类型     | 必填 | 说明 |
| :----- | -------- | ---- | ---- |
| view   | userdata | 是   |      |

| 返回值名称 | 类型     |
| ---------- | -------- |
| 控件       | userdata |



### addlayout

> 加载一个lualayout布局并添加到主页面

| 参数名 | 类型  | 必填 | 说明 |
| :----- | ----- | ---- | ---- |
| layou  | table | 是   |      |

| 返回值名称 | 类型     |
| ---------- | -------- |
| 控件       | userdata |





### setCache

> 保存一个数据到缓存,同一个窗口可以通过getCache 获取

| 参数名 | 类型     | 必填 | 说明 |
| :----- | -------- | ---- | ---- |
| 名称   | string   | 是   |      |
| 数据   | LuaValue | 否   |      |



### getCache

> 获取同一个窗口保存的数据

| 参数名 | 类型   | 必填 | 说明 |
| :----- | ------ | ---- | ---- |
| 名称   | string | 是   |      |

| 返回值名称 | 类型     |
| ---------- | -------- |
| cache      | LuaValue |



### match_parnt

> 窗口全屏模式



### wrap_content

> 窗口自适应模式



### newId

> 创建ID

| 参数名 | 类型   | 必填 | 说明 |
| :----- | ------ | ---- | ---- |
| ID名称 | string | 是   |      |

| 返回值名称 | 类型   |
| ---------- | ------ |
| id         | number |



### getId

> 获取ID

| 参数名 | 类型   | 必填 | 说明                        |
| :----- | ------ | ---- | --------------------------- |
| ID名称 | string | 是   | 必须是 newId 创建过的ID名称 |

| 返回值名称 | 类型   |
| ---------- | ------ |
| id         | number |



### findViewByName

> 通过ID名称找对应的View控件

| 参数名 | 类型   | 必填 | 说明                        |
| :----- | ------ | ---- | --------------------------- |
| ID名称 | string | 是   | 必须是 newId 创建过的ID名称 |

| 返回值名称 | 类型     |
| ---------- | -------- |
| 控件       | userdata |



### goneViewByName

> 隐藏某个ID名称的View

| 参数名 | 类型   | 必填 | 说明 |
| :----- | ------ | ---- | ---- |
| ID名称 | string | 是   |      |



### visibleViewByName

> 显示某个ID名称的View

| 参数名 | 类型   | 必填 | 说明 |
| :----- | ------ | ---- | ---- |
| ID名称 | string | 是   |      |



### addViewByName

> 添加View添加到ID名称的容器里

| 参数名 | 类型     | 必填 | 说明           |
| :----- | -------- | ---- | -------------- |
| ID名称 | string   | 是   | 父容器的ID名称 |
| 子控件 | userdata | 是   | 子控件         |



### loadlayoutByView

> 加载lua布局并添加到View容器里

| 参数名 | 类型     | 必填 | 说明         |
| :----- | -------- | ---- | ------------ |
| 父容器 | userdata | 是   | 父容器       |
| layout | table    | 是   | 子控件的布局 |



### loadlayoutByName

> 加载lua布局并添加到ID名称的容器里

| 参数名 | 类型   | 必填 | 说明           |
| :----- | ------ | ---- | -------------- |
| ID名称 | string | 是   | 父容器的ID名称 |
| layout | table  | 是   | 子控件的布局   |





## 常见问题

- 在回调事件开启功能后为什么会卡UI？

  原因是因为回调事件是main线程执行，如果main线程因为耗时任务长久占用，就会出现卡死的情况

  如何解决？

  在回调事件使用多线程执行耗时任务即可

  

  错误示范

  ```lua
  -- 回调事件
  onClick = function()
  	-- 其它代码
  
  	-- 耗时任务
  	gg.searchNumber(0)
  
  	-- 其它代码
  end
  
  ```

  

  正确示范

  ```lua
  -- 回调事件
  onClick = function()
  
  	function func()
  		-- 其它代码
  
  		-- 耗时任务
  		gg.searchNumber(0)
  
  		-- 其它代码
  	end
  
  	-- 使用多线程执行 function
  	luajava.startThread(func)
  end
  
  ```

  

  正确示范

  ```lua
  function AAA1()
  	-- 其它代码
  
  	-- 耗时任务
  	gg.searchNumber(0)
  
  	-- 其它代码
  end
  
  
  -- 回调事件
  onClick = function()
  
  	-- 使用多线程执行 AAA1
  	luajava.startThread(AAA1)
  end
  
  ```

  

  如何理解什么是 `耗时任务`

  执行周期太长的

  比如 `gg.searchNumber` 函数，它的搜索时间非常久

  比如 `gg.sleep` 函数，它的作用是使当前线程睡眠一段时间，那么也是耗时的

  只要能感觉得出来卡顿的，都算耗时任务

  

- 

