



# _ENV

> _ENV是全局环境变量



[以文本方式查看](https://gitee.com/rlyun/rlgg/raw/master/RLGG%E5%87%BD%E6%95%B0%E5%BA%93%E6%96%87%E6%A1%A3.md)

> 保存起来方便搜索



所有参数名为 root 的都表示是否使用 root 权限执行函数,一般是boolean类型



## modules

> 模块需要使用 require 加载,一般首次加载需要联网,所以不建议在UiThread 加载,而是把使用到的模块提前加载好

### [draw3](#draw3)



### [floatingWindowManager](src/windowManager/floatingWindowManager.lua)



### [windowManager](src/windowManager/windowManager.lua)



### [中文模块](%E4%B8%AD%E6%96%87%E6%A8%A1%E5%9D%97/%E4%B8%AD%E6%96%87%E6%A8%A1%E5%9D%97.lua)



### [cglib](#cglib)



### ui

> 制作中



### androidx

> 返回 androidx 的 java.lang.ClassLoader



### 









## 全局函数

#### isNil

> 判断数据类型是否为 nil

| 参数名 | 类型     |
| :----- | -------- |
| data   | LuaValue |

| 返回值名称 | 类型    |
| ---------- | ------- |
| ok         | boolean |
| type       | string  |



#### isBoolean

> 判断数据类型是否为 boolean

| 参数名 | 类型     |
| :----- | -------- |
| data   | LuaValue |

| 返回值名称 | 类型    |
| ---------- | ------- |
| ok         | boolean |
| type       | string  |



#### isNumber

> 判断数据类型是否为 number

| 参数名 | 类型     |
| :----- | -------- |
| data   | LuaValue |

| 返回值名称 | 类型    |
| ---------- | ------- |
| ok         | boolean |
| type       | string  |



#### isString

> 判断数据类型是否为 string

| 参数名 | 类型     |
| :----- | -------- |
| data   | LuaValue |

| 返回值名称 | 类型    |
| ---------- | ------- |
| ok         | boolean |
| type       | string  |



#### isTable

> 判断数据类型是否为 table

| 参数名 | 类型     |
| :----- | -------- |
| data   | LuaValue |

| 返回值名称 | 类型    |
| ---------- | ------- |
| ok         | boolean |
| type       | string  |



#### isFunction

> 判断数据类型是否为 function

| 参数名 | 类型     |
| :----- | -------- |
| data   | LuaValue |

| 返回值名称 | 类型    |
| ---------- | ------- |
| ok         | boolean |
| type       | string  |



#### isUserdata

> 判断数据类型是否为 userdata

| 参数名 | 类型     |
| :----- | -------- |
| data   | LuaValue |

| 返回值名称 | 类型    |
| ---------- | ------- |
| ok         | boolean |
| type       | string  |



#### isThread

> 判断数据类型是否为 thread

| 参数名 | 类型     |
| :----- | -------- |
| data   | LuaValue |

| 返回值名称 | 类型    |
| ---------- | ------- |
| ok         | boolean |
| type       | string  |



#### import

> 导入java类

| 参数名    | 类型   | 说明                      |
| :-------- | ------ | ------------------------- |
| className | string | 支持泛型，例如java.lang.* |

| 返回值名称 | 类型            |
| ---------- | --------------- |
| Class      | java.lang.Class |

> 示例

~~~lua
local File = import('java.io.File')
local sdcard = File('/sdcard/') -- java.io.File
print(sdcard:isFile()) -- false

local java_util = import('java.util.*')
local UUID = java_util.UUID -- java.util.UUID
local uuid = UUID:randomUUID() -- java.util.UUID
uuid = uuid:toString() -- string
print(uuid)
~~~





#### getLoadingBox

> 获取加载框

| 参数名 | 类型   | 必填 | 说明       |
| :----- | ------ | ---- | ---------- |
| text   | string | 是   | 显示的文字 |

| 返回值名称 | 类型  |
| ---------- | ----- |
| LoadingBox | table |

> LoadingBox

| 字段名 | 类型     | 说明       |
| ------ | -------- | ---------- |
| 显示   | function | 显示加载框 |
| 关闭   | function | 关闭加载框 |

> 示例

~~~lua
local loadingBox = getLoadingBox('正在加载中...')
loadingBox['显示']()
gg.sleep(2000)
loadingBox['关闭']()
~~~



#### printf

> 打印格式化内容

| 参数名 | 类型   | 必填 | 说明     |
| :----- | ------ | ---- | -------- |
| format | string | 是   | 占位格式 |
| vararg | ...    | 是   |          |

> 示例

~~~lua
printf('你好,我叫%s', 'rlgg')
~~~



#### newShell

> 创建shell进程

| 参数名 | 类型    | 必填 | 说明                                    |
| :----- | ------- | ---- | --------------------------------------- |
| root   | boolean | 否   | 如果root == true 则使用 su, 否则使用 sh |

| 返回值名称      | 类型  |
| --------------- | ----- |
| [shell](#shell) | table |



#### shell

> 由 newShell 创建



##### read

> 读取结果

| 返回值类型 |
| ---------- |
| string     |



##### write

> 异步写入cmd, 意味着不会立刻获得执行结果

| 参数名 | 类型   | 必填 | 说明      |
| :----- | ------ | ---- | --------- |
| cmd    | string | 是   | shell命令 |



##### cmd

> 同步写入cmd,会等待执行结果,并返回

| 参数名 | 类型   | 必填 | 说明      |
| :----- | ------ | ---- | --------- |
| cmd    | string | 是   | shell命令 |

| 返回值类型 |
| ---------- |
| string     |



##### exec

> 执行cmd

| 参数名 | 类型   | 必填 | 说明     |
| :----- | ------ | ---- | -------- |
| name   | string | 是   | 命令名称 |
| args   | ...    | 否   | 参数     |

| 返回值类型 |
| ---------- |
| string     |



##### execFile

> 使用cmd执行二进制文件

| 参数名 | 类型   | 必填 | 说明               |
| :----- | ------ | ---- | ------------------ |
| path   | string | 是   | 二进制文件绝对路径 |

| 返回值类型 |
| ---------- |
| string     |



##### destroy

> 销毁shell进程



> 示例

~~~lua
local shell = newShell(true)
print('cmd', shell.cmd('echo "hello"'))
print('exec', shell.exec('echo', 'hello'))
print('write', shell.write('sleep 1\necho "我睡了1秒钟"')) -- 睡眠1秒,这里并不会堵塞,因为write是异步写入cmd命令
gg.sleep(1100)
print('read', shell.read()) -- 我睡了1秒钟
print('echo', shell.echo('支持直接从shell获取命令名作为函数去执行')) -- 支持直接从shell获取命令名作为函数去执行
~~~



#### checkPkg

> 验证包名/进程,如果包名已经启动,则自动选择,否则弹出选择启动框

| 参数名  | 类型  | 必填 | 说明     |
| :------ | ----- | ---- | -------- |
| pkgList | table | 是   | 包名列表 |

| 返回值类型 | 说明             |
| ---------- | ---------------- |
| string     | 返回选择后的包名 |

~~~lua
checkPkg({'游戏包名'})
~~~





#### checkSign

> 校验修改器签名MD5

| 参数名   | 类型  | 必填 | 说明    |
| :------- | ----- | ---- | ------- |
| signList | table | 是   | MD5列表 |

| 返回值类型 | 说明                                                         |
| ---------- | ------------------------------------------------------------ |
| boolean    | 只要修改器签名MD5符合参数MD5列表中的任意一个,都为true,否则为false |



#### checkMD5

> 校验修改器MD5

| 参数名  | 类型  | 必填 | 说明    |
| :------ | ----- | ---- | ------- |
| md5List | table | 是   | MD5列表 |

| 返回值类型 | 说明                                                         |
| ---------- | ------------------------------------------------------------ |
| boolean    | 只要修改器MD5符合参数MD5列表中的任意一个,都为true,否则为false |



#### checkXposed

> 如果运行环境安装了xposed则会报错异常

| 参数名 | 类型   | 必填 | 说明         |
| :----- | ------ | ---- | ------------ |
| error  | string | 否   | 报错时的提示 |



#### callAsyncTask

> 执行异步任务

| 参数名 | 类型     | 必填 | 说明             |
| :----- | -------- | ---- | ---------------- |
| func   | function | 是   | 后台线程执行任务 |



#### getAbsTime

> 获取绝对时间戳(从网络获取,非本地)

| 返回值类型 | 说明                              |
| :--------- | --------------------------------- |
| number     | 网络时间戳，和 os.time() 格式一样 |



#### image

> 显示图片

| 参数名     | 类型   | 必填 | 说明                      |
| :--------- | ------ | ---- | ------------------------- |
| src[^src]: | string | 是   |                           |
| _          | _      | 否   | 该参数弃用，直接写nil即可 |
| msg        | string | 否   | 提示信息                  |

> 推荐使用 [gg.image](#ggimage)



#### hashCode

> 获取数据的 hashCode

| 参数名 | 类型     |
| ------ | -------- |
| data   | LuaValue |

| 返回值类型 |
| :--------- |
| number     |



#### setScreenshots

> 禁止录屏

| 参数名 | 类型    |
| ------ | ------- |
| bool   | boolean |

~~~lua
setScreenshots(true)
~~~



#### 	

> 监听声音变化

| 参数名    | 类型     | 说明                                        |
| --------- | -------- | ------------------------------------------- |
| onReceive | function | android.content.BroadcastReceiver#onReceive |

[查看示例](https://gitee.com/rlyun/rlgg/blob/master/src/luajava/监听声音变化隐藏View.lua)



#### setOnExitListener

> 设置脚本结束事件
>
> 旧名 setExitEvent 

| 参数名   | 类型     | 必填 | 说明           |
| :------- | -------- | ---- | -------------- |
| callback | function | 是   | 脚本结束后执行 |
| name     | string   | 否   | 事件名称       |

| 返回值 | 类型     | 说明             |
| ------ | -------- | ---------------- |
| remove | function | 调用后移除该事件 |

~~~lua
setOnExitListener(function()
	gg.alert("脚本结束了")
    -- 执行 关闭/销毁对象 的代码，防止内存泄露
end)
~~~







## 全局字段

| 字段名称 | 类型                    |      |
| -------- | ----------------------- | ---- |
| context  | android.content.Context |      |
|          |                         |      |
|          |                         |      |



---

---

## 多线程说明

启动多线程的方式有以下几种

直接启动

~~~lua
local thread = luajava.startThread(function()
	-- 需要执行的功能
end,'线程名称，线程异常的时候提示的信息','线程参数，支持全部Lua类型')
~~~

获取线程后调用线程的 start 方法启动线程

~~~lua
local thread = luajava.getThread(function()
	-- 需要执行的功能
end)

-- 启动线程，这种方式不支持参数
thread:start()
~~~

打断线程（终止）

调用函数的 interrupt 方法执行即可

~~~lua
local thread = luajava.startThread(function()
	-- 需要执行的功能
end)

-- 打断该线程
thread:interrupt()
~~~

启动的多线程会跟随脚本的结束而终止，自动回收的

包括但不限于，语音函数，杀死GG，等异步处理的函数都是通过多线程实现



多线程意味着不稳定，最好是使用2.0.9或更新版本的RLGG来使用多线程，会稳定一些

所有View的回调函数都是UI线程，是不能执行堵塞操作的，比如搜索内存，请求网络，等，这时候就需要启动多线程去处理





## luajava



---

#### luajava.bindClass

> 获取Class
>
> java.lang.Class#forName(java.lang.String)

| 参数名    | 类型   | 必填 | 说明 |
| :-------- | ------ | ---- | ---- |
| className | string | 是   | 类名 |

| 返回值类型            | 类名            |
| --------------------- | --------------- |
| userdata\|false,error | java.lang.Class |

~~~lua
local Object = luajava.bindClass('java.lang.Object')
local o = Object()
print(o:getClass() == Object) -- true
~~~



#### luajava.newInstance

> 创建对象并且实例化

| 参数名    | 类型   | 必填 | 说明     |
| :-------- | ------ | ---- | -------- |
| className | string | 是   | 类名     |
| vararg    | ...    | 否   | 构造参数 |

| 返回值类型 | 类名             |
| ---------- | ---------------- |
| userdata   | java.lang.Object |

~~~lua
local o = luajava.newInstance('java.lang.Object')
print(o:hashCode())
~~~



#### luajava.new

> 创建对象

| 参数名 | 类型     | 必填 | 说明     |
| :----- | -------- | ---- | -------- |
| class  | userdata | 是   | 类名     |
| vararg | ...      | 否   | 构造参数 |

| 返回值类型 | 类名             |
| ---------- | ---------------- |
| userdata   | java.lang.Object |

~~~lua
local Object = luajava.bindClass('java.lang.Object')
local o = luajava.new(Object)
print(o:getClass() == Object) -- true
~~~



#### luajava.createProxy

> 创建代理

| 参数名         | 类型   | 必填 | 说明     |
| :------------- | ------ | ---- | -------- |
| interfaceName  | string | 是   | 接口类名 |
| proxyMethodMap | table  | 是   | 代理方法 |

| 返回值类型 |
| ---------- |
| userdata   |



#### luajava.createProxyFromClass

> 创建代理
>
> 由于 luajava 内置的 luajava.createProxy 代理对象只能是类名，如果需要代理的类名是外部 dex 的则无法获取该类，或者其它异常，因此提供一种支持以 Class 为代理对象进行代理的方法

| 参数名         | 类型             | 必填 | 说明     |
| :------------- | ---------------- | ---- | -------- |
| interfaceClass | userdata         | 是   | 接口类   |
| proxyMethodMap | table\| function | 是   | 代理方法 |

| 返回值类型 |
| ---------- |
| userdata   |

> 示例参考 luajava.createProxy 只是类名换成获取后的Class即可
>
> 另外 proxyMethodMap 参数支持以 function 进行自动适配需要代理的方法名，前提是接口只有一个方法



#### luajava.astable

> 数组转table

| 参数名 | 类型     | 必填 | 说明                                     |
| :----- | -------- | ---- | ---------------------------------------- |
| list   | userdata | 是   | 需要满足 java.lang.Class#isArray == true |

| 返回值类型 |
| ---------- |
| table      |



#### luajava.getMethods

> 获取对象方法数组

| 参数名    | 类型   | 必填 | 说明 |
| :-------- | ------ | ---- | ---- |
| className | string | 是   | 类名 |

| 返回值类型 |
| ---------- |
| table      |



#### luajava.stringToByte

> 字符串转byte[]

| 参数名 | 类型   | 必填 | 说明   |
| :----- | ------ | ---- | ------ |
| data   | string | 是   | 字符串 |

| 返回值类型 | 类名 |
| ---------- | ---- |
| userdata   | [B   |



#### luajava.newByte

> 创建byte[]

| 参数名 | 类型   | 必填 | 说明 |
| :----- | ------ | ---- | ---- |
| length | number | 是   | 长度 |

| 返回值类型 | 类名 |
| ---------- | ---- |
| userdata   | [B   |



#### luajava.numberToJava

> Lua数值转Java数值

| 参数名 | 类型     | 必填 | 说明                   |
| :----- | -------- | ---- | ---------------------- |
| type   | number   | 是   | 请看下面 type 引用说明 |
| data   | LuaValue | 是   | 需要转换的内容         |

> type

| 参数     | 0    | 1    | 2     | 3    | 4    | 5     | 6      |
| -------- | ---- | ---- | ----- | ---- | ---- | ----- | ------ |
| 转换类型 | byte | char | short | int  | long | float | double |

| 返回值类型 | 说明            |
| ---------- | --------------- |
| number     | 转换后的Lua数值 |



#### luajava.currentThread

> 返回当前线程

| 返回值类型 | 类名             |
| ---------- | ---------------- |
| userdata   | java.lang.Thread |



#### luajava.isMainThread

> 判断当前线程是main线程

| 返回值类型 |
| ---------- |
| boolean    |



#### luajava.isGGThread

> 判断当前线程是修改器运行环境的线程

| 返回值类型 |
| ---------- |
| boolean    |



#### luajava.isThread

> 判断当前线程不是main线程（等于是普通线程）
>
> not luajava.isMainThread

| 返回值类型 |
| ---------- |
| boolean    |



#### luajava.getRunnable

> 创建 Runnable 代理

| 参数名 | 类型     | 必填 | 说明    |
| :----- | -------- | ---- | ------- |
| run    | function | 是   | run方法 |

| 返回值类型 | 类名               |
| ---------- | ------------------ |
| userdata   | java.lang.Runnable |



#### luajava.getThread

> 创建 Thread 线程

| 参数名 | 类型     | 必填 | 说明    |
| :----- | -------- | ---- | ------- |
| run    | function | 是   | run方法 |
| name   | string   | 否   | 线程名  |

| 返回值类型 | 类名             |
| ---------- | ---------------- |
| userdata   | java.lang.Thread |

~~~lua
local th = luajava.getThread(function()
	gg.alert('RLGG')
end)

th:start()

~~~



#### luajava.startThread

> 创建并执行线程

| 参数名 | 类型     | 必填 | 说明                                       |
| :----- | -------- | ---- | ------------------------------------------ |
| run    | function | 是   | run方法                                    |
| name   | string   | 否   | 线程名，当线程异常时可以快速定位           |
| vararg | ...      | 否   | 线程参数，如果存在，必须先写前面的name参数 |

| 返回值类型 | 类名             |
| ---------- | ---------------- |
| userdata   | java.lang.Thread |

~~~lua
local thread = luajava.startThread(function(arg1)
	gg.alert(arg1)

end, '线程名', 'RLGG')
~~~



#### luajava.getLockSupport

> 线程同步锁

| 返回值 | 类型     | 说明                                                         |
| ------ | -------- | ------------------------------------------------------------ |
| park   | function | 执行后当前线程将进入睡眠（堵塞）                             |
| unpark | function | 执行后解除 park 的效果，并且把参数作为 park 的返回值（可无参） |

> 示例

~~~lua
local park, unpark = luajava.getLockSupport()

local function run()
	-- 线程任务

	-- 模拟耗时任务
	gg.sleep(100)

	-- 看看先输出1还是 unpark 的返回值？
	print(1)

	return unpark(1, 2, 3) -- 把返回值传递给 park
end

local thread = luajava.startThread(run)

print(park())
~~~



#### luajava.getHandler

> 单例 android.os.Handler
>
> 伪代码：android.os.Handler(android.os.Looper.getMainLooper())

| 返回值类型 | 类名               |
| ---------- | ------------------ |
| userdata   | android.os.Handler |



#### luajava.postMain

> 同步执行 luajava.getHandler():post(run)
>
> 可以理解为属于UI（主）线程

| 参数名 | 类型     | 必填 | 说明    |
| :----- | -------- | ---- | ------- |
| run    | function | 是   | run方法 |
| vararg | ...      | 否   |         |

| 返回值 | 说明                |
| ------ | ------------------- |
|        | 和 pcall 返回值一样 |



#### luajava.post

> 使用 luajava.postMain 执行，如果没有捕获到异常，返回真实结果，否则抛出异常

| 参数名 | 类型     | 必填 | 说明    |
| :----- | -------- | ---- | ------- |
| run    | function | 是   | run方法 |
| vararg | ...      | 否   |         |

| 返回值   | 说明      |
| -------- | --------- |
| LuaValue | run的返回 |



#### luajava.runOnUiThread

> 异步运行UI线程，其实和 luajava.postMain 一样都是UI线程，luajava.postMain 是同步，支持参数并且捕获异常
>
> 它的 Looper 来此 android.os.Looper.getMainLooper()

| 参数名 | 类型     | 必填 | 说明     |
| :----- | -------- | ---- | -------- |
| run    | function | 是   | 回调方法 |



#### luajava.setmetatable

> 给userdata类型的对象设置元表

| 参数名    | 类型     | 必填 | 说明 |
| :-------- | -------- | ---- | ---- |
| object    | userdata | 是   |      |
| metatable | table    | 是   | 元表 |

| 返回值类型 | 说明                |
| ---------- | ------------------- |
| userdata   | 返回的是 参数object |

> 元表

[Lua 元表(Metatable) | 菜鸟教程](https://www.runoob.com/lua/lua-metatables.html "Lua 元表(Metatable)  在 Lua table 中我们可以访问对应的 key 来得到 value 值，但是却无法对两个 table 进行操作(比如相加)。 因此 Lua 提供了元表(Metatable)，允许我们改变 table 的行为，每个行为关联了对应的元方法。 例如，使用元表我们可以定义 Lua 如何计算两个 table 的相加操作 a+b。 当 Lua 试图对两个表进行相加时，先检查两者之一是否有元表，之后检查是否..")



> 示例

~~~lua
luajava.setmetatable(
	String, 
	{
		__index = string,
	}
)

print(String.gsub) -- 当 String 找不到 gsub 的时候,会去 __index 对应的地方找, 这里是string,所以最终的结果是 string.gsub
~~~



#### luajava.iteratorValues

> 获取迭代器全部值

| 参数名   | 类型               | 必填 |
| :------- | ------------------ | ---- |
| userdata | java.util.Iterator | 是   |

| 返回值名称 | 类型  | 说明 |
| ---------- | ----- | ---- |
| values     | table |      |



#### luajava.iterator

> 遍历迭代器

| 参数名   | 类型               | 必填 |
| :------- | ------------------ | ---- |
| userdata | java.util.Iterator | 是   |

| 返回值名称 | 类型     | 说明                           |
| ---------- | -------- | ------------------------------ |
| next       | function | 每次执行next都会返回下一组数据 |

> next

| 返回值名称 | 类型     | 说明       |
| ---------- | -------- | ---------- |
| index      | number   | 数据的索引 |
| value      | LuaValue | 数据       |



#### luajava.list

> 遍历userdata数据

| 参数名   | 类型           | 必填 |
| :------- | -------------- | ---- |
| userdata | java.util.List | 是   |

| 返回值名称 | 类型     | 说明                           |
| ---------- | -------- | ------------------------------ |
| next       | function | 每次执行next都会返回下一组数据 |

> next

| 返回值名称 | 类型     | 说明       |
| ---------- | -------- | ---------- |
| index      | number   | 数据的索引 |
| value      | LuaValue | 数据       |

> 示例

~~~lua
for i, package in luajava.list(app.pm:getInstalledPackages(0)) do
	print(i, package.packageName)
end
~~~



#### luajava.array

> 遍历userdata数据

| 参数名   | 类型               | 必填 |
| :------- | ------------------ | ---- |
| userdata | java.lang.Object[] | 是   |

| 返回值名称 | 类型     | 说明                           |
| ---------- | -------- | ------------------------------ |
| next       | function | 每次执行next都会返回下一组数据 |

> next

| 返回值名称 | 类型     | 说明       |
| ---------- | -------- | ---------- |
| index      | number   | 数据的索引 |
| value      | LuaValue | 数据       |

> 示例

~~~lua
local File = luajava.bindClass('java.io.File')
local Array = class.getMethods(File)
for i, method in luajava.array(Array) do
	print(i, method:getName())
end
~~~



#### luajava.ipairs

> 遍历userdata数据（结合luajava.array 和 luajava.list）

| 参数名   | 类型                                 | 必填 |
| :------- | ------------------------------------ | ---- |
| userdata | java.util.List \| java.lang.Object[] | 是   |

| 返回值名称 | 类型     | 说明                           |
| ---------- | -------- | ------------------------------ |
| next       | function | 每次执行next都会返回下一组数据 |

> next

| 返回值名称 | 类型     | 说明       |
| ---------- | -------- | ---------- |
| index      | number   | 数据的索引 |
| value      | LuaValue | 数据       |

> 示例

~~~lua
local File = luajava.bindClass('java.io.File')
local Array = class.getMethods(File)
for i, method in luajava.ipairs(Array) do
	print(i, method:getName())
end
~~~



#### luajava.instanceOf

> 判断数据是否为某种类

| 参数名 | 类型     | 必填 | 说明   |
| :----- | -------- | ---- | ------ |
| data   | userdata | 是   |        |
| Class  | userdata | 是   | 目标类 |

| 返回值类型 |
| ---------- |
| boolean    |

> 示例

~~~lua
local f = luajava.newInstance('java.io.File', gg.getFile())
print(luajava.instanceOf(f, luajava.bindClass('java.io.File')))
-- true

local o = luajava.newInstance('java.lang.Object')
print(luajava.instanceOf(o, luajava.bindClass('java.io.File')))
-- false
~~~



#### luajava.download

> 带进度条下载器

| 参数名 | 类型   | 必填 | 说明           |
| :----- | ------ | ---- | -------------- |
| url    | string | 是   | 需要下载的资源 |
| path   | string | 是   | 下载保存路径   |
| msg    | string | 否   | 提示信息       |

| 返回值类型       |
| ---------------- |
| boolean, [error] |

> 示例

~~~lua
local url = 'https://downv6.qq.com/qqweb/QQ_1/android_apk/Android_8.9.71_64.apk'
local path = gg.EXT_STORAGE .. url:match('/[^/]+$')
local msg = '正在下载QQ，请稍后...' .. '\n' .. path
local ok, err = luajava.download(url, path, msg)
if not ok then
	error('下载失败：' .. err)
end
~~~



#### luajava.setInterface

> 设置接口方法（方法参数为接口）

| 参数名     | 类型            | 必填 | 说明             |
| :--------- | --------------- | ---- | ---------------- |
| obj        | userdata        | 是   | java对象         |
| methodName | string          | 是   | 方法名           |
| Override   | function\|table | 是   | 代理后的回调函数 |

> 示例

~~~lua
button = Button(context)
luajava.setInterface(button, 'setOnClickListener', function(view)
	-- 该函数是 android.view.View$OnClickListener#onClick 的代理
end)
~~~

相当于

~~~lua
button = Button(context)
button:setOnClickListener(luajava.createProxy('android.view.View$OnClickListener', {
	onClick = function(view)
		-- 该函数是 android.view.View$OnClickListener#onClick 的代理
	end
}))
~~~



2.0.9版本起，table|function参数可自动实现接口

如果接口有多个方法，则需要table，如果只有唯一方法，则可以直接使用函数

~~~lua
button = Button(context)
button:setOnClickListener(function(view)
	-- 该函数是 android.view.View$OnClickListener#onClick 的代理
end)

button:setOnClickListener({
	onClick = function(view)
		-- 该函数是 android.view.View.OnClickListener.onClick 的代理
	end
})

~~~



#### luajava.callMethod

> 调用java对象方法

| 参数名     | 类型     | 必填 | 说明       |
| :--------- | -------- | ---- | ---------- |
| obj        | userdata | 是   | java对象   |
| methodName | string   | 是   | 方法名     |
| vararg     | ...      | 否   | 传入的参数 |

~~~lua
obj = Object()
print(luajava.callMethod(obj, 'hashCode'))
~~~



#### luajava.callStaticMethod

> 调用java对象静态方法

| 参数名     | 类型     | 必填 | 说明       |
| :--------- | -------- | ---- | ---------- |
| class      | userdata | 是   | java类     |
| methodName | string   | 是   | 方法名     |
| vararg     | ...      | 否   | 传入的参数 |

~~~lua
Math = luajava.bindClass('java.lang.Math')
print(luajava.callStaticMethod(Math, 'random'))
~~~



#### luajava.getObjectField

> 获取对象字段

| 参数名    | 类型     | 必填 | 说明     |
| :-------- | -------- | ---- | -------- |
| obj       | userdata | 是   | java对象 |
| fieldName | string   | 是   | 字段名称 |

| 失败返回值类型 |
| -------------- |
| nil，error     |



#### luajava.getStaticObjectField

> 获取Class静态字段

| 参数名    | 类型     | 必填 | 说明     |
| :-------- | -------- | ---- | -------- |
| obj       | userdata | 是   | java对象 |
| fieldName | string   | 是   | 字段名称 |

~~~lua
Math = luajava.bindClass('java.lang.Math')
print(luajava.getStaticObjectField(Math, 'PI'))
~~~

| 失败返回值类型 |
| -------------- |
| nil，error     |



#### luajava.setObjectField

> 设置对象字段

| 参数名    | 类型     | 必填 | 说明     |
| :-------- | -------- | ---- | -------- |
| obj       | userdata | 是   | java对象 |
| fieldName | string   | 是   | 字段名称 |
| value     | LuaValue | 是   |          |

| 返回值类型 |
| ---------- |
| boolean    |



#### luajava.setStaticObjectField

> 设置Class静态字段

| 参数名    | 类型     | 必填 | 说明     |
| :-------- | -------- | ---- | -------- |
| obj       | userdata | 是   | java对象 |
| fieldName | string   | 是   | 字段名称 |
| value     | LuaValue | 是   |          |

~~~lua

~~~

| 返回值类型 |
| ---------- |
| boolean    |



#### luajava.webView

> 创建 android.webkit.WebView，可执行RLGG函数

| 参数名   | 类型     | 必填 | 说明 |
| :------- | -------- | ---- | ---- |
| onCreate | function | 否   |      |

| 返回值类型             |
| ---------------------- |
| android.webkit.WebView |

onCreate 参数是创建 WebView 后的回调函数，回调参数1是创建好的 WebView，属于UI线程，完成一些初始化工作啥的

主线程结束时，自动销毁webView

[rlgg-js交互示例.lua](https://gitee.com/rlyun/rlgg/blob/master/demo/luajava/rlgg-js交互示例.lua)





---



#### 布局相关

##### luajava.loadlayout

> 加载布局

| 参数名 | 类型     | 必填 | 说明     |
| :----- | -------- | ---- | -------- |
| info   | table    | 是   | 布局信息 |
| env    | table    | 否   | 环境     |
| group  | userdata | 否   | 父容器   |

>布局信息

| 字段名称    | 类型     | 必选 | 说明                                                 |
| ----------- | -------- | ---- | ---------------------------------------------------- |
| 1           | userdata | 是   | 布局的类                                             |
| 2           | table    | 否   | 可被ipairs遍历的索引,除了1,其它都是 子控件的布局信息 |
| 其它key字段 | LuaValue | 否   | 和xml控件作用一样                                    |



| 返回值类型 | 类名                    | 说明               |
| ---------- | ----------------------- | ------------------ |
| userdata   | 根据参数 info[1] 来决定 | 不可以setmetatable |

> 示例

~~~lua
local view = luajava.loadlayout({
	LinearLayout,
	orientation = 'vertical',
	{
		Button,
		text = '我是按钮1',
		onClick = function()
			gg.toast('按钮1被点击了')
		end
	},
	{
		Button,
		id = luajava.newId('我是按钮2'),
		text = '我是按钮2',
	}
})

-- view = android.widget.LinearLayout

local button2 = luajava.getIdView('我是按钮2')
 -- 无论是 getIdView 还是 getIdValue 都支持 SET 指令设置属性, 更推荐 getIdView(请参考 luajava.setmetatable)
button2.onClick = function()
	gg.toast('按钮2被点击了')
end
~~~



##### luajava.newId

> 获取一个从 0x8f000000 开始的id

| 参数名 | 类型   | 必填 |
| :----- | ------ | ---- |
| ID名称 | string | 是   |

| 返回值类型 |
| ---------- |
| number     |



##### luajava.getId

> 获取通过 newId 创建的id

| 参数名 | 类型   | 必填 | 说明                                         |
| :----- | ------ | ---- | -------------------------------------------- |
| ID名称 | string | 是   | 必须是 [luajava.newId][#luajavanewId] 创建的 |

| 返回值类型 |
| ---------- |
| number     |



##### luajava.getIdValue

> 获取id对应的值

| 参数名 | 类型   | 必填 | 说明                                         |
| :----- | ------ | ---- | -------------------------------------------- |
| ID名称 | string | 是   | 必须是 [luajava.newId][#luajavanewId] 创建的 |

| 返回值类型 | 说明                                                         |
| ---------- | ------------------------------------------------------------ |
| table      | 由于刚开始设计的时候, userdata不支持直接元表操作,所以用了table代替 |



##### luajava.getIdView

> 获取id对应的组件

| 参数名 | 类型   | 必填 | 说明                                         |
| :----- | ------ | ---- | -------------------------------------------- |
| ID名称 | string | 是   | 必须是 [luajava.newId][#luajavanewId] 创建的 |

| 返回值类型 | 类名              |
| ---------- | ----------------- |
| userdata   | android.view.View |



##### luajava.getBitmapDrawable

> 加载本地或在线的图像资源,在线资源会缓存到本地

| 参数名 | 类型   | 必填 | 说明                                                   |
| :----- | ------ | ---- | ------------------------------------------------------ |
| path   | string | 是   | 本地或在线的图像资源, 本地需要绝对路径,在线需要url链接 |

| 返回值类型 | 类名                                     |
| ---------- | ---------------------------------------- |
| userdata   | android.graphics.drawable.BitmapDrawable |



##### luajava.getDrawable

> 加载本地或在线的图像资源,在线资源会缓存到本地

| 参数名 | 类型   | 必填 | 说明                                                   |
| :----- | ------ | ---- | ------------------------------------------------------ |
| path   | string | 是   | 本地或在线的图像资源, 本地需要绝对路径,在线需要url链接 |

| 返回值类型 | 类名                               |
| ---------- | ---------------------------------- |
| userdata   | android.graphics.drawable.Drawable |



##### luajava.getBitmap

> 加载本地或在线的图像资源,在线资源会缓存到本地

| 参数名 | 类型   | 必填 | 说明                                                   |
| :----- | ------ | ---- | ------------------------------------------------------ |
| path   | string | 是   | 本地或在线的图像资源, 本地需要绝对路径,在线需要url链接 |

| 返回值类型 | 类名                    |
| ---------- | ----------------------- |
| userdata   | android.graphics.Bitmap |



##### luajava.getResBitmap

> 从app/Res获取Bitmap

| 参数名 | 类型   | 必填 | 说明   |
| :----- | ------ | ---- | ------ |
| id     | number | 是   | 资源ID |

| 返回值类型 | 类名                    |
| ---------- | ----------------------- |
| userdata   | android.graphics.Bitmap |



##### luajava.getResDrawable

> 从app/Res获取Drawable

| 参数名 | 类型   | 必填 | 说明   |
| :----- | ------ | ---- | ------ |
| id     | number | 是   | 资源ID |

| 返回值类型 | 类名                                     |
| ---------- | ---------------------------------------- |
| userdata   | android.graphics.drawable.BitmapDrawable |



##### luajava.getFloatingWindow

> 获取悬浮窗图标的View

| 返回值类型 | 类名                    |
| ---------- | ----------------------- |
| userdata   | android.graphics.Bitmap |



##### luajava.setFloatingWindowAttr

> 设置悬浮窗图标View的属性

| 参数名 | 类型  | 必填 | 说明 |
| :----- | ----- | ---- | ---- |
| attr   | table | 是   |      |



##### luajava.setFloatingWindowHide

> 设置悬浮窗图标的隐藏

| 参数名 | 类型    | 必填 | 说明     |
| :----- | ------- | ---- | -------- |
| isHide | boolean | 是   | 是否隐藏 |



##### luajava.newToast

> 创建 Toast

| 参数名 | 类型   | 必填 | 说明               |
| :----- | ------ | ---- | ------------------ |
| text   | string | 是   |                    |
| length | number | 是   | 显示时间的长短1\|0 |

| 返回值类型 | 类名                 |
| ---------- | -------------------- |
| userdata   | android.widget.Toast |



##### luajava.showToast

> 显示 Toast

| 参数名 | 类型                 | 必填 | 说明 |
| :----- | -------------------- | ---- | ---- |
| Toast  | android.widget.Toast | 是   |      |



##### luajava.toast

> 和 gg.toast 一样，多出返回 Toast

| 参数名 | 类型    | 必填 | 默认  | 说明       |
| :----- | ------- | ---- | ----- | ---------- |
| text   | string  | 是   |       |            |
| fast   | boolean | 否   | false | 快速模式？ |

| 返回值类型 | 类名                 |
| ---------- | -------------------- |
| userdata   | android.widget.Toast |



##### luajava.showViewToast

> 显示View到Toast

| 参数名 | 类型              | 必填 | 说明 |
| :----- | ----------------- | ---- | ---- |
| view   | android.view.View | 是   |      |

| 返回值类型 | 类名                 |
| ---------- | -------------------- |
| userdata   | android.widget.Toast |



##### luajava.layoutToast

> luajava.loadlayout 和 luajava.showViewToast 的结合体

| 参数名 | 类型  | 必填 | 说明 |
| :----- | ----- | ---- | ---- |
| layout | table | 是   |      |

| 返回值类型 | 类名                 |
| ---------- | -------------------- |
| userdata   | android.widget.Toast |



##### luajava.newAlert

> 创建 Alert

| 返回值类型 | 类名                            |
| ---------- | ------------------------------- |
| userdata   | android.app.AlertDialog$Builder |



##### luajava.showAlert

> 显示 Alert

| 参数名 | 类型                    | 必填 | 说明 |
| :----- | ----------------------- | ---- | ---- |
| Alert  | android.app.AlertDialog | 是   |      |



##### luajava.showViewAlert

> 显示 View 到 Alert

| 参数名 | 类型              | 必填 | 说明 |
| :----- | ----------------- | ---- | ---- |
| view   | android.view.View | 是   |      |



##### luajava.layoutAlert

> luajava.loadlayout 和 luajava.showViewAlert 的结合体

| 参数名 | 类型  | 必填 | 说明 |
| :----- | ----- | ---- | ---- |
| layout | table | 是   |      |



##### luajava.getViewPagerMagicIndicator

> 底部导航，分页布局

| 参数名  | 类型  | 必填 | 说明       |
| :------ | ----- | ---- | ---------- |
| layouts | table | 是   | layout列表 |



> layouts

| 接口方法名      | 参数名称 | 参数类型 | 说明         | 返回值类型                         |
| --------------- | -------- | -------- | ------------ | ---------------------------------- |
| getIconDrawable | index    | number   | 返回图标资源 | android.graphics.drawable.Drawable |
| getTitleView    | index    | number   | 返回标题     | string                             |

[查看示例](https://gitee.com/rlyun/rlgg/blob/master/src/luajava/luajava.getViewPagerMagicIndicator.lua)





## gg

[**原生函数**传送门](http://gg.rlyun.top/help/classgg.html "原生函数")



#### gg.setIcon

> 设置GG悬浮窗图标

| 参数名 | 类型           | 必填 | 说明          |
| :----- | -------------- | ---- | ------------- |
| src    | string\|number | 是   | 本地文件或URL |

[查看源码](src/gg/gg.setIcon.lua)



#### gg.getRangesListX

> getRangesListX 是 getRangesList 的升级版

| 参数名    | 类型                | 必填 | 说明 |
| :-------- | ------------------- | ---- | ---- |
| matchInfo | nil\|number\|string | 否   |      |

> matchInfo

| 当 matchInfo 类型等于是 | 处理事件                              |
| ----------------------- | ------------------------------------- |
| nil                     | 返回全部内存列表                      |
| number                  | 返回内存地址范围符合 matchInfo 的列表 |
| table                   | 基于 内存信息 字段筛选                |

#### 内存信息

> 内存信息是table类型

| 字段名       | 类型   | 说明                       |
| ------------ | ------ | -------------------------- |
| internalName | string | 内存的内部名称             |
| name         | string | 内存的名称                 |
| start        | number | 内存的起始地址             |
| end          | number | 内存的结束地址             |
| state        | string | 内存的状态类型{A,Ca,Xa,等} |
| type         | string | 内存的权限类型，读写       |

筛选方式使用的是等于或LUA正则匹配成立

> 示例

~~~lua
-- 返回所有状态类型符合Xa的内存
local matchInfo  = {
    state = 'Xa',
}
local list = gg.getRangesListX(matchInfo)


-- 返回所有 状态类型符合Xa，且名称符合so结尾 的内存
local matchInfo  = {
    state = 'Xa',
    internalName = '.*so$',
}
local list = gg.getRangesListX(matchInfo)


-- 返回1个状态类型等于A
local matchInfo  = {
    state = '^A$', -- 如果直接写 A，那么可能会匹配到 As 
    limit = 1, -- 限制数量为1
}
local list = gg.getRangesListX(matchInfo)

~~~



#### gg.getRangesInfo

> 获取一个[内存信息](#内存信息)

| 参数名    | 类型                | 必填 | 说明 |
| :-------- | ------------------- | ---- | ---- |
| matchInfo | nil\|number\|string | 否   |      |

> 示例

~~~lua
-- 返回1个状态类型等于A的内存信息
local matchInfo  = {
    state = '^A$', -- 如果直接写 A，那么可能会匹配到 As 
}
local RangesInfo = gg.getRangesInfo(matchInfo)
~~~





#### gg.playMusic

> 播放音乐

| 参数名 | 类型   | 必填 | 说明                                                       |
| :----- | ------ | ---- | ---------------------------------------------------------- |
| path   | string | 是   | 本地资源为绝对路径,在线资源为URL链接,如果path=stop则是暂停 |



#### gg.playVideo

> 播放视频

| 参数名 | 类型   | 必填 | 说明                                                       |
| :----- | ------ | ---- | ---------------------------------------------------------- |
| path   | string | 是   | 本地资源为绝对路径,在线资源为URL链接,如果path=stop则是暂停 |



#### gg.command

> 执行命令

[Linux 命令大全]("https://m.runoob.com/linux/linux-command-manual.html")



| 参数名 | 类型   | 必填 | 说明 |
| :----- | ------ | ---- | ---- |
| cmd    | string | 是   | 命令 |

| 返回值类型 |
| ---------- |
| string     |

> 示例

~~~lua
print(gg.command('ls'))
~~~



#### gg.isVPN

> 当前设备是否使用VPN(网络代理)

| 返回值类型 |
| ---------- |
| boolean    |

> 示例

~~~lua
if gg.isVPN() then
	gg.alert('请关闭网络代理!')
	os.exit()
    return
end
~~~



#### gg.getProcess

> 获取正在运行中的进程

| 返回值类型 | 说明                                        |
| ---------- | :------------------------------------------ |
| table      | 从0开始,每个元素包含2个字段cmdLine和process |



#### gg.setProcess

> 设置当前选择进程

| 参数名  | 类型           | 必填 | 说明             |
| :------ | -------------- | ---- | ---------------- |
| cmdline | number, string | 是   | 索引或者进程名称 |



#### gg.getConfig

> 获取修改器的配置

| 参数名 | 类型           | 必填 | 说明           |
| :----- | -------------- | ---- | -------------- |
| id     | number, string | 否   | id或者配置名称 |

| 返回值类型    | 说明                                                       |
| ------------- | ---------------------------------------------------------- |
| table, string | 如果不存在id, 则返回table类型全部配置,否则返回id对应的配置 |



#### gg.setConfig

> 设置修改器的配置

| 参数名 | 类型           | 必填 | 说明           |
| :----- | -------------- | ---- | -------------- |
| id     | number, string | 是   | id或者配置名称 |
| value  | LuaValue       | 是   |                |

> 示例

~~~lua
gg.setConfig("隐藏辅助", 14)
gg.setConfig("运行守护", 3)
gg.setConfig("冻结间隔", 33000)
gg.setConfig("旁路模式", 0)

~~~



#### gg.setProcessX

> 弹出选择进程框



#### gg.exit

> 退出/重启

| 参数名 | 类型   | 必填 | 说明                           |
| :----- | ------ | ---- | ------------------------------ |
| mode   | string | 否   | 如果mode=re则为重启,否则为退出 |



#### gg.arsc

> 读取resources.arsc资源值

| 参数名 | 类型   | 必填 | 说明   |
| :----- | ------ | ---- | ------ |
| id     | number | 是   | 资源id |

| 返回值类型 |
| ---------- |
| string     |



#### gg.killGG

> 杀死其它GG修改器



#### gg.loopKillGG

> 循环杀死其它GG修改器

| 参数名    | 类型   | 必填 | 默认 | 说明                       |
| :-------- | ------ | ---- | ---- | -------------------------- |
| Intervals | number | 否   | 5000 | 间隔多少毫秒执行一次killGG |

~~~lua
-- 加到脚本第一行即可，脚本运行期间就可以杀死其它GG
gg.loopKillGG()
~~~



#### gg.checkVpn

> 验证当前设备是否为网络代理,如果是则报错



#### gg.loopCheckVpn

> 循环执行checkVpn

| 参数名    | 类型   | 必填 | 默认 | 说明                         |
| :-------- | ------ | ---- | ---- | ---------------------------- |
| Intervals | number | 否   | 2000 | 间隔多少毫秒执行一次checkVpn |



#### gg.getClipboard

> 获取剪贴板的内容

| 返回值类型 |
| ---------- |
| string     |



#### gg.getWindowOrientation

> 获取窗口方向

| 返回值类型 | 说明                 |
| ---------- | -------------------- |
| number     | 0 = 竖屏, 其它为横屏 |



#### gg.getScriptDir

> 获取运行工作目录

| 返回值类型 |
| ---------- |
| string     |



#### gg.getSignatures

> 获取GG的签名哈希值

| 返回值类型 |
| ---------- |
| number     |



#### gg.newAlert

> 使用 [luajava.newAlert](#luajavanewAlert) 创建并初始化其属性

| 参数名 | 类型        | 必填 |
| :----- | ----------- | ---- |
| 标题   | string\|nil | 是   |
| 信息   | string      | 是   |

| 返回值类型                      |
| ------------------------------- |
| android.app.AlertDialog$Builder |



#### gg.showAlert

> gg.showAlert 以 [gg.alert](#ggalert) 的方式显示 Alert，和 [luajava.showAlert](#luajavashowAlert) 有区别，后者不会堵塞

| 参数名      | 类型                    | 必填 |
| :---------- | ----------------------- | ---- |
| AlertDialog | android.app.AlertDialog | 是   |
| 按钮        | ...                     | 否   |

| 返回值类型 | 说明                               |
| ---------- | ---------------------------------- |
| number     | 返回值和 [gg.alert](#ggalert) 一样 |



#### gg.htmlAlert

> 以 html 格式显示的 alert

| 参数名   | 类型   | 必填 | 默认 |
| :------- | ------ | ---- | ---- |
| 标题     | html   | 否   |      |
| 信息     | html   | 是   |      |
| 积极按钮 | string | 否   | 确定 |
| 消极按钮 | string | 否   |      |
| 中立按钮 | string | 否   |      |

| 返回值类型 | 说明                                       |
| ---------- | ------------------------------------------ |
| number     | 返回值和 [gg.showAlert](#ggshowAlert) 一样 |



#### gg.alert2

> 自定义标题的alert

| 参数名   | 类型   | 必填 | 默认 |
| :------- | ------ | ---- | ---- |
| 标题     | string | 否   |      |
| 信息     | string | 是   |      |
| 积极按钮 | string | 否   | 确定 |
| 消极按钮 | string | 否   |      |
| 中立按钮 | string | 否   |      |

| 返回值类型 | 说明                                       |
| ---------- | ------------------------------------------ |
| number     | 返回值和 [gg.showAlert](#ggshowAlert) 一样 |



#### gg.diyToast

> 自定义颜色的toast

| 参数名          | 类型   | 必填 | 说明           |
| :-------------- | ------ | ---- | -------------- |
| text            | string | 是   | 显示的文本     |
| textColor       | number | 否   | 文本的颜色数值 |
| backgroundColor | number | 否   | 背景的颜色数值 |



#### gg.colorToast

> 自定义颜色的toast

| 参数名 | 类型   | 必填 | 默认 | 说明                      |
| :----- | ------ | ---- | ---- | ------------------------- |
| html   | string | 是   |      | 显示的文本                |
| length | number | 否   | 0    | 显示时间的长短 0=短，1=长 |



#### gg.image

> 显示图片

| 参数名 | 类型   | 必填 | 说明                        |
| :----- | ------ | ---- | --------------------------- |
| src    | string | 是   | src可以是云资源或者本地文件 |
| msg    | string | 否   | 提示信息                    |



#### gg.searchChoice

> 搜索提示框

| 参数名 | 类型   | 必填 | 说明 |
| :----- | ------ | ---- | ---- |
| items  | table  | 是   |      |
| title  | string | 否   |      |

| 返回值类型 | 说明                         |
| ---------- | ---------------------------- |
| table\|nil | 返回值和 gg.multiChoice 一样 |

~~~lua
gg.searchChoice({'11','22','33'},'标题')
~~~





------



> 以下方法目的只是为了兼容第三方GG函数
>
> 建议直接使用真实的方法，而不是兼容的





#### gg.intent

请参考[app.intent](#appintent)



#### gg.downloadFile

请参考[file.download](#filedownload)



#### gg.jumpAPP

请参考[app.start](#appstart)



#### gg.appPath

请参考[app.getPath](#appgetPath)



#### gg.isHTTPdump

请参考[gg.isVPN](#ggisVPN)



#### gg.goURL

请参考[app.openUrl](#appopenUrl)



#### gg.colorAlert

请参考[gg.htmlAlert](#gghtmlalert)



#### gg.alertX

请参考[gg.htmlAlert](#gghtmlalert)





---

---



## json



### json.decode

> 解析json字符串

| 参数名 | 类型   | 必填 | 说明       |
| :----- | ------ | ---- | ---------- |
| data   | string | 是   | json字符串 |

| 返回值类型 |
| ---------- |
| table      |

解析数组在table里的起始索引为0，遍历的时候需要从0开始

~~~lua
data = '["a","b","c"]'
t = json.decode(data)
print(t)

for i = 0, #t do
	local v = t[i]
	print(v)
end

~~~



### json.encode

> 对json进行编码

| 参数名 | 类型  | 必填 | 说明         |
| :----- | ----- | ---- | ------------ |
| json   | table | 是   | 解析后的json |

| 返回值类型 |
| ---------- |
| string     |

table转json的时候，数组初始索引必须为0

---

---



## base64



### base64.decode

> 解析base64字符串

| 参数名 | 类型   | 必填 | 说明         |
| :----- | ------ | ---- | ------------ |
| data   | string | 是   | base64字符串 |

| 返回值类型 |
| ---------- |
| string     |



### base64.encode

> 对字符串进行base64编码

| 参数名 | 类型   | 必填 | 说明 |
| :----- | ------ | ---- | ---- |
| data   | string | 是   |      |

| 返回值类型 |
| ---------- |
| string     |



---

---



## timers



### timers.setInterval

> 循环定时器

| 参数名    | 类型     | 必填 | 说明                         |
| :-------- | -------- | ---- | ---------------------------- |
| callback  | function | 是   | 任务函数                     |
| Intervals | number   | 是   | 执行任务函数的间隔时间(毫秒) |

| 返回值名称 | 类型   | 说明                                                         |
| ---------- | ------ | ------------------------------------------------------------ |
| id         | number | 可以使用 [timers.clearInterval](###timers.clearInterval) 来关闭该定时器 |



### timers.clearInterval

> 清除循环定时器

| 参数名 | 类型   | 必填 | 说明                                                 |
| :----- | ------ | ---- | ---------------------------------------------------- |
| id     | number | 是   | 由 [timers.setInterval](#timerssetInterval) 创建的id |



### timers.setTimeout

> 单次定时器,触发后销毁

| 参数名    | 类型     | 必填 | 说明                         |
| :-------- | -------- | ---- | ---------------------------- |
| callback  | function | 是   | 任务函数                     |
| Intervals | number   | 是   | 执行任务函数的间隔时间(毫秒) |

| 返回值名称 | 类型   | 说明                                                         |
| ---------- | ------ | ------------------------------------------------------------ |
| id         | number | 可以使用 [timers.clearTimeout](#timersclearTimeout) 来关闭该定时器 |



### timers.clearTimeout

> 清除单次定时器

| 参数名 | 类型   | 必填 | 说明                                               |
| :----- | ------ | ---- | -------------------------------------------------- |
| id     | number | 是   | 由 [timers.setTimeout](#timerssetTimeout) 创建的id |



---

---



## storages



### storages.create

> 创建本地储存

| 参数名 | 类型   | 必填 | 说明                         |
| :----- | ------ | ---- | ---------------------------- |
| name   | string | 是   | 使用名称来区分不同的储存文件 |

| 返回值名称 | 类型  | 说明                     |
| ---------- | ----- | ------------------------ |
| storage    | table | 参考 [storage](#storage) |



### storages.remove

> 删除本地储存

| 参数名 | 类型   | 必填 | 说明                                                         |
| :----- | ------ | ---- | ------------------------------------------------------------ |
| name   | string | 是   | 删除由 [storages.create](#storagescreate) 创建的本地储存文件 |



---

---



### storage

>storage是由storages.create 创建的类库



#### storage.get

> 获取数据

| 参数名 | 类型     | 必填 | 说明                          |
| :----- | -------- | ---- | ----------------------------- |
| key    | LuaValue | 是   | 获取 storage.put 保存后的数据 |

| 返回值类型 |
| ---------- |
| LuaValue   |



#### storage.put

> 保存数据

| 参数名 | 类型     | 必填 | 说明                                                 |
| :----- | -------- | ---- | ---------------------------------------------------- |
| key    | LuaValue | 是   | 数据名称,保存后可以通过 storage.get 可以获取到该数据 |
| value  | LuaValue | 否   | 如果value不存在则表示删除该key的数据                 |



#### storage.save

> 写出储存文件,通常在一级key里面put是自动保存的



#### storage.remove

> 删除数据

| 参数名 | 类型     | 必填 | 说明                      |
| :----- | -------- | ---- | ------------------------- |
| key    | LuaValue | 是   | 删除storage.put保存的数据 |



#### storage.remove

> 删除数据

| 参数名 | 类型     | 必填 | 说明                      |
| :----- | -------- | ---- | ------------------------- |
| key    | LuaValue | 是   | 删除storage.put保存的数据 |



#### storage.contains

> 数据是否存在

| 参数名 | 类型     | 必填 |
| :----- | -------- | ---- |
| key    | LuaValue | 是   |

| 返回值类型 | 说明                    |
| ---------- | ----------------------- |
| boolean    | storage.get(key) ~= nil |



#### storage.clear

> 删除整个配置文件



#### storage.enKey

> 使用加密后,写出本地配置文件的key是经过加密的

| 参数名 | 类型    | 必填 | 说明                           |
| :----- | ------- | ---- | ------------------------------ |
| mode   | boolean | 是   | true=使用加密,false=不使用加密 |

---

---



## assets



### assets.read

> 读取数据

| 参数名   | 类型   | 必填 | 说明         |
| :------- | ------ | ---- | ------------ |
| filename | string | 是   | assets文件名 |

| 返回值类型 | 说明                         |
| ---------- | ---------------------------- |
| string     | 如果不存在 filename 则会报错 |

> 示例

~~~lua
-- 比如在 apk/assets/ 下有个文件叫 rlgg.lua
-- apk/assets/rlgg.lua
-- 那么读取这个文件的方式为
local data = assets.read('rlgg.lua')


-- 比如在 apk/assets/二级目录/ 下有个文件叫 rlgg.lua
-- apk/assets/二级目录/rlgg.lua
-- 那么读取这个文件的方式为
local data = assets.read('/二级目录/rlgg.lua')
~~~



### assets.write

> 读取数据后写出本地

| 参数名   | 类型   | 必填 | 说明                                                      |
| :------- | ------ | ---- | --------------------------------------------------------- |
| filename | string | 是   | assets文件名                                              |
| path     | string | 是   | 写出文件的绝对路径或目录,目录的话绝对路径为 目录/filename |

| 返回值类型 | 说明               |
| ---------- | ------------------ |
| string     | 写出文件的绝对路径 |

~~~lua
-- 把 apk/assets/shell/test.sh 写出到 /sdcard/test.sh
assets.write('/shell/test.sh','/sdcard/')

-- 写出到 /sdcard/1.sh
assets.write('/shell/test.sh','/sdcard/1.sh')
~~~



### assets.toPath

> 读取数据后写出本地

| 参数名   | 类型   | 必填 | 说明         |
| :------- | ------ | ---- | ------------ |
| filename | string | 是   | assets文件名 |

| 返回值类型 | 说明               |
| ---------- | ------------------ |
| string     | 写出文件的绝对路径 |



### assets.exec

> 执行二进制文件

| 参数名   | 类型   | 必填 | 说明         |
| :------- | ------ | ---- | ------------ |
| filename | string | 是   | assets文件名 |

| 返回值类型 | 说明                                               |
| ---------- | -------------------------------------------------- |
| string     | shell.execFile shell 类库来此[newShell](#newshell) |

> 使用 root 权限执行可执行文件

~~~lua
assets.exec('/shell/test.sh')
~~~



### assets.lua

> 执行lua文件

| 参数名   | 类型   | 必填 | 说明         |
| :------- | ------ | ---- | ------------ |
| filename | string | 是   | assets文件名 |
| vararg   | ...    | 否   | 传入参数     |

| 返回值类型 | 说明     |
| ---------- | -------- |
| LuaValue   | 执行结果 |

> 可以把离线的脚本内置到 apk/assets/ 然后使用 assets.lua 执行

~~~lua
assets.lua('内置lua脚本')
~~~





---

---



## coroutine

[Lua 协同程序(coroutine) | 菜鸟教程](https://www.runoob.com/lua/lua-coroutine.html)



## string

> string类库继承了 java.lang.String

[Lua 字符串 | 菜鸟教程](https://www.runoob.com/lua/lua-strings.html)



### 数字签名



#### string.md

> 信息摘要

| 参数名    | 类型   | 必填 | 说明       |
| :-------- | ------ | ---- | ---------- |
| data      | string | 是   | 签名的数据 |
| algorithm | string | 是   | 算法       |

| 返回值类型 | 大小写 | 说明     |
| ---------- | ------ | -------- |
| string     | 大     | 数字签名 |



#### string.md5

> md5签名

| 参数名 | 类型   | 必填 | 说明       |
| :----- | ------ | ---- | ---------- |
| data   | string | 是   | 签名的数据 |

| 返回值类型 | 大小写 | 长度 | 原理                   |
| ---------- | ------ | ---- | ---------------------- |
| string     | 大     | 32   | string.md(data, 'md5') |

> 示例

~~~lua
string.md5('rlgg') --> E95E84AA6CFC78268301FB36CF389446
~~~



#### string.md5l

> md5签名-小写

| 参数名 | 类型   | 必填 | 说明       |
| :----- | ------ | ---- | ---------- |
| data   | string | 是   | 签名的数据 |

| 返回值类型 | 大小写 | 长度 | 原理                     |
| ---------- | ------ | ---- | ------------------------ |
| string     | 小     | 32   | string.md5(data):lower() |

> 示例

~~~lua
string.md5l('rlgg') --> e95e84aa6cfc78268301fb36cf389446
~~~

 

#### string.sha1

> sha1签名

| 参数名 | 类型   | 必填 | 说明       |
| :----- | ------ | ---- | ---------- |
| data   | string | 是   | 签名的数据 |

| 返回值类型 | 大小写 | 长度 | 原理                    |
| ---------- | ------ | ---- | ----------------------- |
| string     | 大     | 40   | string.md(data, 'sha1') |

> 示例

~~~lua
string.sha1('rlgg') --> 24F3202052781064A25E5F8BCC00C748BBE4B1B2
~~~



#### string.sha256

> sha256签名

| 参数名 | 类型   | 必填 | 说明       |
| :----- | ------ | ---- | ---------- |
| data   | string | 是   | 签名的数据 |

| 返回值类型 | 大小写 | 长度 | 原理                      |
| ---------- | ------ | ---- | ------------------------- |
| string     | 大     | 64   | string.md(data, 'sha256') |

> 示例

~~~lua
string.sha1('rlgg') --> 23D4561B95B6D58D1ACC1919F5CFCB780FBED3E8ED0973D7A0BDE22DEE4BCEC0
~~~



### 编码/解码



#### string.zip

> 字符串压缩

| 参数名 | 类型   | 必填 |
| :----- | ------ | ---- |
| data   | string | 是   |

| 返回值类型 |
| ---------- |
| string     |



#### string.unzip

> 字符串解压

| 参数名 | 类型   | 必填 | 说明                                             |
| :----- | ------ | ---- | ------------------------------------------------ |
| data   | string | 是   | 解压由 [string.zip](####string.zip) 压缩的字符串 |

| 返回值类型 |
| ---------- |
| string     |



#### string.bin2hex

> 字符串转十六进制

| 参数名 | 类型   | 必填 | 说明 |
| :----- | ------ | ---- | ---- |
| data   | string | 是   |      |

| 返回值类型 | 大小写 |
| ---------- | ------ |
| string     | 大     |

>示例

~~~lua
string.bin2hex('rlgg') --> 726C6767
~~~



#### string.hex2bin

> 十六进制转明文

| 参数名 | 类型   | 必填 | 说明 |
| :----- | ------ | ---- | ---- |
| data   | string | 是   |      |

| 返回值类型 |
| ---------- |
| string     |



#### string.xor

> 异或加密

| 参数名 | 类型   | 必填 | 说明                                       |
| :----- | ------ | ---- | ------------------------------------------ |
| data   | string | 是   | 如果data是xor加密过的,那么再次加密就是解密 |
| key    | string | 是   | 密钥                                       |

| 返回值类型 |
| ---------- |
| string     |



#### string.rc4

> rc4加密

| 参数名 | 类型   | 必填 | 说明                                       |
| :----- | ------ | ---- | ------------------------------------------ |
| data   | string | 是   | 如果data是rc4加密过的,那么再次加密就是解密 |
| key    | string | 是   | 密钥                                       |

| 返回值类型 |
| ---------- |
| string     |



#### string.base64

> base64编码

| 参数名 | 类型   | 必填 | 默认 |
| :----- | ------ | ---- | ---- |
| mode   | string | 否   | en   |

| 返回值类型 |                                                              |
| ---------- | ------------------------------------------------------------ |
| string     | 如果 mode == 'de' 则 调用 [base64.decode](#base64decode) 否则 调用 [base64.encode](#base64encode) |



#### string.enUrl

> 编码URL

| 参数名     | 类型   | 必填 |
| :--------- | ------ | ---- |
| [url][URL] | string | 是   |

| 返回值类型 |
| ---------- |
| string     |



#### string.deUrl

> 解码URL

| 参数名     | 类型   | 必填 | 说明        |
| :--------- | ------ | ---- | ----------- |
| [url][URL] | string | 是   | 编码后的URL |

| 返回值类型 |
| ---------- |
| string     |



#### string.url

> URL编码或解码

| 参数名     | 类型   | 必填 | 默认 | 说明                                |
| :--------- | ------ | ---- | ---- | ----------------------------------- |
| [url][URL] | string | 是   |      | 编码后的URL                         |
| mode       | string | 否   | en   | 如果 mode == 'de' 则 解码 否则 编码 |

| 返回值类型 |
| ---------- |
| string     |



#### string.urlCode

> 和url一样,目的兼容其它GG

| 返回值类型 |
| ---------- |
| string     |



#### string.chars

> table转字符串

| 参数名 | 类型  | 必填 | 说明                                |
| :----- | ----- | ---- | ----------------------------------- |
| bytes  | table | 是   | 请参考 [string.bytes](#stringbytes) |

| 返回值类型 | 原理                             |
| ---------- | -------------------------------- |
| string     | string.char(table.unpack(bytes)) |



#### string.bytes

> 字符串转table

| 参数名 | 类型   | 必填 |
| :----- | ------ | ---- |
| data   | string | 是   |

| 返回值类型 | 原理                       |
| ---------- | -------------------------- |
| table      | {string.byte(data, 1, -1)} |



#### string.toHex

> 转十六进制 \\x.. 

| 参数名 | 类型   | 必填 |
| :----- | ------ | ---- |
| data   | string | 是   |

| 返回值类型 |
| ---------- |
| string     |

> 示例

~~~lua
string.toHex('rlgg') --> \x72\x6C\x67\x67
~~~



------





### string.startsWith

> 匹配文本头

| 参数名 | 类型   | 必填 |
| :----- | ------ | ---- |
| data   | string | 是   |
| prefix | string | 是   |

| 返回值类型 |
| ---------- |
| boolean    |

> 示例

~~~lua
local url = 'http://127.0.0.1'
if not string.startsWith(url, 'http') then
	return false, 'url不合法'
end

~~~



### string.endsWith

> 匹配文本尾

| 参数名 | 类型   | 必填 |
| :----- | ------ | ---- |
| data   | string | 是   |
| prefix | string | 是   |

| 返回值类型 |
| ---------- |
| boolean    |

> 示例

~~~lua
local path = '/sdcard/rlgg.lua'
if not string.endsWith(path, 'lua') then
	return false, '你输入的不是lua文件'
end

~~~



### string.split

> 分割字符串

| 参数名 | 类型   | 必填 |
| :----- | ------ | ---- |
| data   | string | 是   |
| regex  | string | 是   |
| limit  | number | 否   |

| 返回值类型 |
| ---------- |
| table      |

> 示例

~~~lua
string.split('a,b,c,d,e,f,g', ',')
--[[ result
{
	[1] = 'a',
	[2] = 'b',
	[3] = 'c',
	[4] = 'd',
	[5] = 'e',
	[6] = 'f',
	[7] = 'g',
}
]]
~~~



### string.replace

> 替换字符串

| 参数名      | 类型   | 必填 |
| :---------- | ------ | ---- |
| data        | string | 是   |
| target      | string | 是   |
| replacement | string | 是   |

| 返回值类型 |
| ---------- |
| string     |

> 示例

~~~lua
string.replace('我是xxxx','xxxx','rlgg') --> 我是rlgg
~~~



### string.replaceAll

> Java正则替换字符串

| 参数名      | 类型   | 必填 |
| :---------- | ------ | ---- |
| data        | string | 是   |
| target      | string | 是   |
| replacement | string | 是   |

| 返回值类型 |
| ---------- |
| string     |

> 示例

~~~lua
string.replaceAll('我是xxxx','x+','rlgg') --> 我是rlgg
~~~



### string.trim

> 删除首尾空格

| 参数名 | 类型   | 必填 |
| :----- | ------ | ---- |
| data   | string | 是   |

| 返回值类型 |
| ---------- |
| string     |



### string.ltrim

> 删除左边空格

| 参数名 | 类型   | 必填 |
| :----- | ------ | ---- |
| data   | string | 是   |

| 返回值类型 |
| ---------- |
| string     |



### string.rtrim

> 删除右边空格

| 参数名 | 类型   | 必填 |
| :----- | ------ | ---- |
| data   | string | 是   |

| 返回值类型 |
| ---------- |
| string     |



### string.append

> 字符串附加

| 参数名 | 类型   | 必填 |
| :----- | ------ | ---- |
| data   | string | 是   |
| args   | ...    | 是   |

| 返回值类型 |
| ---------- |
| string     |



### string.random

> 随机字符串

| 参数名 | 类型   | 必填 | 默认 | 说明         |
| :----- | ------ | ---- | ---- | ------------ |
| len    | number | 否   | 1    | 字符串长度   |
| min    | number | 否   | 0    | 最小char范围 |
| max    | number | 否   | 255  | 最的char范围 |

| 返回值类型 |
| ---------- |
| string     |



### string.randomUUID

> 随机UUID

| 参数名 | 类型    | 必填 | 说明                      |
| :----- | ------- | ---- | ------------------------- |
| mode   | boolean | 否   | 如果mode==true则替换-为空 |

| 返回值类型 |
| ---------- |
| string     |



### string.UID

> 随机UUID

| 返回值类型 | 原理                    |
| ---------- | ----------------------- |
| string     | string.randomUUID(true) |



### string.tonumber

> 字符串转数值

| 参数名  | 类型   | 必填 | 说明                     |
| :------ | ------ | ---- | ------------------------ |
| data    | string | 是   |                          |
| default |        | 否   | 如果转换失败,返回default |

| 返回值类型        |
| ----------------- |
| number \| default |



### string.randomMD5

> 随机MD5

| 返回值类型 |
| ---------- |
| string     |



### string.equal

> 可以缩写eq, 判断两个字符串是否相等,无视大小写

| 参数名 | 类型   | 必填 |
| :----- | ------ | ---- |
| self   | string | 是   |
| target | string | 是   |

| 返回值类型 |
| ---------- |
| boolean    |



### string.toMusic

> 字符串转语音

| 参数名 | 类型    | 必填 | 说明                     |
| :----- | ------- | ---- | ------------------------ |
| text   | string  | 是   | 语音文本                 |
| sync   | boolean | 否   | 是否同步播放（默认异步） |

~~~lua
string.toMusic("欢迎使用RLGG", true)
~~~





### string.subsum

> 计算子串有多少个

| 参数名 | 类型   | 必填 | 说明 |
| :----- | ------ | ---- | ---- |
| data   | string | 是   | 主串 |
| sub    | string | 是   | 子串 |

| 返回值类型 |
| ---------- |
| number     |



### string.hashCode

> 获取字符串 hashCode

| 参数名 | 类型   |
| :----- | ------ |
| data   | string |

| 返回值类型 |
| ---------- |
| number     |



### string.crc32

> 获取字符串 crc32

| 参数名 | 类型   |
| :----- | ------ |
| data   | string |

| 返回值类型 |
| ---------- |
| number     |





## http

>什么是 HTTP ？
>超文本传输协议（HTTP）的设计目的是保证客户端与服务器之间的通信。
>
>HTTP 的工作方式是客户端与服务器之间的请求-应答协议。
>
>web 浏览器可能是客户端，而计算机上的网络应用程序也可能作为服务器端。
>
>举例：客户端（浏览器）向服务器提交 HTTP 请求；服务器向客户端返回响应。响应包含关于请求的状态信息以及可能被请求的内容。





> callback

| 变量名   | 类型     | 说明                                                         |
| -------- | -------- | ------------------------------------------------------------ |
| callback | function | 如果 存在该数据 则 使用线程异步请求,请求完成后把结果作为第一个参数传递到callback |



### http.arg2data

> 参数转提交数据

| 参数名 | 类型  |
| :----- | ----- |
| arg    | table |

| 返回值类型 |
| ---------- |
| string     |

> 示例

~~~lua
http.arg2data({a=1,b=2})-- a=1&b=2
~~~



### http.get

> 提交get请求

| 参数名     | 类型     | 必填 | 说明     |
| :--------- | -------- | ---- | -------- |
| [url][URL] | string   | 是   |          |
| headers    | table    | 否   | 请求头   |
| callback   | function | 否   | 异步回调 |

| 返回值类型              | 说明                                         |
| ----------------------- | -------------------------------------------- |
| table\|java.lang.Thread | 如果存在 callback 参数, 则返回异步请求的线程 |

> 示例

~~~lua
for i = 1, 100 do
	local function callback(result)
		if not result then
			return
		end
		printf('第%s次请求结果为%s', i, result.code)
	end

	local asynThread = http.get('https://www.baidu.com/', nil, callback)
	asynThread:join(10) -- 等待10毫秒
end

gg.sleep(100)
~~~



### http.post

> 提交post请求

| 参数名     | 类型          | 必填 | 说明       |
| :--------- | ------------- | ---- | ---------- |
| [url][URL] | string        | 是   |            |
| headers    | table         | 否   | 请求头     |
| data       | string\|table | 否   | 提交的数据 |
| callback   | function      | 否   | 异步回调   |

| 返回值类型              | 说明                                         |
| ----------------------- | -------------------------------------------- |
| table\|java.lang.Thread | 如果存在 callback 参数, 则返回异步请求的线程 |



### http.put

> 上传指定的 URI 表示

| 参数名     | 类型     | 必填 | 说明       |
| :--------- | -------- | ---- | ---------- |
| [url][URL] | string   | 是   |            |
| headers    | table    | 否   | 请求头     |
| data       | string   | 否   | 提交的数据 |
| callback   | function | 否   | 异步回调   |

| 返回值类型              | 说明                                         |
| ----------------------- | -------------------------------------------- |
| table\|java.lang.Thread | 如果存在 callback 参数, 则返回异步请求的线程 |



### http.patch

> 使用 PATCH 方法提交请求

| 参数名     | 类型     | 必填 | 说明       |
| :--------- | -------- | ---- | ---------- |
| [url][URL] | string   | 是   |            |
| headers    | table    | 否   | 请求头     |
| data       | string   | 否   | 提交的数据 |
| callback   | function | 否   | 异步回调   |

| 返回值类型              | 说明                                         |
| ----------------------- | -------------------------------------------- |
| table\|java.lang.Thread | 如果存在 callback 参数, 则返回异步请求的线程 |



### http.delete

>  删除指定资源

| 参数名     | 类型     | 必填 | 说明       |
| :--------- | -------- | ---- | ---------- |
| [url][URL] | string   | 是   |            |
| headers    | table    | 否   | 请求头     |
| data       | string   | 否   | 提交的数据 |
| callback   | function | 否   | 异步回调   |

| 返回值类型              |
| ----------------------- |
| table\|java.lang.Thread |



### http.download

> 下载文件

| 参数名     | 类型     | 必填 | 说明         |
| :--------- | -------- | ---- | ------------ |
| [url][URL] | string   | 是   |              |
| headers    | table    | 否   | 请求头       |
| path       | string   | 是   | 文件保存路径 |
| callback   | function | 否   | 异步回调     |

| 返回值类型              | 说明                                         |
| ----------------------- | -------------------------------------------- |
| table\|java.lang.Thread | 如果存在 callback 参数, 则返回异步请求的线程 |



### http.upload

> 上传文件

| 参数名     | 类型     | 必填 | 说明         |
| :--------- | -------- | ---- | ------------ |
| [url][URL] | string   | 是   |              |
| headers    | table    | 否   | 请求头       |
| path       | string   | 是   | 本地文件路径 |
| callback   | function | 否   | 异步回调     |

| 返回值类型              | 说明                                         |
| ----------------------- | -------------------------------------------- |
| table\|java.lang.Thread | 如果存在 callback 参数, 则返回异步请求的线程 |



[URL]: https://www.runoob.com/html/html-url.html	"HTML  统一资源定位器(Uniform Resource Locators)   URL 是一个网页地址。 URL可以由字母组成，如“gg.rlyun.top”，或互联网协议（IP）地址： 114.114.114.114。大多数人进入网站使用网站域名来访问，因为 名字比数字更容易记住。"



## file

> file类库支持所有java.io.File的方法



### file.new

> 创建文件对象

| 返回值类型 | 类名         |
| ---------- | ------------ |
| userdata   | java.io.File |



### file.getCacheName

> 获取缓存文件路径，文件夹为 android.content.ContextWrapper#getCacheDir 的结果

| 参数名 | 类型   | 必填 | 说明                       |
| :----- | ------ | ---- | -------------------------- |
| name   | string | 是   | 根据name的哈希值生成文件名 |

| 返回值类型 | 说明     |
| ---------- | -------- |
| string     | 绝对路劲 |



### file.checkFile

> 验证文件是否可读写，如果不存在则尝试创建
>
> 通常 download 函数都会先调用该函数进行校验保存文件

| 参数名   | 类型   | 必填 | 说明         |
| :------- | ------ | ---- | ------------ |
| filename | string | 是   | 文件绝对路径 |

| 返回值类型      | 说明 |
| --------------- | ---- |
| boolean,[error] |      |



### file.checkDir

> 验证目录是否可读写，如果不存在则尝试创建

| 参数名 | 类型   | 必填 | 说明         |
| :----- | ------ | ---- | ------------ |
| dir    | string | 是   | 目录绝对路径 |

| 返回值类型      | 说明 |
| --------------- | ---- |
| boolean,[error] |      |



### file.checkUrl

> 下载URL资源到本地缓存

| 参数名 | 类型   | 必填 | 说明                                                    |
| :----- | ------ | ---- | ------------------------------------------------------- |
| url    | string | 是   | 如果url存在缓存,则返回缓存文件,否则下载到缓存文件再返回 |

| 返回值类型           | 说明             |
| -------------------- | ---------------- |
| string \| false, err | 缓存后的绝对路劲 |



### file.download

> 下载文件

| 参数名 | 类型   | 必填 |
| :----- | ------ | ---- |
| url    | string | 是   |
| path   | string | 是   |

| 返回值类型       |
| ---------------- |
| boolean, [error] |



### file.getdir

> 获取目录

| 参数名 | 类型   | 必填 |
| :----- | ------ | ---- |
| path   | string | 是   |

| 返回值类型 |
| ---------- |
| string     |



### file.getdirs

> 获取目录,如果不存在则创建

| 参数名 | 类型   | 必填 |
| :----- | ------ | ---- |
| url    | string | 是   |
| path   | string | 是   |

| 返回值类型 | 说明  |
| ---------- | ----- |
| string     | /结尾 |



### file.type

> 路径指向的类型

| 参数名 | 类型   | 必填 |
| :----- | ------ | ---- |
| path   | string | 是   |

| 返回值 | 类型   | 说明         |
| ------ | ------ | ------------ |
| 目录   | string | 为目录时返回 |
| 文件   | string | 为文件时返回 |
| nil    | nil    | 不存在时返回 |



### file.isDir

> 路劲指向的类型是否为目录

| 参数名 | 类型   | 必填 |
| :----- | ------ | ---- |
| path   | string | 是   |

| 返回值类型 | 原理             |
| ---------- | ---------------- |
| boolean    | file.isDirectory |



### file.list

> 获取子文件数组

| 参数名 | 类型   | 必填 |
| :----- | ------ | ---- |
| path   | string | 是   |

| 返回值类型 | 类名          | 原理           |
| ---------- | ------------- | -------------- |
| userdata   | [java.io.File | file.listFiles |



### file.rmdir

> 删除目录

| 参数名 | 类型   | 必填 |
| :----- | ------ | ---- |
| path   | string | 是   |

| 返回值类型 |
| ---------- |
| boolean    |



### file.delete

> 删除文件

| 参数名 | 类型   | 必填 |
| :----- | ------ | ---- |
| path   | string | 是   |

| 返回值类型 |
| ---------- |
| boolean    |



### file.remove

> 删除文件或目录

| 参数名 | 类型   | 必填 |
| :----- | ------ | ---- |
| path   | string | 是   |

| 返回值类型 |
| ---------- |
| boolean    |



### file.read

> 读取文件

| 参数名 | 类型           | 默认 | 必填 |
| :----- | -------------- | ---- | ---- |
| path   | string         |      | 是   |
| mode   | string, number | "*a" | 否   |

| 返回值类型 |
| ---------- |
| string     |



### file.write

> 写出文件

| 参数名 | 类型     | 必填 |
| :----- | -------- | ---- |
| path   | string   | 是   |
| data   | LuaValue | 是   |

| 返回值类型 |
| ---------- |
| boolean    |



### file.writeTmp

> 写出临时文件

| 参数名 | 类型     | 必填 |
| :----- | -------- | ---- |
| data   | LuaValue | 是   |

| 返回值 | 类型   | 说明             |
| ------ | ------ | ---------------- |
| path   | string | 随机的缓存文件名 |



### file.lastTime

> 获取文件最后修改时间戳

| 参数名 | 类型   | 必填 |
| :----- | ------ | ---- |
| path   | string | 是   |

| 返回值类型 | 说明   |
| ---------- | ------ |
| number     | 十位数 |



### file.lastModifiedDate

> 获取文件最后修改时间

| 参数名 | 类型   | 必填 |
| :----- | ------ | ---- |
| path   | string | 是   |

| 返回值类型 | 说明           |
| ---------- | -------------- |
| string     | %Y-%m-%d %H:%M |



### file.length

> 获取文件或目录大小

| 参数名 | 类型    | 必填 |
| :----- | ------- | ---- |
| path   | string  | 是   |
| mode   | boolean | 否   |

| 返回值                     | 类型   | 说明             |
| -------------------------- | ------ | ---------------- |
| 大小                       | number | 默认             |
| 大小带单位(B,KB,MB,GB,...) | string | 当mode等于true时 |



### file.prefix

> 获取文件前缀

| 参数名 | 类型   | 必填 |
| :----- | ------ | ---- |
| path   | string | 是   |

| 返回值类型 |
| ---------- |
| string     |



### file.suffix

> 获取文件后缀

| 参数名 | 类型   | 必填 |
| :----- | ------ | ---- |
| path   | string | 是   |

| 返回值类型 |
| ---------- |
| string     |



### file.info

> 获取文件信息

| 参数名 | 类型   | 必填 | 说明                                 |
| :----- | ------ | ---- | ------------------------------------ |
| path   | string | 是   |                                      |
| name   | string | 否   | 如果没有给定name则返回全部信息的集合 |

| name     | 类型   | 说明                  |
| -------- | ------ | --------------------- |
| 绝对路径 | string | file.getAbsolutePath  |
| 目录名称 | string | file.getParent        |
| 文件名称 | string | file.getName          |
| 前缀名称 | string | file.prefix           |
| 后缀名称 | string | file.suffix           |
| 修改时间 | string | file.lastModifiedDate |
| 文件类型 | string | file.type             |
| 文件大小 | string | file.length           |



### file.exec

> 使用su进程(root)执行二进制文件

| 参数名 | 类型   | 必填 |
| :----- | ------ | ---- |
| path   | string | 是   |

| 返回值类型 |
| ---------- |
| string     |



### file.sh

> 执行shell文件

| 参数名 | 类型    | 必填 |
| :----- | ------- | ---- |
| path   | string  | 是   |
| root   | boolean | 否   |

| 返回值类型 |
| ---------- |
| string     |



### file.mv

> 移动文件

| 参数名   | 类型   | 必填 |
| :------- | ------ | ---- |
| 源文件   | string | 是   |
| 目标文件 | string | 是   |
| root     |        |      |

| 返回值类型 |
| ---------- |
| string     |



### file.chmod

> 修改文件权限

| 参数名     | 类型    | 必填 |
| :--------- | ------- | ---- |
| path       | string  | 是   |
| permission | string  | 是   |
| root       | boolean | 否   |

| 返回值类型 |
| ---------- |
| string     |



### file.rm

> 强制删除文件

| 参数名 | 类型    | 必填 |
| :----- | ------- | ---- |
| path   | string  | 是   |
| root   | boolean | 否   |

| 返回值类型 | 命令        |
| ---------- | ----------- |
| string     | rm -rf path |



### file.changeName

> 返回更改文件名

| 参数名 | 类型   | 必填 |
| :----- | ------ | ---- |
| path   | string | 是   |
| name   | string | 是   |

| 返回值类型 |
| ---------- |
| string     |



### file.changeExtension

> 返回更改文件扩展名

| 参数名 | 类型   | 必填 |
| :----- | ------ | ---- |
| path   | string | 是   |
| name   | string | 是   |

| 返回值类型 |
| ---------- |
| string     |



### file.md5

> 获取文件MD5

| 参数名 | 类型   | 必填 |
| :----- | ------ | ---- |
| path   | string | 是   |

| 返回值类型 |
| ---------- |
| string     |



### file.open

> 调用系统API打开文件

| 参数名 | 类型   | 必填 |
| :----- | ------ | ---- |
| path   | string | 是   |



### file.getAppPath

> 获取软件自身路径

| 返回值类型 |
| ---------- |
| string     |



### file.ipairs

> 遍历子文件

| 参数名     | 类型                 | 必填 |
| :--------- | -------------------- | ---- |
| path\|file | string\|java.io.File | 是   |

> 示例

~~~lua
for i, mfile in file.ipairs("/sdcard/") do
	--
end
~~~

| 变量名 | 类型     | 类名         |
| ------ | -------- | ------------ |
| i      | number   |              |
| mfile  | userdata | java.io.File |





## device

> android.os.Build 的一些成员变量
>
> 详细可print(device)看看



### device.getWidth

> 获取设备分辨率的宽

| 返回值类型 |
| ---------- |
| number     |



### device.getHeight

> 获取设备分辨率的高

| 返回值类型 |
| ---------- |
| number     |



### device.getimei

> 获取设备的imei

| 返回值类型 |
| ---------- |
| string     |





## app

> app类库继承于android.content.Context



### app的属性

> 以下是RLGG自身的属性

| 字段名称    | 类型                              | 说明         |
| ----------- | --------------------------------- | ------------ |
| context     | android.content.Context           | 应用上下文   |
| pm          | android.content.pm.PackageManager | 包管理器     |
| info        | android.content.pm.PackageInfo    | 包信息       |
| name        | string                            | 应用名称     |
| path        | string                            | apk路径      |
| md5         | string                            | apk的MD5     |
| sign        | string                            | 签名         |
| sign_md5    | string                            | 签名的MD5    |
| sign_sha1   | string                            | 签名的SHA1   |
| sign_sha256 | string                            | 签名的SHA256 |





### app.newContext

> 根据给定的 包名 创建出上下文

| 参数名      | 类型   | 必填 | 默认 |
| :---------- | ------ | ---- | ---- |
| packageName | string | 是   |      |
| flags       | number | 否   | 2    |

| 返回值类型 | 类名                    |
| ---------- | ----------------------- |
| userdata   | android.app.ContextImpl |



### app.getPackageInfo

> 获取包信息

| 参数名               | 类型   | 必填 | 默认 |
| :------------------- | ------ | ---- | ---- |
| packageName\|apkPath | string | 是   |      |
| flags                | number | 否   | 0    |

| 返回值类型 | 类名                           |
| ---------- | ------------------------------ |
| userdata   | android.content.pm.PackageInfo |



### app.getName

> 获取app名称

| 参数名      | 类型   | 必填 |
| :---------- | ------ | ---- |
| packageName | string | 是   |

| 返回值类型 |
| ---------- |
| string     |



### app.install

> 安装应用

| 参数名  | 类型    | 必填 | 说明                   |
| :------ | ------- | ---- | ---------------------- |
| apkPath | string  | 是   |                        |
| root    | boolean | 否   | 是否使用su命令进行安装 |

| 返回值类型 |
| ---------- |
| string     |



### app.uninstall

> 卸载应用

| 参数名      | 类型    | 必填 | 说明                   |
| :---------- | ------- | ---- | ---------------------- |
| packageName | string  | 是   |                        |
| root        | boolean | 否   | 是否使用su命令进行卸载 |



### app.startActivity

> 启动应用

| 参数名 | 类型                   | 必填 |
| :----- | ---------------------- | ---- |
| Intent | android.content.Intent | 是   |



### app.start

> 启动应用

| 参数名      | 类型   | 必填 |
| :---------- | ------ | ---- |
| packageName | string | 是   |



### app.intent

> 启动android.intent.action.VIEW

| 参数名 | 类型   | 必填 |
| :----- | ------ | ---- |
| uri    | string | 是   |



### app.openUrl

> 打开URL链接

| 参数名 | 类型   | 必填 |
| :----- | ------ | ---- |
| url    | string | 是   |



### app.signatures

> 获取app签名

| 参数名      | 类型   | 必填 |
| :---------- | ------ | ---- |
| packageName | string | 是   |

| 返回值类型 |
| ---------- |
| string     |



### app.getInstalledPackages

> 获取已安装的包列表

| 参数名 | 类型   | 必填 | 默认 |
| :----- | ------ | ---- | ---- |
| flags  | number | 否   | 0    |

| flags | 说明               |
| ----- | ------------------ |
| 0     | 获取普通应用       |
| 1     | 获取系统应用       |
| 2     | 获取普通和系统应用 |

| 返回值类型 |
| ---------- |
| table      |



### app.isSystem

> 判断app是否为系统应用

| 参数名      | 类型   | 必填 |
| :---------- | ------ | ---- |
| packageName | string | 是   |

| 返回值类型 |
| ---------- |
| boolean    |



### app.isRoot

> 判断当前运行环境是否为ROOT

| 返回值类型 |
| ---------- |
| boolean    |



### app.getPID

> 获取给定 包名 的PID

| 参数名      | 类型   | 必填 |
| :---------- | ------ | ---- |
| packageName | string | 是   |

| 返回值类型 |
| ---------- |
| number     |



### app.kill

> 杀死进程

| 参数名           | 类型           | 必填 |
| :--------------- | -------------- | ---- |
| packageName\|PID | string\|number | 是   |

| 返回值类型 |
| ---------- |
| string     |



### app.installSystem

> 把普通应用安装到系统应用

| 参数名      | 类型   | 必填 |
| :---------- | ------ | ---- |
| packageName | string | 是   |

| 返回值类型 |
| ---------- |
| boolean    |



### app.reboot

> 重启手机



### app.exit

> 退出应用



### app.runList

> 获取正在运行中的包名列表

| 返回值类型 |
| ---------- |
| table      |



### app.getPath

> 获取包名的apk路径

| 参数名      | 类型   | 必填 |
| :---------- | ------ | ---- |
| packageName | string | 是   |

| 返回值类型 |
| ---------- |
| string     |



### app.bootTime

> 获取系统开机时间

| 返回值类型 | 说明             |
| ---------- | ---------------- |
| number     | 长度为10的时间戳 |



### app.loadIcon

> 加载应用图标

| 参数名      | 类型   | 必填 |
| :---------- | ------ | ---- |
| packageName | string | 是   |

| 返回值类型                               |
| ---------------------------------------- |
| android.graphics.drawable.BitmapDrawable |



### app.is64

> 判断进程是否为64位（必须是已经运行的进程）

| 参数名      | 类型   | 必填 |
| :---------- | ------ | ---- |
| packageName | string | 是   |

| 返回值类型 |
| ---------- |
| boolean    |

~~~lua
is64 = app.is64('包名')
is32 = not app.is64('包名')
~~~







## qq



### qq.join

> 跳转到给定的 QQ 用户界面

| 参数名 | 类型   | 必填 |
| :----- | ------ | ---- |
| qq     | string | 是   |



### qq.joinGroup

> 跳转到给定的 Q群 界面

| 参数名 | 类型   | 必填 |
| :----- | ------ | ---- |
| qq群   | string | 是   |



### qq.exist

> 检查当前环境是否存在给定的qq
>
> 注意,和RLGG同一个运行环境才有效

| 参数名 | 类型   | 必填 |
| :----- | ------ | ---- |
| qq     | string | 是   |

| 返回值类型 |
| ---------- |
| boolean    |



### qq.existGroup

> 检查当前环境是否存在给定的q群

| 参数名 | 类型   | 必填 |
| :----- | ------ | ---- |
| qq群   | string | 是   |

| 返回值类型 |
| ---------- |
| boolean    |

> 示例

~~~lua
local qun = '694700750'
if not qq.existGroup(qun) then
	if gg.alert(string.format('请先加入QQ群%s', qun), '跳转', '退出') == 1 then
		qq.joinGroup(qun)
	end
	os.exit()
    return
end

~~~





## draw

>注意，RLGG运行结束后会自动执行draw.remove 来移除所有draw产生的绘制
>
>在测试的时候，需要加个延时来保证脚本不会立即结束



在安卓12或以上版本使用 draw 进行绘制,会导致屏幕触摸失效

可以加载 draw3 来修复, 例如在脚本最前面加入 

```lua
require('draw3')
```

就可以了,可以不需要改动其它代码

更建议使用原生rlgg的绘制,[查看示例](demo/RLGG原生绘制-示例.lua)



### draw.new

> 把旧版的 DrawTool-绘制工具 初始化到 _ENV 环境



### draw.line

> 绘制线段

| 参数名 | 类型   | 必填 | 说明          |
| :----- | ------ | ---- | ------------- |
| startX | number | 是   | 线段开头的x轴 |
| startY | number | 是   | 线段开头的y轴 |
| endX   | number | 是   | 线段结尾的x轴 |
| endY   | number | 是   | 线段结尾的y轴 |

| 返回值名称 | 返回值类型 |
| ---------- | ---------- |
| ID         | number     |

> 示例

~~~lua
draw.line(100, 100, 100, 200)
gg.sleep(5000) -- 正常开发把这行延时代码删掉
~~~



### draw.circle

> 绘制圆形

| 参数名 | 类型   | 必填 | 说明      |
| :----- | ------ | ---- | --------- |
| startX | number | 是   | 圆心的x轴 |
| startY | number | 是   | 圆心的y轴 |
| radius | number | 是   | 圆的半径  |

| 返回值名称 | 返回值类型 |
| ---------- | ---------- |
| ID         | number     |

> 示例

~~~lua
draw.circle(200, 200, 100)
gg.sleep(5000) -- 正常开发把这行延时代码删掉
~~~



### draw.rect

> 绘制方形

| 参数名 | 类型   | 必填 | 说明            |
| :----- | ------ | ---- | --------------- |
| startX | number | 是   | 方形左上角x坐标 |
| startY | number | 是   | 方形左上角y坐标 |
| endX   | number | 是   | 方形右下角x坐标 |
| endY   | number | 是   | 方形右下角y坐标 |

| 返回值名称 | 返回值类型 |
| ---------- | ---------- |
| ID         | number     |

> 示例，参考draw3





### draw.progress

> 绘制进度条

| 返回值名称 | 返回值类型 |
| ---------- | ---------- |
| ID         | number     |

> 示例，参考draw3



### draw.picture

> 绘制原比例大小的图片

| 参数名 | 类型   | 必填 | 说明         |
| :----- | ------ | ---- | ------------ |
| path   | string | 是   | 图像文件路径 |
| startX | number | 是   |              |
| startY | number | 是   |              |

| 返回值名称 | 返回值类型 |
| ---------- | ---------- |
| ID         | number     |

> 示例

~~~lua
draw.picture(file.checkUrl('https://q4.qlogo.cn/headimg_dl?dst_uin=507522729&spec=640'), 0, 0)
gg.sleep(5000) -- 正常开发把这行延时代码删掉
~~~



### draw.scaled

> 绘制自定义比例的图片

| 参数名 | 类型   | 必填 | 说明         |
| :----- | ------ | ---- | ------------ |
| path   | string | 是   | 图像文件路径 |
| startX | number | 是   |              |
| startY | number | 是   |              |
| endX   | number | 是   |              |
| endY   | number | 是   |              |

| 返回值名称 | 返回值类型 |
| ---------- | ---------- |
| ID         | number     |

> 示例

~~~lua
draw.scaled(file.checkUrl('https://q4.qlogo.cn/headimg_dl?dst_uin=507522729&spec=640'), 0, 0,100,100)
gg.sleep(5000) -- 正常开发把这行延时代码删掉
~~~



### draw.text

> 绘制文本/文字

| 参数名 | 类型   | 必填 | 说明     |
| :----- | ------ | ---- | -------- |
| text   | string | 是   | 文本内容 |
| startX | number | 是   |          |
| startY | number | 是   |          |

| 返回值名称 | 返回值类型 |
| ---------- | ---------- |
| ID         | number     |

> 示例

~~~lua
draw.text('RLGG', 200,200)
gg.sleep(5000) -- 正常开发把这行延时代码删掉
~~~



### draw.remove

> 移除绘制

| 参数名 | 类型   | 必填 | 说明             |
| :----- | ------ | ---- | ---------------- |
| ID     | number | 是   | draw类库返回的ID |



### draw.setColor

> 设置绘制颜色

| 参数名 | 类型   | 必填 | 说明           |
| :----- | ------ | ---- | -------------- |
| color  | string | 是   | 十六进制颜色值 |

> 示例

~~~lua
draw.setColor("#ff0000")
draw.text('RLGG', 200,200)
gg.sleep(5000) -- 正常开发把这行延时代码删掉
~~~



### draw.setOrigin

> 设置绘制坐标轴的原点

| 参数名 | 类型   | 必填 | 说明 |
| :----- | ------ | ---- | ---- |
| startX | number | 是   |      |
| startY | number | 是   |      |

> 示例

~~~lua
draw.setOrigin(200,300)
~~~



### draw.setRange

> 设置全部绘制内容的最大显示范围(注意：设置显示范围的形状为方形)

| 参数名 | 类型   | 必填 | 说明 |
| :----- | ------ | ---- | ---- |
| startX | number | 是   |      |
| startY | number | 是   |      |

> 示例

~~~lua
draw.setRange(100,100,300,300)
~~~



### draw.setSize

> 设置绘制文本的大小(注意：只对文本绘制有效)

| 参数名 | 类型   | 必填 | 说明 |
| :----- | ------ | ---- | ---- |
| size   | number | 是   |      |

> 示例

~~~lua
draw.setSize(20)
~~~



### draw.setStyle

> 设置绘制的样式为描边还是填充(注意：只对绘制圆、方形有效)

| 参数名    | 类型   | 必填 | 说明                   |
| :-------- | ------ | ---- | ---------------------- |
| StyleType | string | 是   | 描边\|填充\|描边并填充 |

> 示例

~~~lua
draw.setStyle('描边并填充')
~~~



### draw.setWidth

> 设置画笔的粗细(注意：对绘制文本无效)

| 参数名 | 类型   | 必填 | 说明 |
| :----- | ------ | ---- | ---- |
| size   | number | 是   |      |

> 示例

~~~lua
draw.setWidth(5)
~~~



### draw.updateColor

> 更新已绘制颜色

| 参数名 | 类型   | 必填 | 说明             |
| :----- | ------ | ---- | ---------------- |
| ID     | number | 是   | draw类库返回的ID |
| color  | string | 是   | 十六进制颜色值   |

> 示例

~~~lua
draw.setColor('#ff0000')
local ID1=draw.text('RLGG', 200,200)
gg.sleep(1000)
draw.updateColor(ID1,'#ffff00')
gg.sleep(5000) -- 正常开发把这行延时代码删掉
~~~



### draw.updateText

> 更新已绘制文本

| 参数名 | 类型   | 必填 | 说明               |
| :----- | ------ | ---- | ------------------ |
| ID     | number | 是   | draw.text 返回的ID |
| text   | string | 是   | 文本               |

> 示例

~~~lua
draw.setColor("#ff0000")
local ID1=draw.text('RLGG', 200,200)
gg.sleep(1000)
draw.updateText(ID1,'更新了绘制文本')
gg.sleep(5000) -- 正常开发把这行延时代码删掉
~~~



### draw.updateDraw

> 更新已绘制的内容

| 参数名 | 类型   | 必填 | 说明               |
| :----- | ------ | ---- | ------------------ |
| ID     | number | 是   |                    |
| vararg | ...    | 是   | ID原方法需要的参数 |



## draw3

有 draw3 那么有 draw2 吗？

没有，draw2 只是很久以前占用的一个变量名，已经弃用了



需要使用 require('draw3') 导入模块，不进行“饿汉式”加载

draw3 包含所有 draw 返回值为 ID 的方法

draw3 方法的返回值为table

| 方法名   | 参数类型                               | 说明     |
| -------- | -------------------------------------- | -------- |
| setColor | string{\#%06x} \| number{0x0-0xffffff} | 设置颜色 |
| update   | ...                                    | 更新绘制 |
| remove   | 没有参数                               | 移除绘制 |



### draw3.text

> 绘制文本/文字

| 参数名 | 类型   | 必填 | 说明     |
| :----- | ------ | ---- | -------- |
| text   | string | 是   | 文本内容 |
| startX | number | 是   |          |
| startY | number | 是   |          |

update 方法

| 参数名 | 类型   | 说明           |
| ------ | ------ | -------------- |
| text   | string | 需要更新的文本 |



~~~lua
draw3 = require('draw3')
text1 = draw3.text('0', device.width / 2, device.height / 2)
for i = 1, 100 do
	gg.sleep(50)

	-- 设置随机颜色
	local color = math.random(000000, 0xffffff)
	text1.setColor(color)

	-- 更新文本
	text1.update(i)
end

~~~



### draw3.rect

> 绘制方形

| 参数名 | 类型   | 必填 | 说明            |
| :----- | ------ | ---- | --------------- |
| startX | number | 是   | 方形左上角x坐标 |
| startY | number | 是   | 方形左上角y坐标 |
| endX   | number | 是   | 方形右下角x坐标 |
| endY   | number | 是   | 方形右下角y坐标 |

update 方法，参数和 draw3.rect 参数一样



~~~lua
draw3 = require('draw3')

-- 方块宽度为屏幕宽度的十分之一
width = device.width / 10
-- 方块高度为屏幕高度的十分之一
height = device.height / 10

-- 把绘制的对象创建出来
rect1 = draw3.rect(0, 0, 0, 0)

-- 更新绘制内容
for y = 1, device.height, height do
	-- 设置随机颜色
	-- local color = math.random(000000, 0xffffff)
	-- rect1.setColor(color)

	for x = 1, device.width, width do
		rect1.update(x, y, x + width, y + height)
		gg.sleep(100)
	end
end

~~~





### draw3.progress

> 绘制进度条

| 参数名 | 类型   | 必填 | 说明            |
| :----- | ------ | ---- | --------------- |
| max    | number | 是   | 进度条的最大值  |
| startX | number | 是   | 方形左上角x坐标 |
| startY | number | 是   | 方形左上角y坐标 |
| endX   | number | 是   | 方形右下角x坐标 |
| endY   | number | 是   | 方形右下角y坐标 |

update 方法

| 参数名 | 类型   | 说明             |
| ------ | ------ | ---------------- |
| num    | number | 进度条当前的数值 |



~~~lua
draw3 = require('draw3')

local max = 100
local startX = 0
local startY = device.height / 2
local endX = device.width
local endY = startY + (startY / 10)

-- 把绘制的对象创建出来
progress1 = draw3.progress(max, startX, startY, endX, endY)

for i = 1, max do
	progress1.update(i)
	gg.sleep(10)
end

~~~





## table

>table类库使用的参数名self，指的是表



### table.keys

> 获取全部table的key到新的table

| 参数名 | 类型  |
| :----- | ----- |
| self   | table |

| 返回值类型 |
| ---------- |
| table      |

~~~lua
local t = {aa="a",bb="b",cc="c"}
print(table.keys(t)) --> {"aa","bb","cc"}
~~~



### table.values

> 获取全部table的value到新的table

| 参数名 | 类型  |
| :----- | ----- |
| self   | table |

| 返回值类型 |
| ---------- |
| table      |

~~~lua
local t = {aa="a",bb="b",cc="c"}
print(table.keys(t)) --> {"a","b","c"}
~~~



### table.indexof

> 从数组table查找value

| 参数名 | 类型     | 必填 | 说明                 |
| :----- | -------- | ---- | -------------------- |
| array  | table    | 是   |                      |
| value  | LuaValue | 是   | 需要查找的值         |
| begin  |          | 否   | 从指定的索引开始查找 |

| 返回值类型   |
| ------------ |
| index\|false |

~~~lua
local t = {"a","b","c"}
print(table.indexof(t,"c")) -->3
~~~



### table.keyof

> 从数组table查找value

| 参数名 | 类型     | 必填 | 说明                 |
| :----- | -------- | ---- | -------------------- |
| k-v    | table    | 是   | 通用table            |
| value  | LuaValue | 是   | 需要查找的值         |
| begin  |          | 否   | 从指定的索引开始查找 |

| 返回值类型 |
| ---------- |
| index\|nil |

~~~lua
local t = {"a","b","c"}
print(table.keyof(t,"c")) -->3
~~~



### table.map

> 映射table

| 参数名 | 类型     | 必填 | 说明      |
| :----- | -------- | ---- | --------- |
| k-v    | table    | 是   | 通用table |
| func   | function | 是   | 处理函数  |

| 返回值类型 |
| ---------- |
| nil        |

遍历table，回调处理函数的结果作为新的value，回调参数为 value，key

~~~lua
local t = {"a","b","c"}
table.map(t, function(v,k) return string.format("修饰-%s",v) end)
print(t)
--[[

{
	"修饰-a",
	"修饰-b",
	"修饰-c"
}

]]
~~~



### table.walk

> 遍历table

| 参数名 | 类型     | 必填 | 说明      |
| :----- | -------- | ---- | --------- |
| k-v    | table    | 是   | 通用table |
| func   | function | 是   | 处理函数  |

| 返回值类型 |
| ---------- |
| nil        |

遍历table，每次遍历都进行回调 处理函数进行处理，回调参数为 value，key

~~~lua
local t = {"a","b","c"}
table.walk(t, print)

--[[

a,1
b,2
c,3

]]
~~~



### table.filter

> 过滤器

| 参数名 | 类型     | 必填 | 说明      |
| :----- | -------- | ---- | --------- |
| k-v    | table    | 是   | 通用table |
| func   | function | 是   | 处理函数  |

| 返回值类型 |
| ---------- |
| nil        |

遍历table，每次遍历都进行回调 处理函数进行处理，回调参数为 value，key

处理函数结果不为true时，则丢弃该值



~~~lua
local t = {"a", "b", "c"}
table.filter(t, function(v, k)
	if v == "c" then
		return false
	end
	return true
end)
print(t)

-- {"a","b"}
~~~



### table.key2val

> key-value互转，key变成value，value变成key

| 参数名 | 类型  |
| :----- | ----- |
| self   | table |

| 返回值类型 |
| ---------- |
| newtable   |

~~~lua
local t = {"a","b","c"}
print(table.key2val(t))
--[[

{
	a=1,
	b=2,
	c=3
}

]]
~~~



### table.clear

> 清空table

| 参数名 | 类型  |
| :----- | ----- |
| self   | table |



### table.removeRepeat

> 删除重复Value（浅）

| 参数名 | 类型  |
| :----- | ----- |
| self   | table |

| 返回值类型 |
| ---------- |
| self       |



### table.removeRepeats

> 删除重复Value（深）

| 参数名 | 类型  |
| :----- | ----- |
| self   | table |

| 返回值类型 |
| ---------- |
| self       |

> 示例



```lua
local t1={1,2,3,3,4,{1,1}}
table.removeRepeat(t1) -- 浅

{ -- table(ef347d8)
	[1] = 1,
	[2] = 2,
	[3] = 3,
	[4] = 4,
	[5] = { -- table(7e46bb)
		[1] = 1,
		[2] = 1,
	},
}

local t1={1,2,3,3,4,{1,1}}
table.removeRepeat(t1) -- 深

{ -- table(ef347d8)
	[1] = 1,
	[2] = 2,
	[3] = 3,
	[4] = 4,
	[5] = { -- table(7e46bb)
		[1] = 1,
	},
}
```



### table.length

> 通过遍历获取表的真实长度

| 参数名 | 类型  |
| :----- | ----- |
| self   | table |

| 返回值类型 |
| ---------- |
| number     |



### table.merge

> 合并多个表

| 参数名 | 类型       |
| :----- | ---------- |
| self   | table      |
| ...    | ...(table) |

| 返回值类型 |
| ---------- |
| self       |



### table.copy

> 拷贝表（深）

| 参数名 | 类型  | 必填 |
| :----- | ----- | ---- |
| to     | table | 否   |
| from   | table | 是   |

| 返回值名称 | 类型  |
| ---------- | ----- |
| to         | table |

> 示例

~~~lua
local t1 = {1,2,3}
table.copy(t1)
{1,2,3} -- 元素一样的新表

local t1 = {a=1,b=2}
local t2 = {a=100}
table.copy(t1, t2)
{a=100,b=2} == t1
~~~



### table.list

> 把数组转table

| 参数名 | 类型           |
| :----- | -------------- |
| list   | java.util.List |

| 返回值名称 | 类型  |
| ---------- | ----- |
| 表         | table |

> 先前写 table.list 的参数类型为 [ ,这是错误的，  java.util.List 才对



### table.array

> 把数组转table

| 参数名 | 类型                       |
| :----- | -------------------------- |
| Array  | java.lang.reflect.Array，[ |

| 返回值名称 | 类型  |
| ---------- | ----- |
| 表         | table |



### table.find

> 找元素（浅）

| 参数名     | 类型     |
| :--------- | -------- |
| self       | table    |
| 需要找的值 | LuaValue |

| 返回值名称 | 类型     |
| ---------- | -------- |
| 位置       | index    |
| 找到的值   | LuaValue |



### table.finds

> 找元素（深）

| 参数名     | 类型     |
| :--------- | -------- |
| self       | table    |
| 需要找的值 | LuaValue |

| 返回值名称 | 类型     |
| ---------- | -------- |
| 位置       | index    |
| 找到的值   | LuaValue |



### table.pairs

> 和 [pairs](#pairs ) 一样



### table.ipairs

> 和 [ipairs ](#ipairs ) 一样



### table.json

> 和 [json.decode][] 一样







## math

> 这是一个和数字相关的类库



### math.byte2bins

> 十进制转二进制

| 参数名 | 类型   |
| :----- | ------ |
| byte   | number |

| 返回值类型 | 说明       |
| ---------- | ---------- |
| table      | 二进制列表 |



### math.byte2bin

> 十进制转二进制

| 参数名 | 类型   |
| :----- | ------ |
| byte   | number |

| 返回值类型 | 说明     |
| ---------- | -------- |
| string     | 二进制串 |

> 示例

~~~lua
math.byte2bin(0) -- 00000000
math.byte2bin(100) -- 01100100
~~~



### math.bin2byte

> 二进制转十进制

| 参数名   | 类型   |
| :------- | ------ |
| 二进制串 | string |

| 返回值类型 |
| ---------- |
| number     |



### math.int

> 数值转整数

| 参数名   | 类型   |
| :------- | ------ |
| LuaValue | number |

| 返回值类型 |
| ---------- |
| number     |

> 示例

~~~lua
math.int(100.023) -- 100
~~~



### math.float

> 数值转浮点型

| 参数名   | 类型   |
| :------- | ------ |
| LuaValue | number |

| 返回值类型 |
| ---------- |
| number     |

> 示例

~~~lua
math.int(100) -- 100.0
~~~





## streamUtils

> 和输入（java.io.InputStream）输出（java.io.OutputStream）流有关的类库





### streamUtils.inputStreamWriteFile

> 将输入流写出到文件

| 参数名       | 类型                |
| :----------- | ------------------- |
| 输入流       | java.io.InputStream |
| 文件绝对路径 | string              |



### streaUtils.fileWriteOutputStream

> 将文件输出到输出流

| 参数名       | 类型                 |
| :----------- | -------------------- |
| 文件绝对路径 | string               |
| 输出流       | java.io.OutputStream |



### streamUtils.stringWriteOutputStream

> 将字符串输出到输出流

| 参数名 | 类型                 |
| :----- | -------------------- |
| 数据   | string               |
| 输出流 | java.io.OutputStream |



### streamUtils.readInputStream

> 读取输入流

| 参数名 | 类型                |
| :----- | ------------------- |
| 输入流 | java.io.InputStream |

| 返回值类型 |
| ---------- |
| string     |



### streamUtils.copy

> 将输入流拷贝到输出流

| 参数名 | 类型                 |
| :----- | -------------------- |
| 输入流 | java.io.InputStream  |
| 输出流 | java.io.OutputStream |



## dex

> 加载外部dex交互



### dex.newInstance

> 创建dex实例，推荐用 dex.loadfile，单例的后续加载更快

| 参数名             | 必须 | 类型                  | 说明             |
| :----------------- | ---- | --------------------- | ---------------- |
| dexPath            | 是   | string                | dex文件绝对路径  |
| optimizedDirectory | 否   | string                | 优化后缓存的目录 |
| librarySearchPath  | 否   | string                | lib搜索路径      |
| parent             | 否   | java.lang.ClassLoader | 父加载器         |

| 返回值类型                   |
| ---------------------------- |
| dalvik.system.DexClassLoader |



### dex.loadfile

> 加载dex文件，每个文件都是单例，加载成功后进行缓存
>
> 该dex会加入 import 的加载器中，意味着 import 可以获取dex的类

| 参数名    | 必须 | 类型   | 说明                |
| :-------- | ---- | ------ | ------------------- |
| dexPath   | 是   | string | dex文件绝对路径     |
| className | 否   | string | 返回从dex加载该类名 |

| 返回值类型                                      |
| ----------------------------------------------- |
| dalvik.system.DexClassLoader \| java.lang.Class |



### dex.appendLoader

> 将 dexloader 加入到 import 的加载器中，import 可以获取该dex的类

| 参数名 | 必须 | 类型                         | 说明 |
| :----- | ---- | ---------------------------- | ---- |
| loader | 是   | dalvik.system.DexClassLoader |      |







## functions

> 函数专用类库（基本参数或返回值是function类型），functions类库必须是使用 2.0.9或以上版本，否则可能有问题



### functions.synchronized

> 获取函数的同步回调，在多线程执行，同一时间只会执行唯一一个
>
> 利用 java synchronized关键词

| 参数名   | 必须 | 类型     | 说明 |
| :------- | ---- | -------- | ---- |
| callback | 是   | function |      |

| 返回值类型 | 说明       |
| ---------- | ---------- |
| function   | 加持同步锁 |

~~~lua
local function func(...)
	print(...)

	gg.sleep(50)
end

-- 给函数加上同步锁
synfunc = functions.synchronized(func)

-- 获取函数的多线程回调
synthreadfunc = functions.thread(synfunc)
threadfunc = functions.thread(func)

-- 同步锁测试
for i = 1, 5, 1 do
	local msg = string.format('同步锁多线程第%s次执行', i)
	synthreadfunc(msg)
end

-- 没有同步锁测试
for i = 1, 5, 1 do
	local msg = string.format('多线程第%s次执行', i)
	threadfunc(msg)
end

gg.sleep(110)

--[[

运行结束后同步锁的多线程只执行了2-3次，其它的还没来得及执行脚本就结束了（需要等待正在执行中的执行完了，其它的才可以执行）

]]
~~~



### functions.syncCall

> 同步执行函数

| 参数名 | 必须 | 类型     | 说明 |
| :----- | ---- | -------- | ---- |
| func   | 是   | function |      |
| vararg | 否   | ...      |      |

| 返回值类型 | 说明          |
| ---------- | ------------- |
| ...        | pcall的返回值 |



### functions.preload

> 获取函数的预加载回调
>
> 第一次执行时，执行 callback，之后的执行，都是调用 callback 的返回值，因此第一次执行 callback 需要返回一个function

| 参数名   | 必须 | 类型     | 说明 |
| :------- | ---- | -------- | ---- |
| callback | 是   | function |      |

| 返回值类型 |
| ---------- |
| function   |

~~~lua
local func = functions.preload(function(...)

	-- 初始化，只会执行一次
	local res = math.random(1000, 9999)

	-- 返回真正的函数
	return function(...)
		return res
	end
end)

func('支持参数')

for i = 1, 10, 1 do

	-- func 的返回值是一样的
	print(func())
end

~~~



### functions.singleton

> 获取函数的单例回调
>
> 首次执行callback会缓存执行结果，其余的执行都是直接返回该缓存结果

| 参数名   | 必须 | 类型     | 说明 |
| :------- | ---- | -------- | ---- |
| callback | 是   | function |      |

| 返回值类型 | 说明                     |
| ---------- | ------------------------ |
| function   | 返回的是 callback 的结果 |

~~~lua
local function func(...)
	return math.random(1000, 9999)
end

singletonfunc = functions.singleton(func)

threadfunc = functions.thread(function()
	print(singletonfunc())
end)

for i = 1, 10, 1 do
	threadfunc()
end

gg.sleep(50)

-- 每次的结果都是首次的执行结果（即便是在多线程）

~~~



### functions.thread

> 获取函数的多线程回调

| 参数名   | 必须 | 类型     | 说明 |
| :------- | ---- | -------- | ---- |
| callback | 是   | function |      |

| 返回值类型 | 说明                                                         |
| ---------- | ------------------------------------------------------------ |
| function   | 执行这个函数，会自动转为多线程执行，支持参数，返回值是 java.lang.Thread |

> 例子可以看上面的 functions.singleton 或者 functions.synchronized



### functions.voidThread

> 获取函数的多线程回调，callback不会返回结果

| 参数名   | 必须 | 类型     | 说明 |
| :------- | ---- | -------- | ---- |
| callback | 是   | function |      |

| 返回值类型 | 说明                                                     |
| ---------- | -------------------------------------------------------- |
| function   | 执行这个函数，会自动转为多线程执行，支持参数，没有返回值 |



### functions.closure

> 创建闭包

| 参数名 | 必须 | 类型     | 说明 |
| :----- | ---- | -------- | ---- |
| func   | 是   | function |      |
| vararg | 否   | ...      |      |

| 返回值类型 | 说明 |
| ---------- | ---- |
| function   |      |

~~~lua
local f1 = functions.closure(gg.toast, '欢迎使用RLGG')

-- 等价于 gg.toast('欢迎使用RLGG')
f1()
f1()
~~~



### functions.closures

> 创建闭包，闭包依然可携带参数

| 参数名 | 必须 | 类型     | 说明 |
| :----- | ---- | -------- | ---- |
| func   | 是   | function |      |
| vararg | 否   | ...      |      |

| 返回值类型 | 说明 |
| ---------- | ---- |
| function   |      |

~~~lua
local yz_alert = functions.closures(gg.alert2, 'RL云验证系统-超级无敌科技')

yz_alert('登录成功', 'ok')
yz_alert('登录失败', '重新登录')
~~~



## auto

> 基于无障碍模式自动点击



x:屏幕x坐标

y:屏幕y坐标



[查看示例](demo/auto/auto测试.lua)



### auto.start

> 使用auto类库之前,需要先启动一下服务(一些初始化工作,和判断当前用户是否开启无障碍)

| 返回值类型      |
| --------------- |
| boolean[,error] |

~~~lua
assert(auto.start())
local x = device.x
local y = device.y / 2
gg.setVisible(false)
gg.sleep(500)
auto.swipe(0, y, x, y, 500) -- 由左向右滑动屏幕
~~~



### auto.click

> 短暂点击屏幕坐标,固定耗时100毫秒

| 参数名 | 必须 | 类型   |
| :----- | ---- | ------ |
| x      | 是   | number |
| y      | 是   | number |



### auto.longClick

> 长按屏幕坐标,固定耗时1000毫秒

| 参数名 | 必须 | 类型   |
| :----- | ---- | ------ |
| x      | 是   | number |
| y      | 是   | number |



### auto.tap

> 点击屏幕

| 参数名 | 必须 | 类型   | 说明         |
| :----- | ---- | ------ | ------------ |
| x      | 是   | number |              |
| y      | 是   | number |              |
| milli  | 是   | number | 耗时（毫秒） |



### auto.swipe

> 滑动屏幕

| 参数名 | 必须 | 类型   | 说明         |
| :----- | ---- | ------ | ------------ |
| startX | 是   | number | 开始X坐标    |
| startY | 是   | number | 开始Y坐标    |
| endX   | 是   | number | 结束X坐标    |
| endY   | 是   | number | 结束Y坐标    |
| milli  | 是   | number | 耗时（毫秒） |



### auto.press

> 模拟按住坐标

| 参数名 | 必须 | 类型   | 说明         |
| :----- | ---- | ------ | ------------ |
| x      | 是   | number |              |
| y      | 是   | number |              |
| milli  | 是   | number | 耗时（毫秒） |



### auto.gesture

> 模拟手势操作

| 参数名 | 必须 | 类型   | 说明         |
| :----- | ---- | ------ | ------------ |
| milli  | 是   | number | 耗时（毫秒） |
| xy1    | 是   | table  | 坐标信息     |
| xy2    | 否   | table  | 坐标信息     |
| xyn... |      |        |              |

> 坐标信息可以有多个



### auto.gestures

> 同时模拟多个手势

| 参数名 | 必须 | 类型  | 说明               |
| :----- | ---- | ----- | ------------------ |
| xy1    | 是   | table | auto.gesture的参数 |
| xy2    | 否   | table | auto.gesture的参数 |
| xyn... |      |       |                    |

> 坐标信息可以有多个







## cglib [![Build Status](https://travis-ci.org/cglib/cglib.svg?branch=master)](https://github.com/cglib/cglib)

> cglib 是一个动态代理操作库，被代理的类不需要是接口类型
>
> 使用 cglib 需要使用 require 加载。 `local cglib = require('cglib')`



### cglib.createInterceptor

> 使用拦截器java方式代理，在需要执行 invokeSuper 的时候使用这种方式，否则建议使用 cglib.createProxy
>

| 参数名      | 必须 | 类型               | 说明               |
| :---------- | ---- | ------------------ | ------------------ |
| superClass  | 是   | class              | 需要代理的类       |
| proxyMethod | 是   | table methodName[] | 需要代理的方法     |
| intercept   | 是   | function           | 拦截器             |
| vararg      | 否   | ...                | 创建代理实例的参数 |

| 返回值类型 | 说明               |
| ---------- | ------------------ |
| userdata   | superClass(vararg) |

~~~lua
local cglib = require('cglib')

local o = cglib.createInterceptor(Object, {'toString', 'equals'}, function(thisObject, param, methodProxy)
	print('拦截', methodProxy:getMethodName())

	if methodProxy:getMethodName() == 'toString' then
		return 'cglib.createInterceptor：修改了toString的返回值'
	end

	return methodProxy:invokeSuper(thisObject, param)
end)

print(luajava.instanceOf(o, Object))
print(o:toString())
~~~



### cglib.createProxy

> 使用lua函数方式代理

| 参数名      | 必须 | 类型                        | 说明               |
| :---------- | ---- | --------------------------- | ------------------ |
| superClass  | 是   | class                       | 需要代理的类       |
| proxyMethod | 是   | table<methodName, callback> | 需要代理的方法     |
| vararg      | 否   | ...                         | 创建代理实例的参数 |

| 返回值类型 | 说明               |
| ---------- | ------------------ |
| userdata   | superClass(vararg) |

~~~lua
local cglib = require('cglib')

local o = cglib.createProxy(Object, {
	toString = function()
		return 'cglib.createProxy：修改了toString的返回值'
	end,
	equals = function(p1)
		return false
	end
})

print(o:toString())
print(o:equals(o), '被拦截了强制返回false')
~~~















[^src]: src可以是本地文件或者url





[json.decode]: #jsondecode

