local function FishView()
	local mPaint
	local mFishX = 20 -- 鱼的x坐标
	local mFishY = 70 -- 鱼的y坐标

	
	mPaint = Paint()
	mPaint:setAntiAlias(true)
	mPaint:setStyle(Paint.Style.FILL)
	mPaint:setColor(Color.RED)

	local function onDraw(canvas)
		-- 绘制鱼身体
		local bodyPath = Path()
		bodyPath:moveTo(mFishX, mFishY)
		bodyPath:lineTo(mFishX + 100, mFishY - 50)
		bodyPath:lineTo(mFishX + 150, mFishY)
		bodyPath:lineTo(mFishX + 100, mFishY + 50)
		bodyPath:close()
		canvas:drawPath(bodyPath, mPaint)

		-- 绘制鱼眼睛
		mPaint:setColor(Color.WHITE)
		canvas:drawCircle(mFishX + 110, mFishY - 10, 8, mPaint)
		mPaint:setColor(Color.BLACK)
		canvas:drawCircle(mFishX + 110, mFishY - 10, 4, mPaint)

		-- 绘制鱼嘴巴
		local mouthPath = Path()
		mouthPath:moveTo(mFishX + 150, mFishY)
		mouthPath:lineTo(mFishX + 120, mFishY + 20)
		mouthPath:lineTo(mFishX + 120, mFishY - 20)
		mouthPath:close()
		canvas:drawPath(mouthPath, mPaint)
	end

	return luajava.proxyOnDraw(onDraw)
end

local fishView = FishView()

-- 使用 windowManager 模块把View添加到悬浮窗
local windowManager = require('windowManager')

local viewManager = windowManager:bindView(fishView)
viewManager:addView({
	width = 200,
	height = 200,
})

viewManager:setMoveable(true)
gg.setVisible(false)
viewManager:wait()

