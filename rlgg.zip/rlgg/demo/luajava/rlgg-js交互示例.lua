--[[

js调用的函数属于多线程，可以执行gg函数

普通参数必须是字符串
调用参数必须是字符串集合，例如 ['参数1','参数2']

rlgg.call,rlgg.calls 回调函数的第一个参数总是 webView

js里的rlgg有以下方法：

调用RLGG全局函数
1.	rlgg.call
rlgg.call("函数名");

2.	rlgg.calls
带参数调用RLGG全局函数
rlgg.call("函数名",['参数','参数数量理论不限，我没测试过太多']);

3.	rlgg.callMember
调用成员函数，必须带参数
rlgg.callMember('gg','alert',['你好','yes','no']);

4.	rlgg.load
rlgg.load('gg.alert("js执行lua代码")');

5.	rlgg.log
rlgg.log('打印字符串');

6.	rlgg.logs
rlgg.logs(['打印字符串集合','第二个参数']);

]] -- 
local windowManager = require('windowManager')
local LayoutParams = luajava.bindClass('android.view.WindowManager$LayoutParams')
local viweManager

function func(webView)
	gg.alert('hello')
end

function func2(webView, arg1, arg2, ...)
	print('func2')
	print('arg1=', arg1)
	print('arg2=', arg2)
end

_ENV['exit-webView'] = function(webView)
	viweManager:exit()
end

_ENV['login-submit'] = function(webView, user, password)
	-- 演示获取 html 的内容
	gg.alert2('登录', string.format('user:%s\npassword:%s', user, password))

	luajava.post(function()
		-- 解除获取输入法后返回键失灵
		viweManager:getLayoutParams().flags = LayoutParams.FLAG_NOT_FOCUSABLE
		viweManager:updateView()

		-- 返回上一页
		webView:goBack()
	end)
end

_ENV['login-test'] = function(webView)

	-- 如果需要和 view 交互，必须在UI线程，luajava.post属于UI线程
	luajava.post(function()
		-- 允许View获取输入法
		viweManager:getLayoutParams().flags = LayoutParams.FLAG_NOT_TOUCH_MODAL
		viweManager:updateView()

		-- 加载新的页面，也可以用 loadUrl 加载在线网站url，或者本地文件，看个人需求，需要会一点java和 android.webkit.WebView 的知识
		webView:loadData([[
<!DOCTYPE html>
<html>

<head>
	<title>User Login</title>
	<style>
		body {
			font-family: Arial, sans-serif;
			background-color: #f4f4f4;
			margin: 0;
			padding: 20px;
		}

		.login-form {
			max-width: 300px;
			margin: 0 auto;
			background-color: #fff;
			padding: 20px;
			border-radius: 5px;
			box-shadow: 0px 0px 10px rgba(0, 0, 0, 0.1);
		}

		.login-form h2 {
			text-align: center;
		}

		.login-form input[type="text"],
		.login-form input[type="password"] {
			width: 100%;
			padding: 8px;
			margin-bottom: 10px;
			border: 1px solid #ccc;
			border-radius: 4px;
			box-sizing: border-box;
		}

		.login-form button {
			width: 100%;
			background-color: #4CAF50;
			color: #fff;
			padding: 10px;
			border: none;
			border-radius: 4px;
			cursor: pointer;
		}

		.login-form button:hover {
			background-color: #45a049;
		}
	</style>
</head>

<body>
	<div class="login-form">
		<h2>User Login</h2>
		<form>
			<input type="text" id="username" placeholder="Username" required>
			<input type="password" id="password" placeholder="Password" required>
			<button onclick="login()">Login</button>
		</form>
	</div>
</body>

<script type="text/javascript">

	var loginForm = document.getElementById('login-form');
	var usernameInput = document.getElementById('username');
	var passwordInput = document.getElementById('password');

	function login() {
		// 获取文本框和密码框的值
		var username = usernameInput.value;
		var password = passwordInput.value;

		if (username == '' || password == '') {
			return;
		}
		rlgg.calls("login-submit", [username, password]);
	}

</script>

</html>
		]], 'text/html', 'UTF-8')

	end)

end

local webView = luajava.webView(function(webView)
	webView:loadData([[
<!DOCTYPE html>
<html lang="en">

<head>
	<meta charset="UTF-8">
	<title>Title</title>
	<h1>欢迎使用RLGG</h1>
	<input type="button" value="js调用rlgg函数" onclick="test1()">
	<input type="button" value="js执行lua代码" onclick="test2()">
	<input type="button" value="带参数调用成员函数" onclick="test3()">
	<input type="button" value="带参数调用rlgg函数" onclick="test4()">
	<input type="button" value="log打印" onclick="test5()">
	<input type="button" value="登录UI" onclick="login()">
	<input type="button" value="退出" onclick="exit()">
	
</head>

<body>
	<script type="text/javascript">
		function test1() {
			rlgg.call("func");
		}

		function test2() {
			rlgg.load('gg.alert("js执行lua代码")');
		}

		function test3() {
			rlgg.callMember('gg','alert',['你好','yes','no']);
		}

		function test4() {
			rlgg.calls('func2',['参数1','参数2']);
		}

		function test5() {
			rlgg.log("来此rlgg.log");
			rlgg.logs(["1","2","3","rlgg.logs参数是字符串集合"]);
		}

		function login() {
			rlgg.call("login-test");
		}

		function exit() {
			rlgg.call("exit-webView");
		}

	</script>
</body>

</html>
	]], 'text/html', 'UTF-8')

end)

viweManager = windowManager:bindView(webView)
viweManager:show()
viweManager:setMoveable(true)
viweManager:wait()

-- 通常 rlgg 在脚本结束的时候会自动回收 luajava.webView 创建的 webView
luajava.post(function()
	webView:destroy()
end)
