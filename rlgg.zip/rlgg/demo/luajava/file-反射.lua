--[[

利用 luajava 构建一个 file 类库

缺点，不兼容函数重载，原因自己思考一下就知道了

]] --
local Class = luajava.bindClass('java.lang.Class')
local FileClass = luajava.bindClass('java.io.File')

local file = {}

file.new = function(filePath)
	return luajava.new(FileClass, filePath)
end

-- java.lang.reflect.Method[]
local methods = Class.getMethods(FileClass)

for i = 1, #methods do
	local method = methods[i]
	local name = method:getName()

	local function invoke(filePath, ...)
		local File = file.new(filePath)

		-- 反射执行
		return method:invoke(File, {...})
	end

	file[name] = invoke
end

print(file)

print(file.isDirectory('/sdcard/'))

