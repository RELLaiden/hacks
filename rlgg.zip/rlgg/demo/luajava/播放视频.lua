-- 工厂方式创建复用 GradientDrawable layout
local function newGradientDrawableLayout(layout)
	local baseLayout = {
		GradientDrawable,
		cornerRadius = '15dp',
		color = 0x20000000
	}
	return table.copy(baseLayout, layout)
end

local function getVideoView(videoPath)
	local layout = {
		VideoView,
		videoPath = videoPath
	}

	local video = luajava.post(luajava.loadlayout, layout)
	return video
end


-- 缓存URL文件到本地（这是百度上随便找的视频）
local videoPath, err = file.checkUrl('https://baikevideo.cdn.bcebos.com/media/mda-OgieEXY16SVdPBHF/5f63fbe58e4350ac586d4d9c0b20f721.mp4')
if not videoPath then
	error(err)
end

-- 获取视频文件的播放组件
local video = getVideoView(videoPath)

local rootView = luajava.loadlayout({
	LinearLayout,
	orientation = 'vertical',
	background = newGradientDrawableLayout({color=0xffff0000}),
	padding = {'10dp', '20dp', '10dp', '20dp'},
	{
		video
	},
	{
		LinearLayout,
		layout_width = 'match_parent',
		padding = '4dp',
		background = newGradientDrawableLayout(),
		{
			Button,
			layout_weight = 1,
			layout_width = '0dp',
			text = '播放视频',
			background = newGradientDrawableLayout({color=0x00000000}),
			onClick = function()
				video:start()
			end
		},
		{
			Button,
			layout_weight = 1,
			layout_width = '0dp',
			text = '暂停播放',
			background = newGradientDrawableLayout({color=0x10000000}),
			onClick = function()
				video:pause()
			end
		}
	}

})

local alert = luajava.newAlert()
alert:setView(rootView)

-- 会堵塞，有确定按钮
-- gg.showAlert(alert)

-- 不会堵塞，没有确定按钮
luajava.showAlert(alert)

-- 播放视频
video:start()

-- 隐藏GG界面
gg.setVisible(false)