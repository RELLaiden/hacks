--[[

gg.setIcon
https://gitee.com/rlyun/rlgg/blob/master/RLGG%E5%87%BD%E6%95%B0%E5%BA%93%E6%96%87%E6%A1%A3.md#ggseticon


]]


-- 把 RLGG 悬浮窗设置成当前选择的应用的图标
do
	local Attr = {
		imageDrawable = app.loadIcon(gg.getTargetPackage())
	}
	luajava.setFloatingWindowAttr(Attr)
end
