--[[
luajava.getYoYoImpl()

YoYo 是RLGG引入一个github开源项目，主要实现一些View动画

2023/2/9 GitHub - daimajia/AndroidViewAnimations：可爱的视图动画集合。
https://github.com/daimajia/AndroidViewAnimations 1/1

]] --

local data = [[

Hinge , , ,,, RollIn RollOut Landing TakingOff DropOut
弹跳
BounceIn , , , , BounceInDown BounceInLeft BounceInRight BounceInUp
褪色
FadeIn , , , , FadeInUp FadeInDown FadeInLeft FadeInRight
FadeOut , , , , FadeOutDown FadeOutLeft FadeOutRight FadeOutUp
空翻
FlipInX , , FlipOutX FlipOutY
旋转
RotateIn , , , , RotateInDownLeft RotateInDownRight RotateInUpLeft RotateInUpRight
RotateOut , , , , RotateOutDownLeft RotateOutDownRight RotateOutUpLeft RotateOutUpRight
滑
SlideInLeft , , , SlideInRight SlideInUp SlideInDown
SlideOutLeft , , , SlideOutRight SlideOutUp SlideOutDown
缩放
ZoomIn , , , , ZoomInDown ZoomInLeft ZoomInRight ZoomInUp
ZoomOut , , , , ZoomOutDown ZoomOutLeft ZoomOutRight ZoomOutU

]]

local typeList = {}
data:gsub('%u%w+', function(t)
	typeList[#typeList + 1] = t
end)

-- 实际使用只需要填写对应的类型即可，我这里只是演示，所以直接捕捉全部类型
-- 支持的类型
print(typeList)


local YoYoImpl = luajava.getYoYoImpl()

local imageView = luajava.loadlayout({
	ImageView,
	src = 'https://www.baidu.com/img/flexible/logo/pc/result.png'
})

local layout = {
	LinearLayout,
	orientation = 'vertical'
}

for i, text in ipairs(typeList) do
	layout[#layout + 1] = {
		Button,
		text = text,
		onClick = function()
			local typ = text -- 动画类型，来自typeList的遍历
			local view = imageView -- 选择要实现的View，这里的 imageView 是一个图像
			YoYoImpl:with(typ):duration(700):playOn(view)
		end
	}
end

local rootView = luajava.loadlayout({
	LinearLayout,
	orientation = 'vertical',
	{imageView},
	{
		ScrollView,
		layout_margin = '10dp',
		layout
	}
})

local alert = luajava.newAlert()
alert:setView(rootView)

gg.showAlert(alert)
