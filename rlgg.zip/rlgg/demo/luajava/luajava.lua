---@alias varargs ... @可变参数,任意类型任何数量
---@alias varargClass string|java.lang.Class
---@alias proxyMethod table<string, function>
---@alias resid number

---@class luajava
---@field getRunnable fun(run:function):java.lang.Runnable
---@field getMethods fun(className:string):table @java.lang.reflect.Method[]
---@field getThread fun(run:function, name?:string):java.lang.Thread
---@field getHandler fun():android.os.Handler @android.os.Handler(android.os.Looper.getMainLooper())
---@field getObjectField fun(userdata:java.lang.Objec, fieldName:string):any @获取对象字段
---@field getStaticObjectField fun(userdata:java.lang.Class, fieldName:string):any @获取Class静态字段
---@field getFloatingWindow fun():android.widget.ImageView @获取GG悬浮窗的图像
---@field getBitmap fun(src:path|url):android.graphics.Bitmap
---@field getBitmapDrawable fun(src:path|url):android.graphics.drawable.BitmapDrawable
---@field getDrawable fun(src:path|url|res):android.graphics.drawable.BitmapDrawable @支持url或者本地文件或者 getIdentifier的name参数
---@field getResID fun(name:string):resid @从 drawable类型获取的id, return getIdentifier(name, 'drawable')
---@field getIdentifier fun(name:string, defType?:string, defPackage?:string):resid
---@field getIdentifier fun(name:string):resid @ -> @android:drawable/ic_menu_preferences
---@field getIdentifier fun(name:string):resid @ -> ?ic_ui_button_24dp
---@field getIdentifierDrawable fun(name:string, defType?:string, defPackage?:string):android.graphics.drawable.BitmapDrawable
---@field getResBitmap fun(resid:resid):android.graphics.Bitmap @ 通过 getIdentifier 获取id 创建 Bitmap
---@field getResDrawable fun(name:string):android.graphics.drawable.BitmapDrawable @ 通过 getResBitmap 获取 Bitmap 创建 BitmapDrawable
---@
---@field newId fun(name:string):number
---@field getId fun(name:string):number|nil
---@field getIdValue fun(name:string):table|nil @已弃用,推荐使用 getIdView
---@field getIdView fun(name:string):android.view.View|nil
---@
---@field setInterface fun(userdata:java.lang.Object, methodName:string, override:(function|proxyMethod))
---@field setObjectField fun(userdata:java.lang.Objec, fieldName:string, value:any) @设置对象字段
---@field setStaticObjectField fun(userdata:java.lang.Class, fieldName:string, value:any) @设置Class静态字段
---@field setFloatingWindowAttr fun(layout_attr:table) @设置 getFloatingWindow() View 的属性
---@field setFloatingWindowHide fun(hide:boolean) @设置 getFloatingWindow() View 为隐藏,会在脚本结束后自动恢复可见
---@
---@field isMainThread fun():boolean @判断当前线程是main线程
---@field isGGThread fun():boolean @判断当前线程是修改器运行环境的线程
---@field isThread fun():boolean @判断当前线程不是main线程（等于是普通线程）
---@field instanceOf fun(userdata:java.lang.Object, is:java.lang.Class):boolean
---@
---@field iterator fun(data:java.util.Iterator):function @获取lua迭代器
---@field ipairs fun(data:userdata[]):function @获取lua迭代器
---@field astable fun(data:java.util.ArrayList):table @转table
---@field list fun(data:java.util.List):table
---@field array fun(data:java.lang.Object[]):table
---@field iteratorValues fun(data:java.util.Iterator):table @获取迭代器全部值
---@field stringToByte fun(data:string):byte[]
---@field table fun(data:userdata):table @ luajava.table 是通过 luajava.ipairs 遍历出结果
---@
---@field new fun(Class:java.lang.Class, vararg?:any):java.lang.Object
---@field newinstacne fun(Class:java.lang.Class, vararg?:any):java.lang.Object
---@field newByte fun(length:number):byte[]
---@
---@field newAlert fun():android.app.AlertDialog.Builder
---@field showAlert fun(alert:android.app.AlertDialog|android.app.AlertDialog.Builder)
---@field showViewAlert fun(view:android.widget.View) @ newAlert + showAlert
---@field newToast fun(text:string, fast:boolean):android.widget.Toast
---@field showToast fun(toast:android.widget.Toast)
---@field toast fun(text:string, fast:boolean):android.widget.Toast @ newToast + showToast
---@field showViewToast fun(view:android.widget.View):android.widget.Toast @ newToast + showToast
---@
---@field bindClass fun(className:string):java.lang.Class | error @如果没有找到className会返回 false, 异常信息
---@field bindClass2 fun(className:string):java.lang.Class @如果没有找到className会直接抛出异常
---@field startThread fun(run:function, name?:string):java.lang.Thread @启动线程并返回实例
---@field currentThread fun():java.lang.Thread @返回当前线程
---@field threadJoin fun(thread:java.lang.Thread, millis:number, nanos?:number) @当前线程进入堵塞,直到目标线程超时或结束
---@field postMain fun(run:function, vararg:any):any @同步执行UI线程, 返回值是pcall的结果
---@field post fun(run:function, vararg:any):any @如果run执行异常则抛出异常,否则返回run的执行结果
---@field runOnUiThread fun(run:function) @异步执行UI线程,没有返回值,不支持参数,也不会抛出异常
---@field download fun(url:string, path:string, msg?:string):boolean, error
---@field callMethod fun(userdata:java.lang.Objec, methodName:string, vararg:...):any @调用对象方法
---@field callStaticMethod fun(userdata:java.lang.Class, methodName:string, vararg:...):any @调用对象静态方法
---@field webView fun(onCreate:function):android.webkit.WebView @设置Class静态字段
---@
---@field getBlock fun() @已弃用,推荐使用luajava.getLockSupport
---@field setListener fun() @已弃用
luajava = {}

---@alias typemode
---| '0' #byte
---| '1' #char
---| '2' #short
---| '3' #int
---| '4' #long
---| '5' #float
---| '6' #double

---@param type typemode
---@param data string
---@return number
function luajava.numberToJava(type, data) end

---@param vararg string|java.lang.Class
---@param proxyMethod table<string, function>
---@return java.lang.Object
function luajava.createProxy(vararg, proxyMethod) end


---@alias park function @支持后当前线程进入睡眠
---@alias unpark function @解除 park 进入睡眠的线程,可以 unpark 先调用
---@return park, unpark
function luajava.getLockSupport() end


---@class layoutInfo:layout
---@field public 1 java.lang.Class|android.view.View|android.view.ViewGro

---@alias layoutInfos layoutInfo[]
---@param layout layoutInfos
---@param env?table
---@param parent?android.view.ViewGroup
function luajava.loadlayout(layout,env,parent) end
