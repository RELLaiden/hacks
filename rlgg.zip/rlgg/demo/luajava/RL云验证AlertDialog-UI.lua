do
	if type(getrlyunyz) ~= 'function' then
		gg.alert('请使用RLGG执行')
		os.exit()
		return
	end

	local info = {
		name = 'demo',
		appid = '10009',
		appkey = '4u33n332djlniFEF',
		rc4key = 'LgEXia1aAg810009',
		version = '1.0.2',
		mi_type = '3'
	}

	local rlyunyz = getrlyunyz(info)

	local function login(rlyunyz)
		local result

		-- 如果为自动登录，则直接登录
		if rlyunyz.getAutoLogin() then
			return rlyunyz.start()
		end

		-- 验证是否有更新
		local ini = rlyunyz.checkUpdate()

		-- 公告
		local notice = rlyunyz.notice()

		-- 用于同步的锁
		local lock = luajava.getBlock()

		-- android.app.AlertDialog$Builder
		local alert = luajava.newAlert()
		luajava.post(function()
			-- android.app.AlertDialog
			alert = alert:create()
		end)

		-- 获取卡密
		local function getkami()
			local name = 'RL云验证卡密'
			local editText = luajava.getIdView(name)
			if not isUserdata(editText) then
				gg.alert(string.format('%s-控件不存在', name))
				return
			end
			return editText:getText()
		end

		-- 退出弹窗，并结束堵塞
		local function exit()
			alert:dismiss()
			lock('end')
		end

		-- 工厂方式创建复用 GradientDrawable layout
		local function newGradientDrawableLayout(layout)
			local baseLayout = {
				GradientDrawable,
				cornerRadius = '15dp',
				color = 0x20000000
			}
			return table.copy(baseLayout, layout)
		end

		-- 工厂方式创建复用 Button layout
		local function newButtonLayout(layout)
			local baseLayout = {
				Button,
				layout_width = 'match_parent',
				layout_margin = '5dp',
				textSize = '20sp',
				background = newGradientDrawableLayout()
			}

			return table.copy(baseLayout, layout)
		end

		-- 回调事件不能直接执行堵塞函数，需要用线程执行
		local view = luajava.loadlayout({
			LinearLayout,
			orientation = 'vertical',
			background = newGradientDrawableLayout({color = 0xffff0000}), -- 主题颜色
			padding = {'10dp', '20dp', '10dp', '20dp'},
			{
				EditText,
				layout_width = 'match_parent',
				layout_margin = '5dp',
				hint = '请输入您的卡密',
				id = luajava.newId('RL云验证卡密'),
				background = newGradientDrawableLayout()
			},
			{
				CheckBox,
				layout_width = 'match_parent',
				layout_margin = '5dp',
				text = '自动登录',
				onCheckedChange = function(CompoundButton, state)
					rlyunyz.setAutoLogin(state)
				end
			},
			newButtonLayout({
				text = '登录',
				onClick = function()
					local function func()
						local km = getkami()
						local res = rlyunyz.login(km)
						if res then
							result = res
							exit()
						end
					end
					luajava.startThread(func)
				end
			}),
			newButtonLayout({
				text = '解绑',
				onClick = function()
					local function func()
						local km = getkami()
						rlyunyz.unbind(km)
					end
					luajava.startThread(func)
				end
			})
		})
		alert:setView(view)

		-- 弹窗被取消
		alert:setOnDismissListener(luajava.createProxy('android.content.DialogInterface$OnDismissListener', {
			onDismiss = function()
				exit()
			end
		}))

		-- 异步显示弹窗
		luajava.showAlert(alert)

		-- 堵塞，等待异步弹窗结束
		lock('join')

		return result
	end

	local ret = login(rlyunyz)
	if not ret or not isTable(ret) or ret.sign ~= 'e1d68b2eafaba91b16e15bb07c8faa41' then
		os.exit()
		return
	end
end
-- 把以上代码复制到你脚本最前面即可

gg.alert('欢迎RLGG')

