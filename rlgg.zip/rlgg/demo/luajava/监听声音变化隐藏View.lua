--[[

setOnAudioListener(android.content.BroadcastReceiver#onReceive)

onReceive回调属于UI线程，不能执行gg类库函数（带堵塞的）



]] -- 通过监听音量设置View的可见
function fromAudioSetVisibility(view)

	-- setOnAudioListener 是rlgg自带的
	setOnAudioListener(function(context, intent)
		view:setVisibility(view:isShown() and view.GONE or  view.VISIBLE)
	end)

end

local windowManager = require('windowManager')
local viewManager

local button = Button(context)
button:setText('当按下声音键时，如果View在显示中则隐藏，否则显示')

fromAudioSetVisibility(button)

viewManager = windowManager:bindView(button)
viewManager:setMoveable(true)
viewManager:show()
viewManager:wait()

