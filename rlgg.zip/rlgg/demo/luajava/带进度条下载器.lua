local url = 'https://downv6.qq.com/qqweb/QQ_1/android_apk/Android_8.9.71_64.apk'
local path = gg.EXT_STORAGE .. url:match('/[^/]+$')
local msg = '正在下载QQ，请稍后...' .. '\n' .. path
local ok, err = luajava.download(url, path, msg)
if not ok then
	error('下载失败：' .. err)
end
