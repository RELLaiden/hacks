local items = {'苹果', '西瓜', '花蜜瓜', '香蕉', '雪梨'}
local inputs = gg.searchChoice(items, '标题')

if not inputs then
	gg.alert('你取消了操作')
	os.exit()
end

for i, _ in pairs(inputs) do
	print('你选择了', i, items[i])
end
