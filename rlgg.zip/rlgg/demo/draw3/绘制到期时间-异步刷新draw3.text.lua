local function drawExpireTime(time)
	local draw3 = require('draw3')

	local text1 = draw3.text('', 10, 100)
	text1.setColor('#ff0000')

	luajava.startThread(function()
		local time = time - os.time()

		while true do
			local D = time // (60 * 60 * 24)
			local H = time // (60 * 60) % 24
			local M = time // 60 % 60
			local S = time % 60

			local text
			if D > 0 then
				text = string.format('%d天%d小时%d分%d秒后到期', D, H, M, S)
			elseif H > 0 then
				text = string.format('%d小时%d分%d秒后到期', H, M, S)
			elseif M > 0 then
				text = string.format('%d分%d秒后到期', M, S)
			elseif S > 0 then
				text = string.format('%d秒后到期', S)
			else
				local thread = luajava.startThread(function()
					gg.alert('您的会员已到期，请及时续费')
				end)

				-- 堵塞十秒
				luajava.threadJoin(thread, 1000 * 10)

				-- 退出程序而不是 os.exit 退出脚本
				app.exit()
			end

			text1.update(text)
			time = time - 1
			gg.sleep(1000)
		end
	end)

end

-- 24小时后到期
-- drawExpireTime(os.time() + (60 * 60 * 24))

-- 70秒后到期
-- drawExpireTime(os.time() + 70)

do
	if type(getrlyunyz) ~= 'function' then
		gg.alert('请使用RLGG执行')
		os.exit()
		return
	end

	local info = {
	    example_version = '1.0.3',
		name = 'demo',
		appid = '10009',
		appkey = '4u33n332djlniFEF',
		rc4key = 'LgEXia1aAg810009',
		version = '1.0.3',
		mi_type = '3'
	}

	local rlyunyz = getrlyunyz(info)
	local ret = rlyunyz.start()
	if not ret or not isTable(ret) or ret.sign ~= 'e1d68b2eafaba91b16e15bb07c8faa41' then
		os.exit()
		return
	end

	drawExpireTime(ret.vip)
end

-- 以上都是示例，都不重要，重要的是调用 drawExpireTime 传入到期时间戳即可，10位数的


-- 模式正常脚本的堵塞
while true do
end
