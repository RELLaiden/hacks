--[[

1.在RLGG-APK配置
resources.arsc>ID定位资源>0x7f0d0008>把内容改为1即可

]] --

--[[
2.执行 gg.setProcessX 弹出选择进程
gg.setProcessX()
不建议在纯脚本中使用，如果非要用，应该写在UI中让用户点击后弹出选择进程

]] --

--[[
3.执行 gg.setProcess 设置进程

]] --

local pkg = '包名'
gg.setProcess(pkg)
if gg.getTargetPackage() ~= pkg then
	gg.alert2('请先运行进程', pkg)
	os.exit()
	return
end

--[[
4.执行 checkPkg 选择进程

推荐在开启功能之前，先验证一下包名是否正确，这样就不会因为进程没选对而导致异常了

]] --

checkPkg({'包名1', '包名2'})