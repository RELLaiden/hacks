--[[

drawManager 比起 draw 类库有哪些优势？
解决安卓12及以上版本的绘制无法穿透点击事件问题
绘制内容完全自己实现，可控度更高，可定制更丰富，效率更高

]] -- 
local windowManager = require('windowManager')
local drawManager = windowManager:newDrawManager()

function starsView()
	local paint = Paint()
	paint:setAntiAlias(true)
	paint:setStrokeWidth(3)
	paint:setColor(Color.WHITE)
	paint:setStyle(Paint.Style.STROKE)

	local path = Path()

	local view
	view = drawManager:onDraw(function(canvas)
		local centerX = view:getWidth() / 2
		local centerY = view:getHeight() / 2
		local size = math.min(centerX, centerY) - 20

		path:reset()

		local angle = 2 * math.pi / 6
		local radius = size / 2

		for i = 0, 6 do
			local startX = centerX + radius * math.cos(i * angle)
			local startY = centerY + radius * math.sin(i * angle)
			local endX = centerX + radius * math.cos((i + 2) * angle)
			local endY = centerY + radius * math.sin((i + 2) * angle)

			path:moveTo(startX, startY)
			path:lineTo(endX, endY)
		end

		canvas:drawPath(path, paint)
	end)
	return view
end

-- 自己画
-- 不需要参数的话，可以一行代码绘制到屏幕
drawManager:bindView(starsView()):show()

-- 绘制文本
-- text1DrawManager 是这个 bindView 的管理对象
local text1DrawManager
text1DrawManager = drawManager:bindView(function(canvas)
	local paint = text1DrawManager:getTag('paint')
	if not paint then
		paint = Paint()
		paint:setColor(0xffff0000)
		paint:setTextSize(40)
		text1DrawManager:setTag('paint', paint)
	end

	canvas:drawText(tostring(os.time()), 100, 100, paint)

	-- 1秒后刷新。1000ms = 1s
	text1DrawManager:postInvalidateDelayed(1000)
end)
text1DrawManager:show()

-- 也可以用原生的View
local bt = Button(context)
bt:setText('Button')

local btDrawManager = drawManager:bindView(bt)
btDrawManager:addView({
	x = 200,
	y = 200
})
btDrawManager:setBackgroundColor(0xffff0000)

-- 进入睡眠，等唤醒或者脚本结束
drawManager:park()
