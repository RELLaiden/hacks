local cglib = require('cglib')

local o = cglib.createInterceptor(Object, {'toString', 'equals'}, function(thisObject, param, methodProxy)
	print('拦截', methodProxy:getMethodName())

	if methodProxy:getMethodName() == 'toString' then
		return 'cglib.createInterceptor：修改了toString的返回值'
	end

	return methodProxy:invokeSuper(thisObject, param)
end)

print(luajava.instanceOf(o, Object))
print(o:toString())

local o = cglib.createProxy(Object, {
	toString = function()
		return 'cglib.createProxy：修改了toString的返回值'
	end,
	equals = function(o)
		return false
	end
})

print(o:toString())
print(o:equals(o), '被拦截了强制返回false')
