# AndroidViewAnimations

## 介绍

AndroidViewAnimations 是一个引入github开源项目的模块 

https://github.com/daimajia/AndroidViewAnimations





## 使用方法

使用 dex.getYoYoImpl 方法加载dex模块（从云端下载）

具体类名 rlyun.modules.animation.YoYoImpl

YoYo会依赖 androidx，因此加载dex时，会把androidx作为父加载器来实例化 YoYo 的 dalvik.system.DexClassLoader



进一步封装成 luajava.getYoYoImpl

~~~lua
luajava.getYoYoImpl = functions.singleton(function()
	local loader = dex.getYoYoImpl()
	return loader:loadClass('rlyun.modules.animation.YoYoImpl')
end)
~~~



 使用示例请看 [View动画.lua](../../../demo/luajava/View动画.lua) 



如果需要设置监听事件，可以使用 luajava.getYoYoCallback 创建回调对象



>luajava.getYoYoCallback

| 参数名   | 类型     | 说明     | 返回值类型                                                   |
| -------- | -------- | -------- | ------------------------------------------------------------ |
| callback | function | 回调函数 | com.daimajia.androidanimations.library.YoYo$AnimatorCallback |

