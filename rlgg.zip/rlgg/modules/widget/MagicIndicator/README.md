# MagicIndicator

## 介绍

MagicIndicator 是一个引入github开源项目的模块 

https://github.com/hackware1993/MagicIndicator





## 使用方法

使用 dex.getMagicindicator 方法加载dex模块（从云端下载）

具体类名 rlyun.modules.widget.ViewPagerMagicIndicator



~~~lua
-- 加载 Magicindicator 依赖

-- dalvik.system.DexClassLoader
local Magicindicator = dex.getMagicindicator()
local classname = 'rlyun.modules.widget.ViewPagerMagicIndicator'
local ViewPagerMagicIndicatorClass = Magicindicator:loadClass(classname)

~~~



由于lua不能直接继承java类，所以我编写了一个java的适配器类，在lua实现代理

ViewPagerMagicIndicator 内部有个 BaseImpl 接口，创建 ViewPagerMagicIndicator  必须把 BaseImpl 实现后作为构造参数进行创建



对象 = 创建 ViewPagerMagicIndicator(实现 ViewPagerMagicIndicator.BaseImpl)



> ViewPagerMagicIndicator.BaseImpl

| 方法名称        | 是否必须 | 返回值类型                         | 说明                 |
| --------------- | -------- | ---------------------------------- | -------------------- |
| getCount        | 是       | number                             | 项目的总数量         |
| getTitleView    | 否       | android.view.View                  | 个体项目标题         |
| getIconDrawable | 否       | android.graphics.drawable.Drawable | 个体项目标题图标     |
| getContextView  | 是       | android.view.View                  | 个体项目具体显示内容 |



进一步的封装请看  [luajava.getViewPagerMagicIndicator.lua](../../../src/luajava/luajava.getViewPagerMagicIndicator.lua)

 使用示例请看 [底部导航-页面布局.lua](../../../demo/luajava/底部导航-页面布局.lua) 

