--[[

利用 luajava 构建一个 string 类库

缺点，不兼容函数重载，原因自己思考一下就知道了

]] --
local jstring = {}

local Class = luajava.bindClass('java.lang.Class')
local StringClass = luajava.bindClass('java.lang.String')

-- java.lang.reflect.Method[]
local methods = Class.getMethods(StringClass)

for i = 1, #methods do
	local method = methods[i]
	local name = method:getName()

	-- 如果 jstring 对应的 name 不等于 nil，说明已经有了，则当前的属于方法重载，就忽略它
	if jstring[name] == nil then

		local function invoke(s, ...)
			-- 变量 s 类型为 string，反射会自动转换成 java.lang.String，其它类型则可能转换失败，抛出异常

			-- 如果 s 类型为 number 则帮忙转换一下，否则也会异常，其它的类型则不管它，让它异常就好了
			if type(s) == 'number' then
				s = tostring(s)
			end

			-- 反射执行
			return method:invoke(s, {...})
		end

		jstring[name] = invoke

	end
end

-- java.lang.String.split 返回的是 java.lang.String[] 不利于在 lua 使用，因此需要修复一下
local func = jstring.split
jstring.split = function(...)
	local list = func(...)
	local t = {}
	for i = 1, #list do
		t[i] = tostring(list[i])
	end
	return t
end

print(jstring)

local url = 'https://gitee.com/rlyun'

-- 判断字符串开头是否为 http
print(jstring.startsWith(url, 'http'))
print(jstring.startsWith(123456, 'http'))

-- 判断字符串结尾是否为 rlyun
print(jstring.endsWith(url, 'rlyun'))

-- 分割字符串
print(jstring.split(url, '/'))
