--[[
该函数已内置到 RLGG string.crc32



需要用到

java.util.zip.CRC32
update(byte[] b)

在 rlgg 中，string 类型可以可以自动转 byte[]

]] --
-- 获取字符串CRC
local function crc32(content)
	local instance = luajava.newInstance('java.util.zip.CRC32')
	instance:update(tostring(content))
	return instance:getValue()
end

local res = crc32('RLGG')
print(res, string.format('0x%x', res))

