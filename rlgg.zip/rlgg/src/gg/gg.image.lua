-- 该函数已经内置到 RLGG gg.image

local function image(src, msg)
	local layout = {
		ScrollView, -- android.widget.ScrollView
		padding = '4dp',
		{
			ImageView, -- android.widget.ImageView
			src = src -- src可以是云资源或者本地文件
		}
	}

	local alert = gg.newAlert(nil, msg)
	local view = luajava.loadlayout(layout)
	alert:setView(view)

	-- 使用 gg.showAlert 会和 gg.alert 一样进行堵塞
	return gg.showAlert(alert)
end

gg.image('https://i0.hdslb.com/bfs/article/73e6e9c0e8672ec87fddc268c4d836dcd1562768.jpg@942w_1331h_progressive.webp')
