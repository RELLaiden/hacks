-- 该函数已经内置到 RLGG gg.htmlAlert

local function htmlAlert(title, msg, ...)
	if isString(title) then
		title = string.fromHtml(title)
	end

	if isString(msg) then
		msg = string.fromHtml(msg)
	end

	local alert = gg.newAlert(title, msg)
	return gg.showAlert(alert, ...)
end

-- 测试

-- 标题和显示内容均为html文本格式
title = "<font color='#70f3ff'>title</font>"
message = "<font color='#FFFF00'>Test</font>"
gg.htmlAlert(title, message, "加入", "取消", "犹豫")
-- 五个参数
-- 标题、文本、积极按钮、消极按钮、中立按钮

-- 正确用法
gg.htmlAlert(title, message, "积极按钮", "消极按钮", "中立按钮")
gg.htmlAlert(nil, message, "加入", "取消", "犹豫")
gg.htmlAlert(title, message)
gg.htmlAlert("提示：", "你正在测试脚本！")
gg.htmlAlert(nil, "Test")

html = gg.makeRequest("https://www.runoob.com/w3cnote/htmlcss-make-a-website.html").content

gg.htmlAlert(nil, html)
-- 初前面多了个自定义标题外，其他与原版无差异

-- 错误用法
-- gg.htmlAlert(message,"加入","取消","犹豫")
