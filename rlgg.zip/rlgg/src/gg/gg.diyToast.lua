-- 该函数已经内置到 RLGG gg.diyToast

local function diyToast(text, textColor, backgroundColor)
	text = tostring(text) -- 显示的文本
	textColor = tonumber(textColor) -- 文本的颜色数值
	backgroundColor = tonumber(backgroundColor) -- 背景的颜色数值

	local TextView = TextView -- android.widget.TextView

	-- TextView 的属性
	local layout = {
		TextView,
		text = text,
		textColor = textColor,
		backgroundColor = backgroundColor
	}

	-- 属性不单单支持这几个，具体参考 android.view.View 的属性

	return luajava.layoutToast(layout)
end

diyToast('null', 0xffff0000, nil)



-- 支持覆盖前面的 Toast
gg.diyToast('欢迎使用RLGG！', nil, nil)

