--[[

利用 luajava 构建一个 file 类库

这个比反射的更好，支持方法重载，底层 luajava 会自动处理转换
]] --
local Class = luajava.bindClass('java.lang.Class')
local FileClass = luajava.bindClass('java.io.File')

local file = {}

file.new = function(filePath)
	return luajava.new(FileClass, filePath)
end

-- java.lang.reflect.Method[]
local methods = Class.getMethods(FileClass)

for i = 1, #methods do
	local method = methods[i]
	local name = method:getName()

	-- 获取 luajava 创建的 function
	local func = FileClass[name]
	if type(func) == 'function' then

		local function invoke(filePath, ...)
			local File = file.new(filePath)
			return func(File, ...)
		end

		file[name] = invoke
	end
end

print(file)

print(file.isDirectory('/sdcard/'))

