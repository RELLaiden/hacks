# 玩gglua好低级？那是在使用 RLGG 前的事

RLGG是基于 [GameGuardian.101.0](https://gameguardian.net/) 优化的修改器，其 极致安全的加密，极简易用的API，丰富的内置功能，超小的体积，让无数玩GG的作者喜爱，并被持续口碑传递



[TOC]



[下载最新版](https://gitee.com/rlyun/rlgg/releases/latest)

[查看历史版本](https://gitee.com/rlyun/rlgg/releases)

[内置一体化/加密-录屏教程](https://lanzoux.com/igrKE0t7sssb)

[使用说明](#使用说明)

[常见问题](#常见问题fqa)

[联系我](https://qm.qq.com/cgi-bin/qm/qr?k=ACzLUSy9JXJkRRKRe6tZ5zvvLXGLcIJC&noverify=0&personal_qrcode_source=3)



# 友情链接

- **[RL云验证][]** 
- **[RL网盘][]**



# 主要功能

- 运行lua脚本

- 读写app内存

- [无障碍点击屏幕](https://gitee.com/rlyun/rlgg/blob/master/RLGG%E5%87%BD%E6%95%B0%E5%BA%93%E6%96%87%E6%A1%A3.md#app)

- [执行shell命令(终端模拟器)](https://gitee.com/rlyun/rlgg/blob/master/RLGG%E5%87%BD%E6%95%B0%E5%BA%93%E6%96%87%E6%A1%A3.md#newshell)

- lua加密

- [悬浮窗绘制](https://gitee.com/rlyun/rlgg/blob/master/RLGG%E5%87%BD%E6%95%B0%E5%BA%93%E6%96%87%E6%A1%A3.md#draw)

- [luajava](https://gitee.com/rlyun/rlgg/blob/master/RLGG%E5%87%BD%E6%95%B0%E5%BA%93%E6%96%87%E6%A1%A3.md#luajava)

- [加载外部dex，jar文件](https://gitee.com/rlyun/rlgg/blob/master/RLGG%E5%87%BD%E6%95%B0%E5%BA%93%E6%96%87%E6%A1%A3.md#dex)

- 加载动态lua layout布局

- [网络验证][RL云验证],免费注册,0门槛对接

  

# 防火墙

#### classes.dex校验

> RLGG自带

攻击者无法从安装包篡改java层内容



#### classes.dex混淆

> RLGG自带

攻击者无法使用通用型第三方hook 攻击RLGG，因为luaj的类名被混淆成其它类名

举个例子，假如市面流行一款可以通杀官方GG的hook软件，那么它很有可能对RLGG无效



#### classes.dex加固

> RLGG自带

部分java转二进制，干扰攻击者分析铭感信息，降低被攻击的风险



#### Application校验

> RLGG自带

攻击者无法对RLGG注入，例如绕过SIGN签名校验



#### apk文件防伪装

> RLGG自带

对抗攻击者绕过 [安装包MD5校验](#安装包md5校验)



#### 安装包MD5校验

> 收费加密自带，或手动配置

攻击者无法从安装包篡改任意内容



#### RLGG的SIGN签名校验

> 收费加密自带，或手动配置

进一步提升安全性，更好的保护安装包不被篡改

例如 安装包MD5校验 被攻击者绕开了，那么SIGN这一关很有可能将他挡下，两者配合才完美



#### Lua层的函数防重写

> RLGG自带

攻击者无法在Lua层进行hook，log



#### 运行环境检测

>RLGG自带

RLGG运行时，会先判断运行环境是否存在已知的威胁行为，如果存在则不给予运行



#### 网络抓包检测

> RLGG自带

脚本访问网络时，RLGG自动检测抓包行为



#### 防log机制A

>RLGG自带

重写gg原生写法

例如你执行的是 gg.editAll，RLGG给你用其它等价（gg.setValues）技术实现

例如你执行的是 gg.setValues，RLGG也可以用其它等价技术实现

当然不止以上举例的函数，大部分gg函数都进行了保护



#### 防log机制A-2

>RLGG自带

RLGG使用加密通道和java传递数据

数据传递流程 RLGG>MITM>JAVA

MITM指的是中间人（攻击者）

当 MITM 拦截了 RLGG和Java传递的数据，那么得到的只是无效密文，该密文不存在意义，无法在正常GG使用



#### 防log机制A-3

>RLGG自带

RLGG和Java传递数据时，注入大量数据干扰log

例如原本只是传递一个 ”1“ 这个字符串，RLGG则会追加1个G的数据，如果攻击者把这个G的数据打印log啥的，就会卡死



#### 防log机制B

>RLGG自带

杜绝通杀型hook



#### 防脱机保护

> 付费版自带

攻击者无法修复加密文件，使其可以在普通GG运行



#### 防劫持保护

> 付费版自带，新版加密（>=1.0.3）才支持，建议使用新版加密，否则不安全(被绕过检测)

攻击者无法绕开以上大部分检测/机制



#### 检测xposed环境

> 收费版可选

大幅度提升防hook能力



#### 检测框架环境

> 收费版可选

不允许运行在框架，配合杀死其它GG



#### 检测其它GG

> 收费版可选

极端保护，杜绝99.999999%被其它GG模糊



#### 检测ROOT环境

> 收费版可选

只允许运作在ROOT环境，配合 [检测框架环境](#检测框架环境) 效果更好 



#### QQ黑名单

> 收费版可选

可拉黑指定QQ，RLGG检测到黑名单不给与运行



#### 杀死其它GG

> 收费版可选

不允许同时运行其它GG，如果需要更强力的检测，请用 [检测其它GG](#检测其它gg)




#### 防xposed-hook机制

>付费版自带

该功能非常强大，杜绝99.999的hook，于2023/1/29实现





> 如你所见，RLGG拥有非常多的保护机制，而且不断地更新研发，望多多支持！
>
> 还有一些检测机制是没有介绍的，收费版一定更安全！






# 加密介绍

[**点击跳转**](https://gitee.com/rlyun/rlgg/blob/master/RLGG%E5%8A%A0%E5%AF%86%E5%A5%97%E9%A4%90%E4%BB%8B%E7%BB%8D.md)



# 函数文档

[**点击跳转**](https://gitee.com/rlyun/rlgg/blob/master/RLGG%E5%87%BD%E6%95%B0%E5%BA%93%E6%96%87%E6%A1%A3.md)



# 下载

https://gitee.com/rlyun/rlgg/releases



| 版本名称                                                  | 可用   | 加固       | apk共存 | X86架构 | 框架 | [X8沙箱](https://zh.x8sb.com/) | [雷电模拟器](https://www.ldmnq.com/) | [网易模拟器](https://mumu.163.com/) | 说明 |
| --------------------------------------------------------- | ------ | ---------- | ------- | ------- | ---- | ------------------------------ | ------------------------------------ | ----------------------------------- | ---- |
| [1.8.8](https://lanzoux.com/iYfdt08a62kh)                 | 已弃用 |            | ✔️       | ✔️       | ✔️    | ✔️                              | ✔️                                    | ✔️                                   |      |
| [1.8.9](https://gitee.com/rlyun/rlgg/releases/tag/v1.89)  | 已弃用 | 360        | ❌       | ❌       | ❌    | ✔️                              | ✔️                                    | ✔️                                   |      |
| [2.0.1](https://gitee.com/rlyun/rlgg/releases/tag/v2.0.1) | 已弃用 | 腾讯御安全 | ✔️       |         | ✔️    | ❌                              | 9.0<=                                | ❌                                   |      |
| [2.0.2](https://gitee.com/rlyun/rlgg/releases/tag/v2.0.2) | 已弃用 | 360        | ❌       | ✔️       | ❌    | ✔️                              | ✔️                                    | ✔️                                   |      |
| [2.0.3](https://gitee.com/rlyun/rlgg/releases/tag/v2.0.3) | 已弃用 | DEX保护    | ✔️       | ✔️       | ✔️    | ❌                              | ✔️                                    | ❌                                   |      |
| [2.0.4](https://gitee.com/rlyun/rlgg/releases/tag/v2.0.4) | 已弃用 | DEX保护    | ✔️       | ✔️       | ✔️    | ❌                              | ✔️                                    | ✔️                                   |      |
| [2.0.5](https://gitee.com/rlyun/rlgg/releases/tag/v2.0.5) | 已弃用 | DEX保护    | ✔️       | ✔️       | ✔️    | ✔️                              | ✔️                                    | ✔️                                   |      |
| [2.0.6](https://gitee.com/rlyun/rlgg/releases/tag/v2.0.6) | ✔️      | DEX保护    | ✔️       | ✔️       | ✔️    | ✔️                              | ✔️                                    | ✔️                                   |      |
| [2.0.9](https://gitee.com/rlyun/rlgg/releases/latest)     | ✔️      | DEX保护    | ✔️       | ✔️       | ✔️    | ❌                              | ✔️                                    | ✔️                                   | 稳定 |



- 数据仅供参考,不一定准确哦

- 不在该列表里面的版本不推荐使用

  > 已弃用说明

  为什么会出现弃用？

  因为旧版的域名被**中国移动**节点屏蔽了，因此大部分移动的用户都无法访问RLGG的服务。

  电信，联通正常

  


# 安装指南

## 已获取ROOT权限

1. [下载](https://gitee.com/rlyun/rlgg/blob/master/README.md#%E4%B8%8B%E8%BD%BD)后安装好rlgg
2. 通过**应用详细**来到rlgg的**权限管理**,允许**显示悬浮窗**
3. 打开rlgg,允许root权限



## 没有获取ROOT权限

### 通过框架

1. [下载](https://gitee.com/rlyun/rlgg/blob/master/README.md#%E4%B8%8B%E8%BD%BD)后安装好rlgg
2. 安装一个框架,比如[双开助手](https://www.multiopen.cn/)
3. 通过**应用详细**来到框架的**权限管理**,允许**显示悬浮窗**
4. 打开框架,把rlgg添加到框架
5. 在框架内打开rlgg



### 通过虚拟机

不推荐,性能不好,会比较卡





# 使用说明



## 内置/云更新/视频教程

[RL网盘](https://gitee.com/rlyun/rlgg/tree/master/RL%E7%BD%91%E7%9B%98)

[RL网盘/加密使用-录屏教程](https://lanzoux.com/igrKE0t7sssb)





## 函数说明

[点击跳转 **函数库文档**](https://gitee.com/rlyun/rlgg/blob/master/RLGG%E5%87%BD%E6%95%B0%E5%BA%93%E6%96%87%E6%A1%A3.md)



## 内置教程

把内置代码[设置到对应的资源ID即可](https://gitee.com/rlyun/rlgg/blob/master/README.md#%E8%B5%84%E6%BA%90id)



## 加密说明

1. 需要做好以下准备
   - [最新版RLGG](https://gitee.com/rlyun/rlgg/releases)
   - [共存后的RLGG](https://lanzoux.com/b0858bzfi)
   - [RLGG工具箱](https://lanzoux.com/if7VR0b52wxe)
   - 网盘工具,通常运行**RLGG工具箱**之后就可以看到
   - 加密工具,通常运行**RLGG工具箱**之后就可以看到
   - [视频教程](https://lanzoux.com/iTfNe0b52ooh)
2. 必须先看一遍**加密教程**
3. 使用**RLGG**打开**网盘工具**,登录账户,创建项目(**不需要上传**),获取内置代码,并且进行内置,安装完成后的RLGG
   - 通常是内置在**共存后的RLGG**
4. 使用RLGG打开"加密工具",设置配置
   - 加密后RLGG不能有任意变动,否则会触发第8条
   - MD5校验必开,输入共存的包名(一定要安装在和加密同一个环境),或者输入内置后的文件路径
   - 全局混淆和JMP混淆,看情况,如果你的加密支持那就开,不支持就不需要开(不支持开了也不会有效)
   - 其它的看情况,不懂的就不要开
5. 设置配置好了之后,选择你要加密的文件,点击开始加密等待完成
6. 使用RLGG运行"网盘工具",选择你的应用,点击上传更新,上传加密后的文件
7. 以后的云更新,只需要重新加密并且上传更新即可
8. 如果RLGG变动了会导致MD5校验失败,则需要重新更新(云更新为4-6条)



> 设置配置的作用

1. 全局混淆  (强度适中  以上级别才支持)

   - 源码层的混淆,可靠度非常高,非常难以还原
2. jmp混淆 (安全度极高)

   - 字节码层的混淆,无解
3. MD5校验 (必开)

   - 保护你的修改器不被篡改,比如在你发布后,别人想改一下你RLGG的软件名称,那么改动后的软件就无法行你的脚本了修改器的任意改动都会导致MD5校验失败
4. SIGN校验

   - 保护apk签名一致,通常apk在改动之后都需要进行签名才能安装,第三者在改动你的RLGG之后,如果要安装,就需要签名,签名就会覆盖apk原来的签名(原来的签名是你发布时候的)
   - 在签名相同的情况下,SIGN校验不会触发,比如你发布的时候使用的是MT管理器自带的签名,并且第三者也是用MT管理器自带的签名,那么即便第三者改了你的修改器,也不会触发SIGN校验所以要开SIGN就必须用自己独有的签名

> 其它的不是很重要,可以根据自己的需求去部署





## 注意事项

- 加密使用的RLGG版本最好是和内置使用的RLGG版本一样,否则可能不兼容,比如内置用的版本是1.80,那么加密不可以用版本大于1.80的

- 一定是内置完了才加密的,加密后再内置一定会校验失败

- 内置用的RLGG通常是共存后的



# 常见问题(FQA)

#### 如何获取RLGG的MD5

> - 进入MT管理器》长按安装包文件》属性》校验》即可看到MD5
>
> - 打开RLGG运行任意lua脚本(可以是空文件)，结束后控制台会输出当前RLGG的MD5



#### 如何使用自己的SIGN进行签名

> 在MT管理器点击需要签名的apk,选择"功能",选择"APK签名",选择"更多",选择"导入签名",选择"生成秘钥",然后根据MT的提示去操作



#### 如何获取RLGG的SIGN签名信息

> 在MT管理器点击需要签名的apk,选择"签名状态右边的灰色字体",在格式里取消"添加冒号",RLGG校验用的是MD5



#### RLGG校验用的MD5是大写还是小写

> RLGG校验用的MD5对大小写不敏感，都通用，MD5必须是32位



#### 如何共存RLGG（改包名）

> 进入MT管理器》点击共存的apk文件》功能》APK共存》输入包名》确定
>
> 必须选择**使用旧版方案**



#### RLGG共存后无法打开如何解决

> 打开共存后的RLGG闪退，白屏，则是共存的时候没有选择旧版方案，导致classes.dex文件变动了，无法通过校验，因此无法正常运行，或者该版本不支持共存



#### RLGG加密后提示"MD5校验失败"如何解决

> 内置好之后重新加密，在加密工具箱的设置配置MD5校验中，输入内置后的MD5，参考 **常见问题 >[如何获取RLGG的MD5](#如何获取rlgg的md5)**
>
> 一定是内置后再加密，否则加密后再内置会改变MD5，就会导致MD5校验失败



#### 为什么加密特别慢(大于3分钟)

> 这种情况一般说明你在虚拟机使用RLGG，所以会很卡，请使用框架或者真机进行加密



#### 如何修改apk图标

> 在[NP管理器](https://www.baidu.com/s?ie=UTF-8&wd=NP%E7%AE%A1%E7%90%86%E5%99%A8)点击apk文件，选择**功能**，选择**通用编辑**，选择**App Icon**



#### 如何修改RLGG主页背景

> 做不到，因为RLGG没有主页



#### 如何更改RLGG软件名称

#### 如何取消RLGG自动运行脚本

> 请在 [资源ID](#资源id) 查看









# 资源ID

> 0/1表示0或1,为1的时候,表示开启

| 资源名称     | 类型   | ID         | 默认           | 说明                   |
| ------------ | ------ | ---------- | -------------- | ---------------------- |
| RLGG名称     | string | 0x7F070357 | RLGG{-version} | app名称                |
| 专属内置代码 | string | 0x7F070354 |                | 开启辅助执行的内置脚本 |
| 外链内置代码 | string | 0x7F070355 |                | 开启辅助执行外链的脚本 |
| 弹出选择进程 | 0/1    | 0x7F0D0008 | 0              | 手动选择进程           |
| 自动运行     | 0/1    | 0x7F0D0009 | 1              | 打开app时自动运行内置  |



## 如何设置资源ID对应的值

1. 使用MT管理器打开app/resources.arsc

   > 打开方式为**Arsc编辑器**

2. 选择**ID定位资源**

3. 输入ID之后**确定**即可定位到对应的资源

4. 点击资源即可编辑其**内容**

5. 编辑完成之后选择**确定**,一路返回**保存退出**即可

   > 反正就是一直点确定,直到完成



# 离线资源

## [raw](https://lanzoux.com/ioe9J0b4c4jg)

| 离线类型            | 需要版本 | 资源目录      | 资源文件名 | 说明                            |
| ------------------- | -------- | ------------- | ---------- | ------------------------------- |
| 内置到apk安装包(优) | >=1.8.9  | apk/res/raw/  | ydwraw     | 打开rlgg后自动释放资源          |
| 内置到apk安装包(劣) | 全部     | apk/assets/   | raw        | 运行脚本后释放资源,并且重启软件 |
| 手动下载            | 全部     | /sdcard/rlgg/ | raw        |                                 |
| 自动下载            | 全部     | /sdcard/rlgg/ | raw        |                                 |

> 如果下载的raw是.zip后缀,需要手动把后缀删掉,必须和以上列表对应的**资源文件名**一致



### 内置到apk安装包

> 在MT管理器把RLGG反资源混淆后,把raw文件添加到 apk/res/raw/ydwraw

- 优点 : 不需要另外下载
- 缺点: 安装包内存大



### 手动下载

> 把raw添加到 /sdcard/rlgg/raw

- 优点 : 安装包文件小
- 缺点: 对小白用户不友好



### 自动下载（默认）

> 打开RLGG之后,自动下载

- 优点 : 傻瓜式,不需要操作
- 缺点: 可能有时候下载速度较慢







# 联系我

<img src="https://mail.qq.com/zh_CN/htmledition/images/favicon/qqmail_favicon_96h.png" style="zoom:25%;" />	507522729@qq.com



[![](https://qzonestyle.gtimg.cn/qzone/qzact/act/external/tiqq/logo.png)添加我QQ好友](https://qm.qq.com/cgi-bin/qm/qr?k=M7zYPfDrxp3_Yom63mrGq8-ukUc62Qho&noverify=0&personal_qrcode_source=4)



<a target="_blank" href="https://qm.qq.com/cgi-bin/qm/qr?k=8kGw-2B6BW_q0D37MoZfQdZz2mYGeXcp&jump_from=webapi&authKey=EKu0gtO431E3a1jLZ0d6vT1y+MRlkYWvd/PSEBwZwcaAREj9CbNvxNAPungrALqW"><img border="0" src="//pub.idqqimg.com/wpa/images/group.png" alt="RLGG交流群" title="RLGG交流群"></a>

> 如果网站无法打开,可以尝试复制链接发送到任意QQ好友,在QQ点击链接





[RL网盘]: https://gitee.com/rlyun/rlgg/tree/master/RL%E7%BD%91%E7%9B%98	"”RL网盘文档"
[RL云验证]: http://46.3.112.55:804/README.html

