-- Mostrar un Toast
luajava.toast("Hola desde Lua!", true)

-- Ejecutar en el hilo UI
luajava.runOnUiThread(function()
    local view = luajava.getIdView("mi_boton")
    view:setBackgroundColor(0xFFFF0000) -- Rojo
end)

-- Crear un proxy para una interfaz Java
local proxy = luajava.createProxy(
    "java.lang.Runnable",
    { run = function() print("Ejecutado!") end }
)

-- Iniciar un hilo con el proxy
local thread = luajava.startThread(proxy.run)