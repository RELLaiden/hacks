local windowManager = require('windowManager')

-- 1) Definimos nuestro layout principal:
local wurstLayout = {
  LinearLayout,
  layout_width  = 'wrap_content',
  layout_height = 'wrap_content',
  orientation   = 'vertical',
  padding       = '8dp',
  -- fondo semitransparente negro
  backgroundColor = 0x80000000,  

  -- 1.1) Cabecera con título y botones
  {
    LinearLayout,
    layout_width  = 'match_parent',
    layout_height = 'wrap_content',
    orientation   = 'horizontal',
    padding       = '4dp',
    -- rosa fuerte
    backgroundColor = 0xCC0066, 

    -- Título
    {
      TextView,
      text      = 'WURST v7.19',
      textSize  = '16sp',
      textColor = 0xFFFFFFFF,
      layout_weight = 1,
    },
    -- Botón minimizar “_”
    {
      Button,
      text = '_',
      onClick = function()
        rootViewManager:hide()
      end,
    },
    -- Botón cerrar “×”
    {
      Button,
      text = '×',
      onClick = function()
        rootViewManager:exit()
      end,
    },
  },

  -- 1.2) Sección de toggles (ejemplo con AutoTotem y AutoSoup)
  {
    LinearLayout,
    layout_width  = 'match_parent',
    layout_height = 'wrap_content',
    orientation   = 'vertical',
    padding       = '4dp',
    backgroundColor = 0x33000000,  -- negro muy transparente

    -- fila de AutoTotem
    {
      CheckBox,
      text      = 'AutoTotem',
      textColor = 0xFF66CC,  -- rosa claro para el texto
      checked   = false,
      onCheckedChanged = function(view, isChecked)
        -- aquí tu lógica
        if isChecked then
          gg.toast('AutoTotem ON')
        else
          gg.toast('AutoTotem OFF')
        end
      end,
    },

    -- fila de AutoSoup
    {
      CheckBox,
      text      = 'AutoSoup',
      textColor = 0xFF66CC,
      checked   = false,
      onCheckedChanged = function(view, isChecked)
        -- tu lógica
      end,
    },
  },

  -- 1.3) Dropdown de selección (simula los “▼” de Wurst)
  {
    Spinner,
    layout_width  = 'match_parent',
    layout_height = 'wrap_content',
    entries = { 'Option A', 'Option B', 'Option C' },
    onItemSelected = function(parent, view, pos, id)
      gg.toast('Seleccionaste: ' .. parent:getSelectedItem())
    end,
  },
}

-- 2) Cargamos y mostramos la ventana
local rootView = luajava.loadlayout(wurstLayout)
rootViewManager = windowManager:bindView(rootView)
rootViewManager:addView()
rootViewManager:setMoveable(true)
gg.setVisible(false)
rootViewManager:wait()
