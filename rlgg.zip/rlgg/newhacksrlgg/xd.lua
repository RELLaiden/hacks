-- Cargar la clase y obtener la ruta
local GoldenCubeClass = luajava.bindClass("com.sandboxol.center.router.path.RouterServicePath$GoldenCube")
local servicePath = GoldenCubeClass.GOLDENCUBE

gg.alert("Ruta del servicio: " .. servicePath) -- Mostrará "/GoldenCube/service"