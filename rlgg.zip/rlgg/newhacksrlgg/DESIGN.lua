--[design.lua]
-- Diseño avanzado para hacks con RLGG
local DESIGN = {
    COLORS = {
        PRIMARY = 0xFF9C27B0,    -- Morado anime
        SECONDARY = 0xFFFF4081,  -- Rosa vibrante
        BACKGROUND = 0x80342D4C, -- Fondo oscuro translúcido
        TEXT = 0xFFFFFFFF,       -- Blanco puro
        ACCENT = 0xFF70F3FF      -- Cyan brillante
    },
    ICONS = {
        MAIN = 'https://i.imgur.com/ANIME_MAIN_ICON.png',
        SETTINGS = 'https://i.imgur.com/SETTINGS_ICON.webp',
        CLOSE = 'https://i.imgur.com/CLOSE_ICON.gif'
    },
    STYLES = {
        BUTTON = {
            radius = "25dp",
            padding = "12dp",
            margin = "8dp"
        }
    }
}

-- Cargar y cachear recursos remotos
local function loadResource(url, cacheName)
    local cacheDir = file.path(file.rlggStorage(), "design_cache")
    if not file.isDir(cacheDir) then file.mkdir(cacheDir) end
    
    local localPath = file.path(cacheDir, cacheName)
    if not file.isFile(localPath) then
        gg.makeRequest(url).content:save(localPath)
    end
    return localPath
end

-- Toast animado con icono
function DESIGN.animeToast(text, icon)
    local html = string.format(
        [[<font color="#%06X">%s <img src="%s" width="48dp" height="48dp"></font>]],
        DESIGN.COLORS.TEXT & 0xFFFFFF,
        text,
        loadResource(icon or DESIGN.ICONS.MAIN, "toast_icon.png")
    )
    gg.colorToast(html, 1)
end

-- Alertas HTML temáticas
function DESIGN.htmlAlert(title, content, image)
    local htmlContent = string.format([[
        <body bgcolor="#%06X">
            <h3 align="center">%s</h3>
            <img src="%s" width="100%%">
            <p>%s</p>
        </body>
    ]], 
    DESIGN.COLORS.BACKGROUND & 0xFFFFFF,
    title,
    loadResource(image, "alert_image.png"),
    content)

    gg.htmlAlert(
        string.format('<font color="#%06X">⚡ ANIME HACKS ⚡</font>', DESIGN.COLORS.ACCENT & 0xFFFFFF),
        htmlContent,
        "Aceptar",
        "Cancelar"
    )
end

-- Botones estilo anime
function DESIGN.createButton(text, onClick)
    return {
        Button,
        text = text,
        textColor = DESIGN.COLORS.TEXT,
        textSize = "18sp",
        background = {
            GradientDrawable,
            color = DESIGN.COLORS.PRIMARY,
            cornerRadius = DESIGN.STYLES.BUTTON.radius
        },
        layout_margin = DESIGN.STYLES.BUTTON.margin,
        padding = DESIGN.STYLES.BUTTON.padding,
        onClick = onClick
    }
end

-- Ventana flotante temática
function DESIGN.setupWindow(icon)
    gg.setIcon(loadResource(icon or DESIGN.ICONS.MAIN, "window_icon.png"))
    
    local windowAttr = {
        backgroundDrawable = {
            GradientDrawable,
            color = DESIGN.COLORS.BACKGROUND,
            cornerRadius = "30dp",
            strokeWidth = "2dp",
            strokeColor = DESIGN.COLORS.ACCENT
        }
    }
    luajava.setFloatingWindowAttr(windowAttr)
end

-- Ejemplo de uso
function DESIGN.demo()
    DESIGN.setupWindow()
    DESIGN.animeToast("Iniciando mods anime...")
    
    gg.sleep(1000)
    
    DESIGN.htmlAlert(
        "Bienvenido al Hack",
        "Selecciona tus modificaciones:<br><br>"..
        "• <font color='#70F3FF'>Visuales avanzadas</font><br>"..
        "• <font color='#FF4081'>Mejoras de combate</font>",
        DESIGN.ICONS.SETTINGS
    )
    
    return {
        DESIGN.createButton("Activar Aimbot", Aimbot),
        DESIGN.createButton("Modo Dios", GodMode)
    }
end

return DESIGN