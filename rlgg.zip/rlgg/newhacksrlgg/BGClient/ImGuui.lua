
-- ================================================
-- 🌌 IMGUI UI + Hacks Integrados (Estilo Wurst) 🌌
-- ================================================
local windowManager = require('floatingWindowManager')
local gg = gg or require('gameguardian')  -- asegúrate de requerir GameGuardian si es necesario

-- ================================================
-- ▼▼▼▼▼▼▼▼ Variables de Estado ▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼
-- ================================================
local estados = {
    aimbot          = false,
    bypass          = false,
    noDelay         = false,
    hitbox          = false,
    autoClicker     = false,
    fastBreak       = false,
    attackCooldown  = false,
    fpsUnlock       = false,
    fov             = false,
    speedX1         = false,
    speedX2         = false,
    speedX3         = false,
    gameSpeedX1     = false,
    gameSpeedX2     = false,
    gameSpeedX3     = false,
    speedV2X1       = false,
    speedV2X2       = false,
    speedV2X3       = false,
    airspeedX1      = false,
    airspeedX2      = false,
    airspeedX3      = false,
    airjump         = false,
}

-- ================================================
-- ▼▼▼▼▼▼▼▼ Core Hacks (copiados de Sonic X ExE) ▼▼▼▼▼▼▼▼▼▼
-- (funciones aplicarBypass, speedX1, Aimbot ya definidas antes)
-- Aquí añadimos el resto:

-- No Delay
function aplicarBypass(nivel)
    gg.setVisible(false)
    gg.clearResults()
    
    if nivel == 1 then
        gg.setRanges(gg.REGION_CODE_APP)
        gg.searchNumber("h000000000000000080842E41CDCCCCCC", gg.TYPE_BYTE)
        gg.getResults(500)
        gg.editAll("h000000000000000000000000CDCCCCCC", gg.TYPE_BYTE)
        estados.bypass = true
    
    elseif nivel == 2 then
        gg.setRanges(4^7)
        gg.searchNumber("1e6", 64)
        gg.editAll("0", 64)
        estados.bypass = true
    
    elseif nivel == 3 then
        gg.setRanges(gg.REGION_CODE_APP)
        gg.setVisible(false)
        gg.searchNumber("h63 65 5F 63 73 33 00 48 42 43 68 65 63 6B 00 63 73 63 21 25 73 00 63 73 66 21 25 73 00 63 73 5F 38 30 5F 70 6F 72 74 00 30 5F 30 5F 25 7A 75 00 43 53 33 2C 20 4F 6E 54 69 63 6B 65 74 4F 4B 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 68 65 6C 6C 6F 2C 20 77 6F 72 6C 64 00 00 72 6F 6C 65 5F 69 64 3A 25 73 3B 69 6E 63 5F 69 64 3A 25 64 00 67 65 74 5F 31 5F 25 64 3A 25 70 2C 20 6E 6F 64 65 5F 63 6E 74 3A 25 64 2C 20 72 65 6D 61 69 6E 3A 25 64 2C 20 63 73 33 00 64 65 6C 5F 31 5F 25 64 3A 25 70 2C 20 72 65 6D 61 69 6E 3A 25 64 2C 20 63 73 33 00 63 32 67 5F 72 65 64 69 65 63 74 00 00 04 08 18 0E 61 74 65 5F 62 69 00 63 68 65 63 6B 5F 65 78 74 5F 65 6D 75 5F 66 65 61 74 75 72 65 00 25 63 25 63 3A 25 64 2C 00 65 6D 75 5F 61 6C 65 72 74 3A 25 73 00 65 6D 75 5F 61 6C 65 72 74 00 65 5F 63 5F 6D 21 00 49 43 4F 4E 3A 25 73 3A 00 25 73 57 61 72 6E 69 6E 67 00 49 74 20 69 73 20 66 6F 75 6E 64 20 74 68 61 74 20 79 6F 75 20 61 72 65 20 72 75 6E 6E 69 6E 67 20 69 6E 20 61 6E 20 41 6E 64 72 6F 69 64 20 65 6D 75 6C 61 74 6F 72 2E 20 50 6C 65 61 73 65 20 72 65 73 75 6D 65 20 74 68 65 20 67 61 6D 65 20 61 66 74 65 72 20 72 65 74 75 72 6E 69 6E 67 20 74 6F 20 70 68 79 73 69 63 61 6C 20 64 65 76 69 63 65 73 2E 00 45 78 69 74 00 02 00 04 06 00 66 6F 6F 00 73 74 61 74 5F 72 70 74 00 61 63 65 5F 77 6F 72 6B 65 72 00 61 63 65 5F 77 6F 72 6B 65 72 25 64 00 73 63 5F 69 64 6C 65 00 00 00 00 00 00 00 00 80 84 2E 41 CD CC CC CC CC CC FC 3F 66 66 66 66 66 66 FE 3F 00 00 00 00 00 00 00 00 00 00 00 00 2C 01 00 00 00 00 00 00 84 03 00 00 96 00 00 00 08 00 00 00 3C 00 00 00 00 00 00 00 61 63 65 5F 73 63 68 65 64 75 6C 65 33 00 73 63 5F 64 6C 70 00 2B 20 72 65 70 6F 72 74 5F 62 6B 00 68 62 5F 6C 6F 6F 70 00 71 6F 73 5F 6C 6F 6F 70 00 69 6E 74 65 72 66 61 63 65 5F 74 65 73 74 00 73 63 00 25 64 3A 25 64 3A 25 64 3A 25 64 00 72 32 72 33 5F 65 72 72 00 6E 61 6D 65 3A 25 73 2C 20 63 61 73 74 3A 25 6C 64 00 6F 6E 73 65 6C 65 63 74 5F 61 6C 65 72 74 00 66 63 63 31 2E 64 00 21 64 6C 20 25 64 00 63 64 6E 3A 25 73 00 63 6F 6E 66 69 67 32 2E 78 6D 6C 00 21 64 63 66 00 21 70 63 66 00 21 64 73 66 00 64 6C 20 25 73 2C 20 72 65 74 76 61 6C 3A 25 64 2C 20 73 69 7A 65 3A 25 64 2C 20 63 61 63 68 65 3A 25 64 2C 20 6A 64 3A 25 64 00 63 6F 6D 6D 5F 66 69 72 73 74 00 73 69 67 20 63 75 73 74 6F 6D 2C 20 6E 61 6D 65 3A 25 73 2C 20 6C 65 6E 3A 25 64 2C 20 63 72 63 3A 25 30 38 78 00 63 6F 6E 66 69 67 33 2E 78 6D 6C 00 6D 65 6D 73 61 66 65 00 76 65 72 3A 25 73 20 61 70 70 5F 76 65 72 3A 25 73 20 63 6F 64 65 5F 73 69 7A 65 3A 25 73 20 63 72 63 3A 25 73 00 72 62 00 00 00 00 00 00 00 00 00 00 00 00 00 00 05 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 72 65 73 75 6C 74 3D 65 72 72 6F 72 00 00 00 00 38 DE 00 00 01 00 00 00 39 DE 00 00 01 00 00 00 3A DE 00 00 01 00 00 00 00 64 FD 82 FD FD FD A1 00 16 35 20 35 35 35 2A 00 00 00 00 00 00 00 00 01 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 77 73 61 5F 70 6F 70 65 6E 5F 69 70 00 77 73 61 5F 6E 65 74 6C 69 6E 6B 5F 69 70 00 77 73 61 5F 75 64 70 5F 69 70 00 25 75 3A 73 3B 70 3A 25 73 00 00 00 00 3A 8F 00 00 91 93 00 00 E8 97 00 00 00 61 22 3D 61 61 61 61 61 28 00 72 39 72 5A 72 72 63 72 6C 72 63 76 5F 25 64 2C 6C 65 6E 3A 25 64 2C 63 73 3A 25 64 00 67 5F 64 6C 5F 63 68 61 6E 6E 65 6C 00 70 5F 69 37 2E 64 61 74 00 72 5F 69 37 2E 64 61 74 00 72 65 63 6F 72 64 00 66 69 6C 65 73 2D 64 69 72 3A 25 73 2C 20 69 6E 69 74 65 64 3A 31 00 66 6C 61 67 73 3A 00 72 61 74 65 3A 25 64 00 67 61 6D 65 5F 76 65 72 3A 25 73 20 73 64 6B 5F 76 65 72 3A 25 73 00 33 2E 31 00 6A 61 72 5F 76 65 72 3A 25 73 2C 63 65 72 74 5F 65 6E 76 3A 25 73 00 6D 69 6E 5F 61 70 69 3A 25 64 2C 74 61 72 67 65 74 5F 61 70 69 3A 25 64 00 6D 61 78 5F 75 73 65 72 5F 77 61 74 63 68 65 73 3A 25 73 00 72 6F 6F 74 5F 61 6C 65 72 74 3A 25 73 00 72 6F 6F 74 5F 61 6C 65 72 74 00 72 70 64 61 74 61 32 00 63 73 3A 25 73 00 25 30 38 78 25 30 38 78 25 30 38 78 00 00 30 75 00 00 40 00 00 00 03 00 00 00 00 00 00 00 63 6C 6B 5F 61 64 62 00 41 75 74 6F 43 6C 69 63 6B 65 72 20 66 6F 75 6E 64 20 6F 6E 20 79 6F 75 72 20 70 68 6F 6E 65 2E 20 54 6F 20 63 6F 6E 74 69 6E 75 65 2C 20 64 72 61 67 20 74 68 65 20 73 63 72 6F 6C 6C 20 62 61 72 20 74 6F 20 74 68 65 20 6E 75 6D 62 65 72 20 25 64 2E 00 43 75 72 72 65 6E 74 20 6E 75 6D 62 65 72 20 69 73 3A 20 3B 25 64 3B 25 64 00 63 6C 6B 5F 72 70 74 00 25 73 2F 25 73 00 63 6F 6D 2F 63 6F 63 6F 73 2F 6C 69 62 2F 43 6F 63 6F 73 41 63 74 69 76 69 74 79 00 64 74 00 6D 53 75 72 66 61 63 65 56 69 65 77 00 4C 63 6F 6D 2F 63 6F 63 6F 73 2F 6C 69 62 2F 43 6F 63 6F 73 53 75 72 66 61 63 65 56 69 65 77 3B 00 73 65 74 4F 6E 74 6F 75 63 68 52 65 74 56 61 6C 00 28 5A 29 56 00 00 00 01 02 03 04 05 06 07 08 09 0A 0B 0C 0D 0E 0F 9A 99 99 99 99 99 C9 3F 71 3D 0A D7 A3 70 E5 3F 61 6E 6F 2C 64 72 6F 70 3A 25 73 3A 25 73 00 61 6E 6F 5F 74 69 70 5F 70 6B 67 00 6D 73 67 62 6F 78 5F 62 75 74 74 6F 6E 5F 31 30 30 30 31 00 61 6E 6F 5F 69 63 6F 6E 00 6D 73 67 62 6F 78 5F 63 6F 6E 74 65 6E 74 5F 31 30 30 30 31 00 4D 61 6C 77 61 72 65 20 66 6F 75 6E 64 20 6F 6E 20 79 6F 75 72 20 70 68 6F 6E 65 2E 20 50 6C 65 61 73 65 20 75 6E 69 6E 73 74 61 6C 6C 20 69 74 20 62 65 66 6F 72 65 20 65 6E 74 65 72 69 6E 67 20 74 68 65 20 67 61 6D 65 2E 28 00 61 6E 6F 5F 74 69 6D 65 00 21 66 6F 72 63 65 3A 6D 73 67 5F 62 6F 78 3A 74 69 6D 65 6F 75 74 00 77 68 6F 61 72 65 79 6F 75 3F 00 61 6E 6F 5F 66 63 00 61 6E 6F 5F 63 65 72 74 5F 6D 64 35 00 47 47 00 67 67 00 63 6F 6D 2E 00 61 6E 6F 5F 69 67 6E 6F 72 65 5F 64 65 74 65 63 74 00 61 6E 6F 5F 73 79 73 00 61 6E 6F 5F 63 66 69 6C 74 00 25 75 2E 25 75 2E 25 73 00 44 65 78 53 63 61 6E 00 63 6F 6D 2E 64 74 73 2E 66 72 65 65 66 69 72 65 74 68", gg.TYPE_BYTE, false, gg.SIGN_EQUAL, 0, -1, 0)
        revert = gg.getResults(100000, nil, nil, nil, nil, nil, nil, nil, nil)
        gg.editAll("0", gg.TYPE_BYTE)
        revert = gg.getResults(100000, nil, nil, nil, nil, nil, nil, nil, nil)
        gg.editAll("0", gg.TYPE_BYTE)
        gg.setVisible(false)
        gg.clearResults()
        gg.setRanges(gg.REGION_CODE_APP)
        gg.searchNumber("28 548 151 168 164 723", gg.TYPE_QWORD)
        local b = gg.getResults(99999)
        gg.addListItems(b)
        b = nil
        local a = false
        local b = gg.getListItems()
        if not a then gg.removeListItems(b) end
        for i, v in ipairs(b) do
            v.address = v.address + 0x13
            if a then v.name = v.name..' #2' end
        end
        gg.addListItems(b)
        b = nil
        a = nil
        revert = gg.getListItems()
        local b = gg.getListItems()
        for i, v in ipairs(b) do
                v.flags = gg.TYPE_BYTE
                v.value = "0"
                v.freeze = true
                v.freezeType = gg.FREEZE_IN_RANGE
                v.freezeFrom = "0"
                v.freezeTo = "1"
        end
        gg.addListItems(b)
        b = nil
        gg.clearResults()
        gg.clearList()
        gg.toast('Bypass by stormii')
        estados.bypass = true
    end
    
end

function speedX1()
    gg.setRanges(gg.REGION_CODE_APP)
    gg.searchNumber("-0.05000000075", gg.TYPE_FLOAT)
    gg.getResults(1000)
    gg.editAll("-0.020003", gg.TYPE_FLOAT)
    gg.clearResults()
end

function Aimbot()
    function Sv(v, rg, fg)
        rt = {}
        gg.setRanges(rg)
        gg.searchNumber(v[1], fg)
        local r = gg.getResults(999999)
        if #r == 0 then gg.toast("NOT VALUE 1") return rt end
        for iv = 2, #v do
            for i = 1, #r do
                r[i].address = r[i].address + v[iv][2]
            end
            local rr = gg.getValues(r)
            tt = {}
            for i = 1, #rr do
                if rr[i].value == v[iv][1] then
                    ii = #tt + 1
                    tt[ii] = {}
                    tt[ii].address = rr[i].address - v[iv][2]
                    tt[ii].flags = fg
                end
            end
            if #tt == 0 then gg.clearResults() gg.toast("NOT VALUE 2") return rt end
            r = gg.getValues(tt)
            if iv == #v then rt = r return rt end
        end
        gg.clearResults()
        return rt
    end
    
    gg.sleep(1000)
    
    function F()
        gg.clearList()
        gg.clearResults()
        v = 1
        gg.setVisible(false)
        rr = Sv({1127481344, {300, -71 * 4}, {0, -75 * 4}}, 4, 4)
        if #rr == 0 then gg.clearResults() gg.toast("NOT VALUE 1") return else
            gg.clearResults() gg.toast(#rr .. " PLAYER")
            r = Sv({1070554153, {1070554153, 0}}, 4, 4)
            if #r == 0 then gg.clearResults() gg.toast("NOT VALUE 2") return else
                gg.clearResults() gg.toast("AIMBOT Is ON")
            end
        end
     gg.setVisible(false)
    
       
        local smoothFactor = 0.2 
        local currentYaw = 0
        local currentPitch = 0
    
        while true do
            if gg.isVisible(true) then
                gg.setVisible(false) gg.clearList() gg.clearResults()
                gg.toast("AIMBOT OFF") return
            end
            if v == #rr + 1 then v = 1 end
            if rr[v].value ~= 1127481344 then
                v = v + 1
            else
                u = v
                for i, v in ipairs(r) do
                    local address = v.address
                    xA = gg.getValues({{address = address - 40 * 4, flags = 16}})[1].value
                    yA = gg.getValues({{address = address - 41 * 4, flags = 16}})[1].value
                    zA = gg.getValues({{address = address - 42 * 4, flags = 16}})[1].value
                    myHP = gg.getValues({{address = address + 28 * 4, flags = 64}})[1].value
                end
                
                local xx = {}
                xx[u] = {}
                xx[u].flags = 16
                xx[u].address = rr[u].address + -115 * 4
                xB = gg.getValues(xx)[u].value
                xx[u].address = rr[u].address + -116 * 4
                yB = gg.getValues(xx)[u].value
                xx[u].address = rr[u].address + -117 * 4
                zB = gg.getValues(xx)[u].value
                
                local hp = {}
                hp[u] = {}
                hp[u].flags = 64
                hp[u].address = rr[u].address + -47 * 4
                HP = gg.getValues(hp)[u].value    
     if myHP < 0.123 then
                    gg.toast("AIMBOT Is OFF") gg.clearList() return
                end
                if HP < 0.123 then v = v + 1 else
                    local kc = math.sqrt((xB - xA)^2 + (zB - zA)^2)
                    local ha = yB - yA
                    local hh = math.abs(ha)
                    local ka = math.abs(kc)
                    if kc > 7 then v = v + 1 else
                        if hh > 7 then v = v + 1 else
                            local targetPitch = math.atan2(hh, ka) * 180 / math.pi
                            if ha > 0 then targetPitch = targetPitch * (-1) end
                            local targetYaw = math.atan2(xB - xA, zB - zA) * 180 / math.pi - 90
                            
                           
                            local adaptiveSmoothFactor = smoothFactor + (kc / 15) 
                            
                            
                            currentYaw = currentYaw + (targetYaw - currentYaw) * adaptiveSmoothFactor
                            currentPitch = currentPitch + (targetPitch - currentPitch) * adaptiveSmoothFactor
    
                            
                            tt = {}
                            for i = 1, #r do
                                ii = #tt + 1
                                tt[ii] = {}
                                tt[ii].flags = 16
                                tt[ii].address = r[i].address + -47 * 4
                                tt[ii].value = currentPitch
                                gg.setValues(tt)
                                tt[ii].address = r[i].address + -48 * 4
                                tt[ii].value = currentYaw
                                gg.setValues(tt)
                            end
                        end
                    end    
        
                end
            end
            gg.sleep(5) 
        end
    end
    
    F()
end
function enableNoDelay()
    gg.setVisible(false); gg.clearResults()
    gg.setRanges(gg.REGION_C_ALLOC)
    gg.searchNumber("200;5;6.5", gg.TYPE_FLOAT)
    gg.refineNumber("6.5", gg.TYPE_FLOAT)
    local r = gg.getResults(1)
    if #r>0 then
        local addr = r[1].address - 608
        gg.setValues({{address=addr, flags=gg.TYPE_DWORD, value=1}})
        gg.addListItems({{address=addr, flags=gg.TYPE_DWORD, value=1}})
        gg.toast("No Delay ON")
    else gg.toast("No Delay FAIL") end
    gg.clearResults(); gg.clearList()
end
function disableNoDelay()
    gg.setVisible(false); gg.clearResults()
    gg.setRanges(gg.REGION_C_ALLOC)
    gg.searchNumber("200;5;6.5", gg.TYPE_FLOAT)
    gg.refineNumber("6.5", gg.TYPE_FLOAT)
    local r = gg.getResults(1)
    if #r>0 then
        local addr = r[1].address - 608
        gg.setValues({{address=addr, flags=gg.TYPE_DWORD, value=0}})
        gg.removeListItems({{address=addr, flags=gg.TYPE_DWORD}})
        gg.toast("No Delay OFF")
    else gg.toast("No Delay FAIL") end
    gg.clearResults(); gg.clearList()
end

-- Hitbox
function enableHitbox()
    gg.setVisible(false); gg.clearResults()
    gg.setRanges(gg.REGION_C_ALLOC)
    gg.searchNumber("1058642330D;180", gg.TYPE_FLOAT)
    gg.refineNumber("1058642330", gg.TYPE_DWORD)
    local r2 = gg.getResults(1000)
    for _,v in ipairs(r2) do
        v.value=1083642330; v.flags=gg.TYPE_DWORD
    end; gg.setValues(r2); gg.clearResults()
    gg.searchNumber("1083642330D;1.62", gg.TYPE_FLOAT)
    gg.refineNumber("1083642330", gg.TYPE_DWORD)
    local r3 = gg.getResults(1000)
    for _,v in ipairs(r3) do
        v.value=1058642330; v.flags=gg.TYPE_DWORD
    end; gg.setValues(r3); gg.clearResults()
    gg.searchNumber("1.8;180", gg.TYPE_FLOAT)
    gg.refineNumber("1.8", gg.TYPE_FLOAT)
    local r4 = gg.getResults(1000)
    for _,v in ipairs(r4) do v.value=2.4 end; gg.setValues(r4); gg.clearResults()
    gg.toast("Hitbox ON")
end
function disableHitbox()
    gg.setVisible(false); gg.clearResults()
    gg.setRanges(gg.REGION_C_ALLOC)
    gg.searchNumber("1083642330D;180", gg.TYPE_FLOAT)
    gg.refineNumber("1083642330", gg.TYPE_DWORD)
    local r2 = gg.getResults(1000)
    for _,v in ipairs(r2) do v.value=1058642330; v.flags=gg.TYPE_DWORD end
    gg.setValues(r2); gg.clearResults()
    gg.searchNumber("2.4;180", gg.TYPE_FLOAT)
    gg.refineNumber("2.4", gg.TYPE_FLOAT)
    local r3 = gg.getResults(1000)
    for _,v in ipairs(r3) do v.value=1.8 end; gg.setValues(r3); gg.clearResults()
    gg.toast("Hitbox OFF")
end

-- Auto Clicker
function enableAutoClicker()
    gg.setRanges(gg.REGION_C_ALLOC); gg.clearResults()
    gg.searchNumber("1054168405", gg.TYPE_DWORD)
    local r = gg.getResults(1)
    if #r>0 then
        local v = r[1]
        v.address=v.address+0x48; v.flags=gg.TYPE_DWORD; v.value=1; v.freeze=true
        gg.setValues({v}); gg.addListItems({v})
        gg.toast("AutoClicker ON")
    else gg.toast("AutoClicker FAIL") end
    gg.clearResults()
end
function disableAutoClicker()
    local list = gg.getListItems()
    for _,v in ipairs(list) do
        if v.freeze and v.value==1 then
            v.freeze=false; gg.setValues({v}); gg.removeListItems({v})
            gg.toast("AutoClicker OFF")
            return
        end
    end
    gg.toast("AutoClicker NOT FOUND")
end

-- Fast Break
function enableFastBreak()
    gg.setRanges(gg.REGION_C_ALLOC); gg.clearResults()
    gg.searchNumber("4575657222467066266", gg.TYPE_QWORD)
    local r = gg.getResults(99999)
    gg.addListItems(r)
    for _,v in ipairs(r) do
        v.address=v.address-68; v.flags=gg.TYPE_FLOAT; v.value=0
    end
    gg.setValues(r); gg.clearResults(); gg.clearList()
    gg.toast("FastBreak ON")
end
function disableFastBreak()
    gg.setRanges(gg.REGION_C_ALLOC); gg.clearResults()
    gg.searchNumber("4575657222467066266", gg.TYPE_QWORD)
    local r = gg.getResults(99999)
    local original = {}
    for _,v in ipairs(r) do
        table.insert(original, {address=v.address-68, value=v.value, flags=v.flags})
    end
    for _,v in ipairs(original) do gg.setValues({v}) end
    gg.clearResults(); gg.clearList()
    gg.toast("FastBreak OFF")
end

-- Attack Cooldown
function enableAttackCooldown()
    gg.setRanges(gg.REGION_C_ALLOC); gg.setVisible(false)
    gg.searchNumber("7405825", gg.TYPE_DWORD)
    local r = gg.getResults(gg.getResultCount())
    for _,v in ipairs(r) do
        v.address=v.address-8; v.value=0; v.freeze=true
    end; gg.setValues(r); gg.addListItems(r); gg.clearResults()
    gg.searchNumber("7405825", gg.TYPE_DWORD)
    local r2 = gg.getResults(gg.getResultCount())
    for _,v in ipairs(r2) do
        v.address=v.address+0x28; v.value=0; v.freeze=true
    end; gg.setValues(r2); gg.addListItems(r2); gg.clearResults()
    gg.toast("AttackCD ON")
end
function disableAttackCooldown()
    gg.setRanges(gg.REGION_C_ALLOC); gg.setVisible(false)
    gg.searchNumber("7405825", gg.TYPE_DWORD)
    for _,v in ipairs(gg.getResults(gg.getResultCount())) do
        v.address=v.address-8; gg.removeListItems({v})
    end; gg.clearResults()
    gg.searchNumber("7405825", gg.TYPE_DWORD)
    for _,v in ipairs(gg.getResults(gg.getResultCount())) do
        v.address=v.address+0x28; gg.removeListItems({v})
    end; gg.clearResults(); gg.toast("AttackCD OFF")
end

-- FPS Unlock
function enableFPSUnlock()
    gg.clearResults(); gg.setRanges(gg.REGION_ANONYMOUS)
    local r = gg.getResults(100, gg.TYPE_BYTE)
    if #r>0 then
        r[1].value=0; r[1].freeze=true
        gg.setValues({r[1]}); gg.clearResults()
        gg.toast("FPS Unlock ON")
    else gg.toast("FPS FAIL") end
end
function disableFPSUnlock()
    gg.clearResults(); gg.setRanges(gg.REGION_ANONYMOUS)
    -- dirección hardcodeada ejemplo, ajustar si es necesario
    local a = {{address=0x08FEE224, flags=gg.TYPE_BYTE}}
    gg.getValues(a)
    a[1].value=16; gg.setValues(a)
    gg.clearResults(); gg.toast("FPS Unlock OFF")
end

-- FOV Toggle
function enableFOV()
    gg.clearResults(); gg.setRanges(gg.REGION_C_ALLOC)
    gg.searchNumber("1.62", gg.TYPE_FLOAT)
    for _,v in ipairs(gg.getResults(100)) do v.value=1.7 end
    gg.setValues(gg.getResults(100)); gg.clearResults(); gg.toast("FOV ON")
end
function disableFOV()
    gg.clearResults(); gg.setRanges(gg.REGION_C_ALLOC)
    gg.searchNumber("1.7", gg.TYPE_FLOAT)
    for _,v in ipairs(gg.getResults(100)) do v.value=1.62 end
    gg.setValues(gg.getResults(100)); gg.clearResults(); gg.toast("FOV OFF")
end

-- Speed X2 / X3
function speedX2()
    gg.clearResults(); gg.setRanges(gg.REGION_CODE_APP)
    gg.searchNumber("1.62", gg.TYPE_FLOAT)
    for _,v in ipairs(gg.getResults(100)) do v.address=v.address-0x1C4; v.flags=gg.TYPE_FLOAT; v.value="0.30" end
    gg.setValues(gg.getResults(100)); gg.clearResults(); gg.toast("Speed X2 ON")
end
function speedX2Off()
    gg.clearResults(); gg.setRanges(gg.REGION_CODE_APP)
    gg.searchNumber("1.62", gg.TYPE_FLOAT)
    for _,v in ipairs(gg.getResults(100)) do v.address=v.address-0x1C4; v.flags=gg.TYPE_FLOAT; v.value="0.162771" end
    gg.setValues(gg.getResults(100)); gg.clearResults(); gg.toast("Speed X2 OFF")
end
function speedX3()
    gg.clearResults(); gg.setRanges(gg.REGION_CODE_APP)
    gg.searchNumber("1.62", gg.TYPE_FLOAT)
    for _,v in ipairs(gg.getResults(100)) do v.address=v.address-0x1C4; v.flags=gg.TYPE_FLOAT; v.value="0.35" end
    gg.setValues(gg.getResults(100)); gg.clearResults(); gg.toast("Speed X3 ON")
end
function speedX3Off()
    gg.clearResults(); gg.setRanges(gg.REGION_CODE_APP)
    gg.searchNumber("1.62", gg.TYPE_FLOAT)
    for _,v in ipairs(gg.getResults(100)) do v.address=v.address-0x1C4; v.flags=gg.TYPE_FLOAT; v.value="0.162771" end
    gg.setValues(gg.getResults(100)); gg.clearResults(); gg.toast("Speed X3 OFF")
end

-- Game Speed X1/2/3
function gameSpeedX1()   gg.clearResults(); gg.setRanges(gg.REGION_CODE_APP)
    gg.searchNumber("1.62", gg.TYPE_FLOAT)
    for _,v in ipairs(gg.getResults(100)) do v.address=v.address-0x2D0; v.flags=gg.TYPE_FLOAT; v.value="-0.04000007" end
    gg.setValues(gg.getResults(100)); gg.clearResults(); gg.toast("GameSpeed X1 ON")
end
function gameSpeedX1Off()gg.clearResults(); gg.setRanges(gg.REGION_CODE_APP)
    gg.searchNumber("1.62", gg.TYPE_FLOAT)
    for _,v in ipairs(gg.getResults(100)) do v.address=v.address-0x2D0; v.flags=gg.TYPE_FLOAT; v.value="-0.05000007" end
    gg.setValues(gg.getResults(100)); gg.clearResults(); gg.toast("GameSpeed X1 OFF")
end
function gameSpeedX2()   gg.clearResults(); gg.setRanges(gg.REGION_CODE_APP)
    gg.searchNumber("1.62", gg.TYPE_FLOAT)
    for _,v in ipairs(gg.getResults(100)) do v.address=v.address-0x2D0; v.flags=gg.TYPE_FLOAT; v.value="-0.03000007" end
    gg.setValues(gg.getResults(100)); gg.clearResults(); gg.toast("GameSpeed X2 ON")
end
function gameSpeedX2Off()gg.clearResults(); gg.setRanges(gg.REGION_CODE_APP)
    gg.searchNumber("1.62", gg.TYPE_FLOAT)
    for _,v in ipairs(gg.getResults(100)) do v.address=v.address-0x2D0; v.flags=gg.TYPE_FLOAT; v.value="-0.05000007" end
    gg.setValues(gg.getResults(100)); gg.clearResults(); gg.toast("GameSpeed X2 OFF")
end
function gameSpeedX3()   gg.clearResults(); gg.setRanges(gg.REGION_CODE_APP)
    gg.searchNumber("1.62", gg.TYPE_FLOAT)
    for _,v in ipairs(gg.getResults(100)) do v.address=v.address-0x2D0; v.flags=gg.TYPE_FLOAT; v.value="-0.02000007" end
    gg.setValues(gg.getResults(100)); gg.clearResults(); gg.toast("GameSpeed X3 ON")
end
function gameSpeedX3Off()gg.clearResults(); gg.setRanges(gg.REGION_CODE_APP)
    gg.searchNumber("1.62", gg.TYPE_FLOAT)
    for _,v in ipairs(gg.getResults(100)) do v.address=v.address-0x2D0; v.flags=gg.TYPE_FLOAT; v.value="-0.05000007" end
    gg.setValues(gg.getResults(100)); gg.clearResults(); gg.toast("GameSpeed X3 OFF")
end

-- Speed V2 X1/2/3
function onSpeedV2X1()  gg.clearResults(); gg.setRanges(gg.REGION_C_ALLOC)
    gg.searchNumber("1.62", gg.TYPE_FLOAT)
    for _,v in ipairs(gg.getResults()) do v.address=v.address+376; v.value="0.1"; v.freeze=true end
    gg.setValues(gg.getResults()); gg.clearResults(); gg.toast("SpeedV2 X1 ON")
end
function offSpeedV2X1() gg.clearResults(); gg.setRanges(gg.REGION_C_ALLOC)
    gg.searchNumber("1.62", gg.TYPE_FLOAT)
    for _,v in ipairs(gg.getResults()) do v.address=v.address+376; v.value="0"; v.freeze=true end
    gg.setValues(gg.getResults()); gg.clearResults(); gg.toast("SpeedV2 X1 OFF")
end
function onSpeedV2X2()  gg.clearResults(); gg.setRanges(gg.REGION_C_ALLOC)
    gg.searchNumber("1.62", gg.TYPE_FLOAT)
    for _,v in ipairs(gg.getResults()) do v.address=v.address+376; v.value="0.2"; v.freeze=true end
    gg.setValues(gg.getResults()); gg.clearResults(); gg.toast("SpeedV2 X2 ON")
end
function offSpeedV2X2() gg.clearResults(); gg.setRanges(gg.REGION_C_ALLOC)
    gg.searchNumber("1.62", gg.TYPE_FLOAT)
    for _,v in ipairs(gg.getResults()) do v.address=v.address+376; v.value="0"; v.freeze=true end
    gg.setValues(gg.getResults()); gg.clearResults(); gg.toast("SpeedV2 X2 OFF")
end
function onSpeedV2X3()  gg.clearResults(); gg.setRanges(gg.REGION_C_ALLOC)
    gg.searchNumber("1.62", gg.TYPE_FLOAT)
    for _,v in ipairs(gg.getResults()) do v.address=v.address+376; v.value="0.3"; v.freeze=true end
    gg.setValues(gg.getResults()); gg.clearResults(); gg.toast("SpeedV2 X3 ON")
end
function offSpeedV2X3() gg.clearResults(); gg.setRanges(gg.REGION_C_ALLOC)
    gg.searchNumber("1.62", gg.TYPE_FLOAT)
    for _,v in ipairs(gg.getResults()) do v.address=v.address+376; v.value="0"; v.freeze=true end
    gg.setValues(gg.getResults()); gg.clearResults(); gg.toast("SpeedV2 X3 OFF")
end

-- Airspeed X1/2/3
function airspeedX1()   gg.clearResults(); gg.setRanges(gg.REGION_C_ALLOC)
    gg.searchNumber("1.62", gg.TYPE_FLOAT)
    for _,v in ipairs(gg.getResults(100)) do v.address=v.address+0x2B0; v.flags=gg.TYPE_FLOAT; v.value="0.03" end
    gg.setValues(gg.getResults(100)); gg.clearResults(); gg.toast("Airspeed X1 ON")
end
function airspeedX1Off()gg.clearResults(); gg.setRanges(gg.REGION_C_ALLOC)
    gg.searchNumber("1.62", gg.TYPE_FLOAT)
    for _,v in ipairs(gg.getResults(100)) do v.address=v.address+0x2B0; v.flags=gg.TYPE_FLOAT; v.value="0.02" end
    gg.setValues(gg.getResults(100)); gg.clearResults(); gg.toast("Airspeed X1 OFF")
end
function airspeedX2()   gg.clearResults(); gg.setRanges(gg.REGION_C_ALLOC)
    gg.searchNumber("1.62", gg.TYPE_FLOAT)
    for _,v in ipairs(gg.getResults(100)) do v.address=v.address+0x2B0; v.flags=gg.TYPE_FLOAT; v.value="0.04" end
    gg.setValues(gg.getResults(100)); gg.clearResults(); gg.toast("Airspeed X2 ON")
end
function airspeedX2Off()gg.clearResults(); gg.setRanges(gg.REGION_C_ALLOC)
    gg.searchNumber("1.62", gg.TYPE_FLOAT)
    for _,v in ipairs(gg.getResults(100)) do v.address=v.address+0x2B0; v.flags=gg.TYPE_FLOAT; v.value="0.02" end
    gg.setValues(gg.getResults(100)); gg.clearResults(); gg.toast("Airspeed X2 OFF")
end
function airspeedX3()   gg.clearResults(); gg.setRanges(gg.REGION_C_ALLOC)
    gg.searchNumber("1.62", gg.TYPE_FLOAT)
    for _,v in ipairs(gg.getResults(100)) do v.address=v.address+0x2B0; v.flags=gg.TYPE_FLOAT; v.value="0.05" end
    gg.setValues(gg.getResults(100)); gg.clearResults(); gg.toast("Airspeed X3 ON")
end
function airspeedX3Off()gg.clearResults(); gg.setRanges(gg.REGION_C_ALLOC)
    gg.searchNumber("1.62", gg.TYPE_FLOAT)
    for _,v in ipairs(gg.getResults(100)) do v.address=v.address+0x2B0; v.flags=gg.TYPE_FLOAT; v.value="0.02" end
    gg.setValues(gg.getResults(100)); gg.clearResults(); gg.toast("Airspeed X3 OFF")
end

-- Air Jump
function enableAirjump()
    gg.setVisible(false); gg.clearResults()
    gg.setRanges(gg.REGION_CODE_APP)
    gg.searchNumber("1.62", gg.TYPE_FLOAT)
    local rs = gg.getResults(gg.getResultCount())
    for _,v in ipairs(rs) do
        v.address=v.address-0x478; v.flags=gg.TYPE_FLOAT; v.value="-3"; v.freeze=true
    end; gg.setValues(rs); gg.toast("Airjump ON"); gg.clearResults()
end
function disableAirjump()
    gg.setVisible(false); gg.clearResults()
    gg.setRanges(gg.REGION_CODE_APP)
    gg.searchNumber("1.62", gg.TYPE_FLOAT)
    local rs = gg.getResults(gg.getResultCount())
    for _,v in ipairs(rs) do
        v.address=v.address-0x478; v.flags=gg.TYPE_FLOAT; v.value="0.0001"; v.freeze=false
    end; gg.setValues(rs); gg.toast("Airjump OFF"); gg.clearResults()
end

-- ================================================
-- ▼▼▼▼▼▼▼▼ Funciones Toggle (envuelven cada hack) ▼▼▼▼▼▼▼▼▼
-- ================================================
-- Función auxiliar para toggles
local function toggle(field, onF, offF)
    return function()
        if not estados[field] then
            onF(); estados[field] = true
        else
            offF(); estados[field] = false
        end
    end
end

-- Botón Wurst
local function mkBtn(text, fn, color)
    return {
        Button,
        text = text,
        textSize = "16sp",
        textColor = 0xFFFFFFFF,
        backgroundColor = color,
        padding = "10dp",
        layout_margin = "6dp",
        onClick = function()
            luajava.startThread(function()
                pcall(fn)
                gg.setVisible(false)
            end)
        end
    }
end

-- ===========================
-- 1) VENTANA PRINCIPAL
-- ===========================
windowManager:newWindow("MainMenu", {
    onCreate = function(win)
        win:addlayout({
            ScrollView, layout_width="match_parent", layout_height="match_parent", padding="10dp",
            {
                LinearLayout, orientation="vertical", layout_width="match_parent", layout_height="wrap_content",

                { TextView, text="⚡ IMGUI HUB ⚡", textSize="24sp", textColor=0xFFFFFFFF, layout_marginBottom="12dp" },

                -- Sección Bypass
                { TextView, text="⛓️ Sección Bypass", textSize="18sp", textColor=0xFFFFFFFF },
                mkBtn("🛡️ Bypass Nivel 3", function() aplicarBypass(3) end, 0x00000000),
                { View, layout_width="match_parent", layout_height="1dp", backgroundColor=0x40FFFFFF, layout_margin="12dp" },

                -- Sección Aimbot+Speed1
                { TextView, text="🎯 Aimbot + 🚀 Speed x1", textSize="18sp", textColor=0xFFFFFFFF },
                { Button,
                  text="🎯 Abrir Aimbot",
                  onClick=function() windowManager:start("AimbotMenu") end,
                  backgroundColor=0x00000000, textSize="16sp", padding="10dp", layout_margin="6dp", textColor=0xFFFFFFFF
                },
                { Button,
                  text="🚀 Abrir Speed x1",
                  onClick=function() windowManager:start("Speed1Menu") end,
                  backgroundColor=0x00000000, textSize="16sp", padding="10dp", layout_margin="6dp", textColor=0xFFFFFFFF
                },
                { View, layout_width="match_parent", layout_height="1dp", backgroundColor=0x40FFFFFF, layout_margin="12dp" },

                -- Sección Combat
                { TextView, text="⚔️ Sección Combat", textSize="18sp", textColor=0xFFFFFFFF },
                { Button,
                  text="🔫 Abrir Combat",
                  onClick=function() windowManager:start("CombatMenu") end,
                  backgroundColor=0x00000000, textSize="16sp", padding="10dp", layout_margin="6dp", textColor=0xFFFFFFFF
                },
                { View, layout_width="match_parent", layout_height="1dp", backgroundColor=0x40FFFFFF, layout_margin="12dp" },

                -- Sección Movement
                { TextView, text="🏃 Sección Movement", textSize="18sp", textColor=0xFFFFFFFF },
                { Button,
                  text="🏃 Abrir Movement",
                  onClick=function() windowManager:start("MovementMenu") end,
                  backgroundColor=0x00000000, textSize="16sp", padding="10dp", layout_margin="6dp", textColor=0xFFFFFFFF
                },
            }
        })
    end
})

-- ===========================
-- 2) VENTANA BYPASS (ejemplo)
-- ===========================
windowManager:newWindow("BypassMenu", {
    onCreate = function(win)
        win:addlayout({
            ScrollView, padding="10dp",
            {
                LinearLayout, orientation="vertical",
                { TextView, text="⛓️ BYPASS", textSize="20sp", textColor=0xFFFFFFFF },
                mkBtn("🛡️ Bypass Nivel 3", function() aplicarBypass(3) end, 0x00000000),
                { Button,
                  text="🔙 Volver",
                  onClick=function() windowManager:start("MainMenu") end,
                  backgroundColor=0x00000000, textColor=0xFFFFFFFF, padding="10dp", layout_margin="6dp"
                }
            }
        })
    end
})

-- ===========================
-- 3) VENTANA AIMBOT
-- ===========================
windowManager:newWindow("AimbotMenu", {
    onCreate = function(win)
        win:addlayout({
            ScrollView, padding="10dp",
            {
                LinearLayout, orientation="vertical",
                { TextView, text="🎯 AIMBOT", textSize="20sp", textColor=0xFFFFFFFF },
                mkBtn("🎯 Auto-Aim Premium", Aimbot, 0x00000000),
                { Button,
                  text="🔙 Volver",
                  onClick=function() windowManager:start("MainMenu") end,
                  backgroundColor=0x00000000, textColor=0xFFFFFFFF, padding="10dp", layout_margin="6dp"
                }
            }
        })
    end
})

-- ===========================
-- 4) VENTANA SPEED X1
-- ===========================
windowManager:newWindow("Speed1Menu", {
    onCreate = function(win)
        win:addlayout({
            ScrollView, padding="10dp",
            {
                LinearLayout, orientation="vertical",
                { TextView, text="🚀 SPEED x1", textSize="20sp", textColor=0xFFFFFFFF },
                mkBtn("🚀 Toggle Speed x1", toggle("speedX1", speedX1, speedX1Off), 0x00000000),
                { Button,
                  text="🔙 Volver",
                  onClick=function() windowManager:start("MainMenu") end,
                  backgroundColor=0x00000000, textColor=0xFFFFFFFF, padding="10dp", layout_margin="6dp"
                }
            }
        })
    end
})

-- ===========================
-- 5) VENTANA COMBAT
-- ===========================
windowManager:newWindow("CombatMenu", {
    onCreate = function(win)
        win:addlayout({
            ScrollView, padding="10dp",
            {
                LinearLayout, orientation="vertical",
                { TextView, text="⚔️ COMBAT", textSize="20sp", textColor=0xFFFFFFFF },
                mkBtn("⏱️ No Delay",          toggle("noDelay", enableNoDelay, disableNoDelay),             0x00000000),
                mkBtn("🔫 Hitbox",            toggle("hitbox", enableHitbox, disableHitbox),               0x00000000),
                mkBtn("🤖 Auto Clicker",      toggle("autoClicker", enableAutoClicker, disableAutoClicker),0x00000000),
                mkBtn("💥 Fast Break",        toggle("fastBreak", enableFastBreak, disableFastBreak),      0x00000000),
                mkBtn("⛔ Attack Cooldown",   toggle("attackCooldown", enableAttackCooldown, disableAttackCooldown),0x00000000),
                mkBtn("🎮 FPS Unlock",        toggle("fpsUnlock", enableFPSUnlock, disableFPSUnlock),     0x00000000),
                mkBtn("🔍 FOV Toggle",        toggle("fov", enableFOV, disableFOV),                        0x00000000),
                { Button,
                  text="🔙 Volver",
                  onClick=function() windowManager:start("MainMenu") end,
                  backgroundColor=0x00000000, textColor=0xFFFFFFFF, padding="10dp", layout_margin="6dp"
                }
            }
        })
    end
})

-- ===========================
-- 6) VENTANA MOVEMENT
-- ===========================
windowManager:newWindow("MovementMenu", {
    onCreate = function(win)
        win:addlayout({
            ScrollView, padding="10dp",
            {
                LinearLayout, orientation="vertical",
                { TextView, text="🏃 MOVEMENT", textSize="20sp", textColor=0xFFFFFFFF },
                mkBtn("⚡ Speed x2",          toggle("speedX2", speedX2, speedX2Off),                      0x00000000),
                mkBtn("⚡ Speed x3",          toggle("speedX3", speedX3, speedX3Off),                      0x00000000),
                mkBtn("🎮 GameSpeed x1",      toggle("gameSpeedX1", gameSpeedX1, gameSpeedX1Off),          0x00000000),
                mkBtn("🎮 GameSpeed x2",      toggle("gameSpeedX2", gameSpeedX2, gameSpeedX2Off),          0x00000000),
                mkBtn("🎮 GameSpeed x3",      toggle("gameSpeedX3", gameSpeedX3, gameSpeedX3Off),          0x00000000),
                mkBtn("⚡ Speed V2 X1",       toggle("speedV2X1", onSpeedV2X1, offSpeedV2X1),              0x00000000),
                mkBtn("⚡ Speed V2 X2",       toggle("speedV2X2", onSpeedV2X2, offSpeedV2X2),              0x00000000),
                mkBtn("⚡ Speed V2 X3",       toggle("speedV2X3", onSpeedV2X3, offSpeedV2X3),              0x00000000),
                mkBtn("💨 Airspeed x1",       toggle("airspeedX1", airspeedX1, airspeedX1Off),            0x00000000),
                mkBtn("💨 Airspeed x2",       toggle("airspeedX2", airspeedX2, airspeedX2Off),            0x00000000),
                mkBtn("💨 Airspeed x3",       toggle("airspeedX3", airspeedX3, airspeedX3Off),            0x00000000),
                mkBtn("🪂 Air Jump",          toggle("airjump", enableAirjump, disableAirjump),            0x00000000),
                { Button,
                  text="🔙 Volver",
                  onClick=function() windowManager:start("MainMenu") end,
                  backgroundColor=0x00000000, textColor=0xFFFFFFFF, padding="10dp", layout_margin="6dp"
                }
            }
        })
    end
})

-- ===========================
-- Iniciar UI
-- ===========================
windowManager:run()
