-- Configuración inicial
local fwm = require("floatingWindowManager")
local YoYoImpl

-- 1. Cargar YoYoImpl de forma segura
local loadYoYo = function()
    YoYoImpl = luajava.getYoYoImpl()
end
local yoYoThread = luajava.startThread(loadYoYo)
yoYoThread:join(1500) -- Esperar 1.5 segundos

if not YoYoImpl then
    gg.alert("Error crítico: Módulo de animaciones no cargado")
    return
end

-- 2. Inicializar ventana flotante
fwm.init()

-- 3. Crear ventana con todos los callbacks requeridos
local mainWindow = fwm.newWindow("WurstGG", {
    onCreate = function(window)
        -- Configuración del layout
        window:setTitle("Wurst GG Edition")
        window:match_parent()
        
        local scroll = luajava.new(luajava.bindClass("android.widget.ScrollView"))
        local layout = luajava.loadlayout({
            LinearLayout = {
                orientation = "vertical",
                padding = "16dp",
                background = 0xFF1A1A1A,
                {
                    EditText = {
                        id = "searchBar",
                        hint = "Buscar módulos...",
                        hintTextColor = 0xFF808080,
                        textColor = 0xFFFFFFFF,
                        background = GradientDrawable()
                            :setShape(0) -- Rectángulo
                            :setColor(0xFF2D2D2D)
                            :setCornerRadius(15)
                            :setStroke(2, 0xFF00FF00),
                        layout_width = "match_parent",
                        layout_height = "wrap_content"
                    }
                },
                -- Contenedor dinámico
                {
                    LinearLayout = {
                        id = "categoryContainer",
                        orientation = "vertical",
                        layout_width = "match_parent"
                    }
                }
            }
        })
        
        -- Añadir categorías
        local categories = {
            {name = "Movimiento", modules = {"Fly", "Speed", "NoFall"}},
            {name = "Combate", modules = {"KillAura", "TriggerBot", "Reach"}},
            {name = "Render", modules = {"X-Ray", "ESP", "Fullbright"}}
        }
        
        local container = layout:findViewByName("categoryContainer")
        for _, cat in ipairs(categories) do
            container:addView(createCategory(cat.name, cat.modules))
        end
        
        scroll:addView(layout)
        window:addView(scroll)
    end,
    
    onStart = function(window)
        pcall(function()
            YoYoImpl:with("ZoomInLeft"):duration(600):playOn(window.mRootView)
        end)
    end,
    
    onError = function(err)
        gg.alert("ERROR:\n"..tostring(err))
        fwm.exit()
    end,
    
    -- Callbacks adicionales requeridos
    onPause = function() end,
    onResume = function() end,
    onDestroy = function() end
})

-- 4. Función para crear categorías
function createCategory(name, modules)
    return luajava.loadlayout({
        LinearLayout = {
            orientation = "vertical",
            layout_margin = "8dp",
            {
                TextView = {
                    text = name,
                    textSize = "18sp",
                    textColor = 0xFF00FF00,
                    layout_marginBottom = "4dp"
                }
            },
            createModuleButtons(modules)
        }
    })
end

-- 5. Función para botones de módulos
function createModuleButtons(modules)
    local buttons = {}
    for _, module in ipairs(modules) do
        table.insert(buttons, {
            Button = {
                text = module,
                textColor = 0xFFFFFFFF,
                background = GradientDrawable()
                    :setShape(0)
                    :setColor(0xFF333333)
                    :setCornerRadius(8)
                    :setStroke(2, 0xFF00FF00),
                layout_width = "match_parent",
                onClick = function(v)
                    toggleModule(module)
                end
            }
        })
    end
    return buttons
end

-- 6. Sistema de módulos
local activeModules = {}

function toggleModule(module)
    activeModules[module] = not activeModules[module]
    gg.toast(module..(activeModules[module] and " ACTIVADO" or " DESACTIVADO"))
    
    -- Ejemplo: Lógica para Fly
    if module == "Fly" then
        gg.setValues({{address = 0x12345678, flags = gg.TYPE_DWORD, value = activeModules[module] and 1 or 0}})
    end
end

-- 7. Iniciar
fwm.start("WurstGG")
fwm.run()