-- filename: @/compiler_apk_so/branch/pro_res_game_upload/engine2_game_config_release/game_config/g2038/lua/gm_server.lua
-- version: lua53
-- line: [0, 0] id: 0
local r0_0 = GM:createGMItem()
local r1_0 = require("script_server.battle.battle_field_manager")
local r2_0 = require("script_server.pokemon.pokemon_manager")
local r3_0 = T(Config, "PokemonConfig")
local r4_0 = require("common.setting")
r0_0["每日抽奖/add次数"] = function(r0_1)
  -- line: [12, 20] id: 1
  r0_1:setLastAddLotteryChanceTime(os.time())
  local r1_1 = r0_1:getCurLotteryInfo() or {}
  r1_1.curLotteryNum = (r1_1.curLotteryNum or 0) + 1
  r1_1.curLotteryCircle = r1_1.curLotteryCircle or 1
  r1_1.curPickList = r1_1.curPickList or {}
  r0_1:setCurLotteryInfo(r1_1)
end
r0_0["每日任务/刷新任务列表"] = function(r0_2)
  -- line: [22, 24] id: 2
  r0_2:initDailyTask()
end
r0_0["NPC/清除NPC挑战状态"] = function(r0_3)
  -- line: [27, 29] id: 3
  r0_3:setValue("npcChallengeList", {})
end
r0_0["战斗/挑战NPC"] = function(r0_4)
  -- line: [32, 34] id: 4
  r0_4:npcEnterBattle(60309, 783)
end
r0_0["战斗/宝可梦状态"] = function(r0_5)
  -- line: [38, 48] id: 5
  if r0_5.battleField then
    Lib.logInfo("*****************宝可梦状态*****************")
    for r4_5, r5_5 in pairs(r0_5.battleField.playerList) do
      local r6_5 = r5_5:getBattlePet()
      if r6_5 then
        Lib.logInfo(r5_5.name, r6_5:getPokemon():getObjId(), r6_5:getPokemon():getCfgFullName(), r6_5:getPokemon():getCurHp())
      end
    end
  end
end
r0_0["pvp道馆/完成第一个pve道馆"] = function(r0_6)
  -- line: [53, 55] id: 6
  r0_6:setGymFinish(1, 1)
end
r0_0["pvp道馆/完成第二个pve道馆"] = function(r0_7)
  -- line: [57, 59] id: 7
  r0_7:setGymFinish(2, 1)
end
r0_0["pvp道馆/完成第三个pve道馆"] = function(r0_8)
  -- line: [61, 63] id: 8
  r0_8:setGymFinish(3, 1)
end
r0_0["pvp道馆/完成第四个pve道馆"] = function(r0_9)
  -- line: [65, 67] id: 9
  r0_9:setGymFinish(4, 1)
end
r0_0["pvp道馆/完成第五个pve道馆"] = function(r0_10)
  -- line: [69, 71] id: 10
  r0_10:setGymFinish(5, 1)
end
r0_0["pvp道馆/设置progress"] = function(r0_11)
  -- line: [73, 75] id: 11
  r0_11:setGymProgress(5, 6)
end
r0_0["战斗/所有玩家进入战场"] = function(r0_12)
  -- line: [78, 89] id: 12
  for r4_12, r5_12 in pairs(Game.GetAllPlayers()) do
    if r5_12:getFirstBattlePokemon() and not r5_12:isInBattle() then
      EncounterMgr:encounterTrigger(r5_12, Define.MEET_PKM_TYPE.HIDE_PKM, {
        {
          monsterID = 10200101,
          rareID = 1,
        }
      })
    end
  end
end
r0_0["战斗/PVE NV1"] = function(r0_13)
  -- line: [92, 103] id: 13
  if not r0_13:getFirstBattlePokemon() then
    Lib.logError("not getFirstBattlePokemon", r0_13.name)
    return 
  end
  EncounterMgr:encounterTrigger(r0_13, Define.MEET_PKM_TYPE.HIDE_PKM, {
    {
      monsterID = 1,
      rareID = 1,
    }
  })
end
r0_0["战斗/PVE NV2"] = function(r0_14)
  -- line: [106, 132] id: 14
  local r1_14 = r2_0:createPokemon(1, 1)
  local r2_14 = r2_0:createPokemon(1, 1)
  local r3_14 = r1_0
  local r5_14 = {
    map = "map002",
  }
  local r6_14 = r0_14:getMyTeamMateId()
  if r6_14 then
    r6_14 = 2 or 1
  else
    goto label_21	-- block#2 is visited secondly
  end
  r5_14.playerNum = r6_14
  r5_14.enemy = {
    {
      r1_14
    },
    {
      r2_14
    }
  }
  r5_14.mode = Define.BATTLE_MODE.PVE
  function r5_14.endCallBack()
    -- line: [118, 125] id: 15
    if r1_14:getMasterId() == 0 then
      r1_14:onDestroy()
    end
    if r2_14:getMasterId() == 0 then
      r2_14:onDestroy()
    end
  end
  r3_14 = r3_14:create(r5_14)
  if r0_14:isTeamCaptain() then
    TeamMgr:enterBattleField(r0_14, r3_14)
  else
    r0_14:enterBattleField(r3_14)
  end
end
r0_0["战斗/离开战场"] = function(r0_16)
  -- line: [134, 136] id: 16
  r0_16:leaveBattleField()
end
r0_0["战斗/3个玩家相互PVP"] = function(r0_17)
  -- line: [138, 149] id: 17
  local r1_17 = World.CurWorld:getEntity(Game.GetPlayerByUserId(59616).objID)
  local r2_17 = World.CurWorld:getEntity(Game.GetPlayerByUserId(18512).objID)
  local r3_17 = World.CurWorld:getEntity(Game.GetPlayerByUserId(59536).objID)
  if r1_17 and r2_17 and r3_17 then
    r1_17:onEnterPVP(r2_17)
    r2_17:onEnterPVP(r3_17)
    r3_17:onEnterPVP(r1_17)
    Lib.logInfo("3个玩家相互PVP")
  end
end
r0_0["战斗/打印当前指令"] = function(r0_18)
  -- line: [152, 156] id: 18
  if r0_18.battleField then
    Lib.logInfo("battleField curCmd", Lib.inspect(r0_18.battleField.curCmd))
  end
end
r0_0["战斗/打印battleFieldPos"] = function(r0_19)
  -- line: [159, 162] id: 19
  Lib.logInfo("battleFieldPos", Lib.v2s(r0_19.map.cfg.battleFieldPos or World.cfg.battleFieldPos))
end
r0_0["战斗/打印entityList"] = function(r0_20)
  -- line: [165, 174] id: 20
  if r0_20.battleField then
    Lib.logInfo("********************* entityList *********************")
    for r4_20, r5_20 in pairs(r0_20.battleField.entityList) do
      if r5_20 and r5_20:isValid() then
        Lib.logInfo(r4_20, r5_20:cfg().fullName, r5_20.name)
      end
    end
  end
end
r0_0["战斗/我要变强"] = function(r0_21)
  -- line: [177, 187] id: 21
  local r1_21 = r0_21:getBattlePet()
  if r1_21 and r1_21:isValid() then
    r1_21:setSpeed(999999)
    r1_21:setPAtk(999999)
    r1_21:setSAtk(999999)
    r1_21:setPDef(999999)
    r1_21:setSDef(999999)
    r1_21.curHp = 999999
  end
end
r0_0["战斗/我是弱鸡"] = function(r0_22)
  -- line: [190, 200] id: 22
  local r1_22 = r0_22:getBattlePet()
  if r1_22 and r1_22:isValid() then
    r1_22:setSpeed(1)
    r1_22:setPAtk(1)
    r1_22:setSAtk(1)
    r1_22:setPDef(1)
    r1_22:setSDef(1)
    r1_22.curHp = 1
  end
end
r0_0["战斗/敌方变弱"] = function(r0_23)
  -- line: [203, 216] id: 23
  if r0_23.battleField then
    for r4_23, r5_23 in pairs(r0_23.battleField:getEnemyDataList(r0_23) or {}) do
      if r5_23 and r5_23:isValid() then
        r5_23:setSpeed(1)
        r5_23:setPAtk(1)
        r5_23:setSAtk(1)
        r5_23:setPDef(1)
        r5_23:setSDef(1)
        r5_23.curHp = 1
      end
    end
  end
end
r0_0["战斗/敌方变强"] = function(r0_24)
  -- line: [219, 232] id: 24
  if r0_24.battleField then
    for r4_24, r5_24 in pairs(r0_24.battleField:getEnemyDataList(r0_24) or {}) do
      if r5_24 and r5_24:isValid() then
        r5_24:setSpeed(999999)
        r5_24:setPAtk(999999)
        r5_24:setSAtk(999999)
        r5_24:setPDef(999999)
        r5_24:setSDef(999999)
        r5_24.curHp = 999999
      end
    end
  end
end
r0_0["战斗/跳过操作"] = function(r0_25)
  -- line: [235, 238] id: 25
  r0_25:setStateReady(true)
  r0_25:setCmdReady(true)
end
r0_0["战斗/跳过所有操作"] = function(r0_26)
  -- line: [241, 246] id: 26
  for r4_26, r5_26 in pairs(r0_26.battleField.playerList or {}) do
    r5_26:setStateReady(true)
    r5_26:setCmdReady(true)
  end
end
r0_0["战斗/S StateReady"] = function(r0_27)
  -- line: [248, 250] id: 27
  r0_27.debugStateReady = not r0_27.debugStateReady
end
r0_0["战斗/BattleField Count"] = function(r0_28)
  -- line: [252, 255] id: 28
  Lib.logInfo("BattleField Count", Lib.getTableSize(r1_0:getBattleFieldList()))
end
r0_0["战斗/打印状态条件"] = function(r0_29)
  -- line: [261, 266] id: 29
  if r0_29.battleField then
    Lib.logInfo("condition", r0_29.battleField:checkStateReady(), r0_29.battleField:checkCmdReady(), r0_29.battleField:checkBattleEnd(), r0_29.battleField:checkPetValid())
  end
end
r0_0["战斗/打印宝可梦状态"] = function(r0_30)
  -- line: [268, 274] id: 30
  Lib.logInfo("********************* battlePetList *********************", r0_30.objID, r0_30.name)
  for r4_30, r5_30 in pairs(r0_30:getValue("battlePetList") or {}) do
    local r6_30 = r2_0:getPokemon(r5_30)
    Lib.logInfo(r6_30:getObjId(), r6_30:getName(), r6_30:getCfgFullName(), r6_30:getCurHp())
  end
end
r0_0["战斗/打印BattleState"] = function(r0_31)
  -- line: [276, 280] id: 31
  if r0_31.battleField then
    Lib.logInfo("self.battleState:update", r0_31.battleField.battleState.__name)
  end
end
r0_0["战斗/打印命令队列"] = function(r0_32)
  -- line: [283, 291] id: 32
  if r0_32.battleField then
    local r1_32 = r0_32.battleField.battleActionQueue._data
    Lib.logInfo("********* battleActionQueue *********")
    for r5_32 = 1, #r1_32, 1 do
      Lib.logInfo(r1_32[r5_32].type, Lib.v2s(r1_32[r5_32].param))
    end
  end
end
r0_0["战斗/打印playerList State"] = function(r0_33)
  -- line: [293, 304] id: 33
  if r0_33.battleField then
    Lib.logInfo("********* playerList State *********")
    for r4_33, r5_33 in pairs(r0_33.battleField.playerList) do
      Lib.logInfo(r5_33.objID, r5_33.name, "stateReady " .. tostring(r5_33.stateReady), "cmdReady " .. tostring(r5_33.cmdReady), "CampId " .. tostring(r5_33:getCampId()), "canBattle " .. tostring(r5_33:canBattle()), "BattlePet isValid " .. tostring((r5_33:getBattlePet() and r5_33:getBattlePet():isValid())))
    end
  end
end
r0_0["战斗/打印hostList State"] = function(r0_34)
  -- line: [306, 316] id: 34
  if r0_34.battleField then
    Lib.logInfo("********* hostList State *********")
    for r4_34, r5_34 in pairs(r0_34.battleField.hostList) do
      Lib.logInfo(r5_34.objID, tostring(r5_34.name), r5_34:getBpIndex(), "CampId " .. tostring(r5_34:getCampId()), "canBattle " .. tostring(r5_34:canBattle()), "BattlePet isValid " .. tostring((r5_34:getBattlePet() and r5_34:getBattlePet():isValid())))
    end
  end
end
r0_0["战斗/打印玩家血量"] = function(r0_35)
  -- line: [318, 320] id: 35
  Lib.logDebug("player curHp", r0_35.curHp)
end
r0_0["战斗/排序测试"] = function(r0_36)
  -- line: [322, 332] id: 36
  local r1_36 = {
    1,
    5,
    4,
    2,
    3
  }
  table.sort(r1_36, function(r0_37, r1_37)
    -- line: [324, 326] id: 37
    return false
  end)
  Lib.logInfo("******************* result *******************")
  for r5_36 = 1, #r1_36, 1 do
    Lib.logInfo(Lib.v2s(r1_36[r5_36]))
  end
end
r0_0["战斗/全部离开战场"] = function(r0_38)
  -- line: [335, 341] id: 38
  if r0_38.battleField then
    for r4_38, r5_38 in pairs(r0_38.battleField.playerList) do
      r5_38:leaveBattleField()
    end
  end
end
r0_0["战斗/getEnemyPokemonList"] = function(r0_39)
  -- line: [344, 351] id: 39
  Lib.logInfo("**************** getEnemyPokemonList ****************")
  if r0_39.battleField then
    for r4_39, r5_39 in pairs(r0_39.battleField:getEnemyPokemonList(r0_39)) do
      Lib.logInfo(r5_39:getObjId(), r5_39:getName())
    end
  end
end
r0_0["战斗/灼烧buff"] = function(r0_40)
  -- line: [353, 359] id: 40
  if not r0_40:getTypeBuff("fullName", "myplugin/skill_fire_damage_buff_1") then
    r0_40:addBuff("myplugin/skill_fire_damage_buff_1")
  else
    r0_40:removeTypeBuff("fullName", "myplugin/skill_fire_damage_buff_1")
  end
end
r0_0["宠物/上阵宠物加经验"] = GM:inputStr(function(r0_41, r1_41)
  -- line: [361, 376] id: 41
  local r2_41 = {}
  for r6_41, r7_41 in pairs(r0_41:getBattlePokemon()) do
    table.insert(r2_41, {
      objId = r7_41:getObjId(),
      exp = r1_41 - r7_41:addExp(r1_41),
    })
  end
  r0_41:sendPacket({
    pid = "RewardResult",
    petExpList = r2_41,
    coin = 0,
    exp = 0,
  })
end, "经验数量")
r0_0["宠物/获得所有宠物"] = function(r0_42)
  -- line: [378, 390] id: 42
  local r1_42 = r3_0:getAllConfig()
  local r2_42 = {}
  for r6_42, r7_42 in pairs(r1_42) do
    table.insert(r2_42, r7_42)
  end
  table.sort(r2_42, function(r0_43, r1_43)
    -- line: [384, 386] id: 43
    return r0_43.id < r1_43.id
  end)
  for r6_42, r7_42 in pairs(r2_42) do
    r0_42:randomPokemon(r7_42.id)
  end
end
r0_0["宠物/清空所有宠物"] = function(r0_44)
  -- line: [392, 398] id: 44
  r2_0:removePokemonList(r0_44:getValue("battlePetList"))
  r2_0:removePokemonList(r0_44:getValue("packetPetList"))
  r0_44:setValue("battlePetList", {})
  r0_44:setValue("packetPetList", {})
  r0_44:setValue("bookRecord", {})
end
r0_0["宠物/打印AllPokemon"] = function(r0_45)
  -- line: [400, 408] id: 45
  Lib.logInfo("******************** 打印AllPokemon ********************")
  for r4_45, r5_45 in pairs(r2_0:getAllPokemon() or {}) do
    if r5_45 then
      Lib.logInfo(r5_45:getObjId(), r5_45:getName(), r5_45:getMaster() and r5_45:getMaster():isValid() and r5_45:getMaster().name)
    end
  end
end
r0_0["宠物/打印PlayerPokemon"] = function(r0_46)
  -- line: [411, 419] id: 46
  Lib.logInfo("******************** 打印PlayerPokemon ********************")
  for r4_46, r5_46 in pairs(r0_46:getValue("battlePetList") or {}) do
    local r6_46 = r0_46:getPokemon(r5_46)
    if r6_46 then
      Lib.logInfo(r6_46:getObjId(), r6_46:getName(), r6_46:getMaster() and r6_46:getMaster().name)
    end
  end
end
r0_0["宠物/抓捕宠物"] = GM:inputStr(function(r0_47, r1_47)
  -- line: [421, 428] id: 47
  if not tonumber(r1_47) then
    return 
  end
  local r2_47 = r2_0:createPokemon(r1_47)
  r0_47:capturePokemon(r2_47)
  r2_47:onDestroy()
end, "宠物Id")
r0_0["宠物/查看宠物"] = GM:inputStr(function(r0_48, r1_48)
  -- line: [430, 438] id: 48
  if not tonumber(r1_48) then
    return 
  end
  local r2_48 = r0_48:getPokemon(r1_48)
  if r2_48 then
    Lib.pv(r2_48.attr)
  end
end, "宠物列表的索引objId")
r0_0["宠物/战斗列表"] = function(r0_49)
  -- line: [440, 461] id: 49
  print("战斗列表")
  for r5_49, r6_49 in pairs(r0_49:getBattlePokemon()) do
    print("---------" .. r5_49 .. "-----------")
    print("等级 " .. r6_49:getLevel())
    print("图鉴Id " .. r6_49:getBookId())
    print("当前经验 " .. r6_49:getCurExp())
    print("升级经验 " .. r6_49:getMaxExp())
    print("性别 " .. r6_49:getSex())
    print("种族 " .. r6_49:getRace())
    print("最大血量 " .. r6_49:getMaxHp())
    print("当前血量 " .. r6_49:getCurHp())
    print("技能列表--------------------------- ")
    Lib.pv(r6_49:getSkillList())
    print("被动技能列表--------------------------- ")
    Lib.pv(r6_49:getPassiveSkillList())
    print("待学技能--------------------------- ")
    Lib.pv(r6_49:getStudySkillList())
  end
end
r0_0["宠物/背包列表"] = function(r0_50)
  -- line: [463, 483] id: 50
  print("背包列表")
  for r5_50, r6_50 in pairs(r0_50:getPacketPokemon()) do
    print("---------" .. r5_50 .. "-----------")
    print("等级 " .. r6_50:getLevel())
    print("当前经验 " .. r6_50:getCurExp())
    print("升级经验 " .. r6_50:getMaxExp())
    print("性别 " .. r6_50:getSex())
    print("种族 " .. r6_50:getRace())
    print("最大血量 " .. r6_50:getMaxHp())
    print("当前血量 " .. r6_50:getCurHp())
    print("技能列表--------------------------- ")
    Lib.pv(r6_50:getSkillList())
    print("被动技能列表--------------------------- ")
    Lib.pv(r6_50:getPassiveSkillList())
    print("待学技能--------------------------- ")
    Lib.pv(r6_50:getStudySkillList())
  end
end
r0_0["宠物/恢复所有状态"] = function(r0_51)
  -- line: [485, 492] id: 51
  for r5_51, r6_51 in pairs(r0_51:getBattlePokemon()) do
    if r6_51 then
      r6_51:recoveryAll()
    end
  end
end
r0_0["宠物/打印管理器缓存"] = function(r0_52)
  -- line: [494, 514] id: 52
  for r5_52, r6_52 in pairs(r2_0:getAllPokemon()) do
    print("---------" .. r5_52 .. "-----------")
    print("等级 " .. r6_52:getLevel())
    print("当前经验 " .. r6_52:getCurExp())
    print("升级经验 " .. r6_52:getMaxExp())
    print("性别 " .. r6_52:getSex())
    print("种族 " .. r6_52:getRace())
    print("最大血量 " .. r6_52:getMaxHp())
    print("当前血量 " .. r6_52:getCurHp())
    print("技能列表--------------------------- ")
    Lib.pv(r6_52:getSkillList())
    print("被动技能列表--------------------------- ")
    Lib.pv(r6_52:getPassiveSkillList())
    print("待学技能--------------------------- ")
    Lib.pv(r6_52:getStudySkillList())
    print("------getLongRoundEffectbuffList-------", Lib.v2s(r6_52:getLongRoundEffectbuffList()))
  end
end
r0_0["物品/获得所有精灵球"] = function(r0_53)
  -- line: [516, 523] id: 53
  for r5_53, r6_53 in pairs(r4_0:modCfgs("item")) do
    if tonumber(r6_53.itemType) == Define.ITEM_TYPE.BALL then
      r0_53:obtainItemsByFullName(r5_53, 1, "gm.ball")
    end
  end
end
r0_0["物品/添加金币"] = function(r0_54)
  -- line: [525, 527] id: 54
  r0_54:addCurrency("gold_coin", 10000000, "GM")
end
r0_0["物品/添加假魔方"] = function(r0_55)
  -- line: [529, 531] id: 55
  r0_55:addCurrency("fDiamonds", 10000000, "GM")
end
r0_0["物品/获得所有恢复"] = function(r0_56)
  -- line: [533, 540] id: 56
  for r5_56, r6_56 in pairs(r4_0:modCfgs("item")) do
    if tonumber(r6_56.itemType) == Define.ITEM_TYPE.CURE then
      r0_56:obtainItemsByFullName(r5_56, 1, "gm.cure")
    end
  end
end
r0_0["物品/获得所有其他物品"] = function(r0_57)
  -- line: [542, 549] id: 57
  for r5_57, r6_57 in pairs(r4_0:modCfgs("item")) do
    if tonumber(r6_57.itemType) == Define.ITEM_TYPE.OTHER then
      r0_57:obtainItemsByFullName(r5_57, 1, "gm.other")
    end
  end
end
r0_0["物品/获得所有技能书"] = function(r0_58)
  -- line: [551, 558] id: 58
  for r5_58, r6_58 in pairs(r4_0:modCfgs("item")) do
    if tonumber(r6_58.itemType) == Define.ITEM_TYPE.SKILL then
      r0_58:obtainItemsByFullName(r5_58, 1, "gm.skill")
    end
  end
end
r0_0["物品/获得所有经验书"] = function(r0_59)
  -- line: [560, 567] id: 59
  for r5_59, r6_59 in pairs(r4_0:modCfgs("item")) do
    if tonumber(r6_59.itemType) == Define.ITEM_TYPE.EXP then
      r0_59:obtainItemsByFullName(r5_59, 1, "gm.exp")
    end
  end
end
r0_0["物品/获得所有洗练物品"] = function(r0_60)
  -- line: [569, 576] id: 60
  for r5_60, r6_60 in pairs(r4_0:modCfgs("item")) do
    if tonumber(r6_60.itemType) == Define.ITEM_TYPE.WASH then
      r0_60:obtainItemsByFullName(r5_60, 1, "gm.wash")
    end
  end
end
r0_0["物品/获得糖果"] = function(r0_61)
  -- line: [578, 585] id: 61
  for r5_61, r6_61 in pairs(r4_0:modCfgs("item")) do
    if tonumber(r6_61.itemType) == Define.ITEM_TYPE.Bless then
      r0_61:obtainItemsByFullName(r5_61, 1, "gm.skill")
    end
  end
end
r0_0["template/攻击宠物"] = function(r0_62)
  -- line: [587, 595] id: 62
  if r0_62.followPetObjId then
    local r1_62 = World.CurWorld:getEntity(r0_62.followPetObjId)
    if r1_62 then
      SkillMgr:castSkill(r0_62, 101, r1_62)
    end
  end
end
r0_0["template/花光金魔方"] = function(r0_63)
  -- line: [597, 601] id: 63
  Lib.payMoney(r0_63, 100022, 0, 13512, function(r0_64)
    -- line: [598, 600] id: 64
  end)
end
r0_0["template/获得经验1000"] = function(r0_65)
  -- line: [603, 605] id: 65
  r0_65:addPlayerExp(1000)
end
local r5_0 = 1
r0_0["template/依次获得勋章"] = function(r0_66)
  -- line: [608, 611] id: 66
  r0_66:catchGlory(r5_0)
  r5_0 = r5_0 + 1
end
r0_0["template/垃圾回收"] = function(r0_67)
  -- line: [614, 621] id: 67
  if r0_67.battleField then
    Lib.logInfo("getTableSize entityList before", Lib.getTableSize(r0_67.battleField.entityList))
    collectgarbage()
    collectgarbage()
    Lib.logInfo("getTableSize entityList after", Lib.getTableSize(r0_67.battleField.entityList))
  end
end
r0_0["引导/设置引导到第一个道馆"] = function(r0_68)
  -- line: [624, 628] id: 68
  r0_68:setCurGuideIndex(Define.GUIDE_INDEX.GOTO_GYM_1_BOSS)
end
r0_0["引导/关闭引导"] = function(r0_69)
  -- line: [631, 635] id: 69
  r0_69:setGuideFinish(true)
end
r0_0["传送/道馆"] = function(r0_70)
  -- line: [639, 641] id: 70
  r0_70:setMapPos(r0_70.map, Lib.v3(49, 5, 432))
end
r0_0["传送/回城"] = function(r0_71)
  -- line: [643, 645] id: 71
  r0_71:setMapPos(r0_71.map, Lib.v3(36, 5, 473))
end
r0_0["传送/场景一"] = function(r0_72)
  -- line: [647, 649] id: 72
  r0_72:setMapPos("map001", Lib.v3(15, 5.01, 410))
end
r0_0["传送/场景二"] = function(r0_73)
  -- line: [651, 653] id: 73
  r0_73:setMapPos(r0_73.map, Lib.v3(200, 5, 410))
end
r0_0["传送/场景三"] = function(r0_74)
  -- line: [655, 657] id: 74
  r0_74:setMapPos(r0_74.map, Lib.v3(380, 5, 410))
end
r0_0["传送/场景四"] = function(r0_75)
  -- line: [659, 661] id: 75
  r0_75:setMapPos(r0_75.map, Lib.v3(580, 5, 410))
end
r0_0["传送/场景五"] = function(r0_76)
  -- line: [663, 665] id: 76
  r0_76:setMapPos(r0_76.map, Lib.v3(780, 5, 410))
end
r0_0["传送/道馆二"] = function(r0_77)
  -- line: [667, 669] id: 77
  r0_77:setMapPos("map006", Lib.v3(62, 4, -18))
end
r0_0["传送/道馆三"] = function(r0_78)
  -- line: [671, 673] id: 78
  r0_78:setMapPos("map001", Lib.v3(417.698212, 5.010008, 427.840729))
end
r0_0["传送/道馆四"] = function(r0_79)
  -- line: [675, 677] id: 79
  r0_79:setMapPos("map012", Lib.v3(62, 4, -17))
end
r0_0["传送/道馆五"] = function(r0_80)
  -- line: [679, 681] id: 80
  r0_80:setMapPos("map001", Lib.v3(641.41748, 3.009477, 393.522308))
end
r0_0["传送/草丛"] = function(r0_81)
  -- line: [683, 685] id: 81
  r0_81:setMapPos(r0_81.map, Lib.v3(7, 4, 406))
end
r0_0["传送/???"] = function(r0_82)
  -- line: [687, 689] id: 82
  r0_82:setMapPos(r0_82.map, Lib.v3(97, 3, 397))
end
r0_0["传送/模型效果测试"] = function(r0_83)
  -- line: [690, 692] id: 83
  r0_83:setMapPos("map017", Lib.v3(0, 20, 0))
end
r0_0["测试/创建门"] = function(r0_84)
  -- line: [694, 708] id: 84
  local r1_84 = r0_84:getPosition()
  r0_84.textDoorEntity = EntityServer.Create({
    map = r0_84.map,
    cfgName = "myplugin/g2038_testdoor_fire_off",
    pos = {
      x = r1_84.x + math.random(-3, 3),
      y = r1_84.y,
      z = r1_84.z + math.random(-3, 3),
    },
    ry = 0,
    rp = 0,
  })
end
r0_0["测试/销毁门"] = function(r0_85)
  -- line: [710, 720] id: 85
  r0_85.textDoorEntity:addBuff("myplugin/entity_hide_buff")
end
r0_0["测试/更新门"] = function(r0_86)
  -- line: [722, 732] id: 86
  r0_86.textDoorEntity:addBuff("myplugin/entity_show_buff")
end
r0_0["测试/限时橙宠"] = function(r0_87)
  -- line: [734, 736] id: 87
  r0_87:verifyTriggerGiftCondition(Define.GIFT_TRIGGER_CONDITION.ORANGE_PET, 10200701)
end
r0_0["测试/普通跑马灯"] = function(r0_88)
  -- line: [738, 740] id: 88
  r0_88:sendTopWorldCommonTips("这是一条跑马灯")
end
r0_0["测试/普通世界聊天"] = function(r0_89)
  -- line: [742, 744] id: 89
  r0_89:sendChatWorldCommonTips("这是一条世界聊天")
end
r0_0["测试/特殊世界提示"] = function(r0_90)
  -- line: [746, 762] id: 90
  local r2_90 = {
    tipType = 5,
    playerName = "这个玩家是拜登",
    mapIdName = T(Config, "MapConfig"):getMapById(1).title or "",
    starLevel = 5,
    quality = 3,
    pkmName = "这个宝可梦是风暴主宰",
    oldName = "这个宝可梦我也不知道叫啥",
    skillName = "",
    growthSCount = 0,
    ownerName = "",
    syntheticNum = 7,
  }
  r0_90:sendSpecialWorldCommonTips(r2_90)
end
r0_0["测试/充值30"] = function(r0_91)
  -- line: [764, 769] id: 91
  print("getRechargeSum", r0_91:getRechargeSum())
  r0_91:setRechargeSum(r0_91:getRechargeSum() + 30)
  r0_91:addCurrency("fDiamonds", 30, "daily_reward")
  print("getRechargeSum", r0_91:getRechargeSum())
end
r0_0["测试/清空首冲状态"] = function(r0_92)
  -- line: [771, 774] id: 92
  r0_92:setRechargeSum(0)
  r0_92:setRechargeAwardStatus(0)
end
r0_0["测试/获得金币1000"] = function(r0_93)
  -- line: [776, 778] id: 93
  r0_93:addCurrency("gold_coin", 1000, "gm_gold")
end
return r0_0
