<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Mostrar Imagenes</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 20px;
            text-align: center;
        }
        .gallery {
            display: flex;
            flex-wrap: wrap;
            gap: 20px;
            justify-content: center;
        }

        .gallery img {
            width: 200px;
            height: auto;
            border: 2px solid #ddd;
            border-radius: 10px;
            padding: 5px;
            transition: transform 0.3s ease;
        }
        .gallery img:hover {
            transform: scale(1.1);
            border-color: #4CAF50;
        }
    </style>
</head>
<body>
    <h1>Galeria de Imagenes</h1>
    <div class="gallery">
        <?php
        $servername = "localhost";
        $username = "root";
        $password = "";
        $dbname = "foto";

        $conn = new mysqli($servername, $username, $password, $dbname);

        if ($conn->connect_error) {
            die("Conexion Fallida:" . $conn->connect_error);
        }

        $query = "SELECT filepath from images";
        $result = $conn->query($query);
        
        if ($result->num_rows > 0) {
            while ($row = $result->fetch_assoc()) {
                $filepath = $row["filepath"];
                echo "<img src='$filepath' alt='Immagen'>";
            }
        } else {
            echo "<p>No hay imagenes para mostrar.</p>";
        }

        $conn->close();
        ?>
    </div>
</body>
</html>