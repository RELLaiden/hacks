-- Función para formatear números con n decimales
function formatNumber(num, decimals)
    local mult = 10 ^ (decimals or 2)
    return math.floor(num * mult + 0.5) / mult
end

-- Limpia resultados previos
gg.clearResults()

-- Buscar la posición base del jugador usando "1.62"
gg.searchNumber("1.62", gg.TYPE_FLOAT)
local playerResults = gg.getResults(10) -- Obtenemos los posibles resultados

if #playerResults == 0 then
    gg.alert("No se pudo encontrar la posición base del jugador.")
    return
end

-- Suponemos que el primer resultado es la base del jugador
local playerBaseAddr = playerResults[1].address

-- Calculamos las direcciones de posición del jugador
local playerXAddr = playerBaseAddr + 0xA0 -- X ME
local playerYAddr = playerBaseAddr + 0xA4 -- Y ME
local playerZAddr = playerBaseAddr + 0x9C -- Z ME

-- Leemos las posiciones del jugador
local playerValues = gg.getValues({
    {address = playerXAddr, flags = gg.TYPE_FLOAT},
    {address = playerYAddr, flags = gg.TYPE_FLOAT},
    {address = playerZAddr, flags = gg.TYPE_FLOAT},
})

local playerX = playerValues[1].value
local playerY = playerValues[2].value
local playerZ = playerValues[3].value

gg.toast("Posición del jugador: X=" .. formatNumber(playerX, 2) .. ", Y=" .. formatNumber(playerY, 2) .. ", Z=" .. formatNumber(playerZ, 2))

-- Buscar enemigos usando "0.6;1.8;180"
gg.clearResults()
gg.searchNumber("0.6;1.8;180", gg.TYPE_FLOAT)
gg.refineNumber("180", gg.TYPE_FLOAT)

local enemyResults = gg.getResults(50) -- Tomamos múltiples resultados para más precisión
if #enemyResults == 0 then
    gg.alert("No se encontraron enemigos.")
    return
end

-- Buscar el enemigo más cercano
local closestEnemy = nil
local closestDistance = math.huge

for _, enemy in ipairs(enemyResults) do
    local enemyBaseAddr = enemy.address
    local enemyXAddr = enemyBaseAddr - 0x1CC -- X Enemy
    local enemyYAddr = enemyBaseAddr - 0x280 -- Y Enemy
    local enemyZAddr = enemyBaseAddr - 0x1C8 -- Z Enemy
    local enemyHPAddr = enemyBaseAddr - 0xBC -- HP Enemy

    local enemyValues = gg.getValues({
        {address = enemyXAddr, flags = gg.TYPE_FLOAT},
        {address = enemyYAddr, flags = gg.TYPE_FLOAT},
        {address = enemyZAddr, flags = gg.TYPE_FLOAT},
        {address = enemyHPAddr, flags = gg.TYPE_DOUBLE},
    })

    local enemyX = enemyValues[1].value
    local enemyY = enemyValues[2].value
    local enemyZ = enemyValues[3].value
    local enemyHP = enemyValues[4].value

    -- Calcula la distancia entre el jugador y el enemigo
    local distance = math.sqrt(
        math.pow(enemyX - playerX, 2) +
        math.pow(enemyY - playerY, 2) +
        math.pow(enemyZ - playerZ, 2)
    )

    -- Verifica si este enemigo es el más cercano
    if distance < closestDistance then
        closestDistance = distance
        closestEnemy = {
            x = enemyX,
            y = enemyY,
            z = enemyZ,
            hp = enemyHP,
            distance = distance
        }
    end
end

if closestEnemy then
    gg.alert("Enemigo más cercano:\n" ..
        "Posición: X=" .. formatNumber(closestEnemy.x, 2) .. 
        ", Y=" .. formatNumber(closestEnemy.y, 2) .. 
        ", Z=" .. formatNumber(closestEnemy.z, 2) .. "\n" ..
        "Distancia: " .. formatNumber(closestEnemy.distance, 2) .. "\n" ..
        "HP: " .. formatNumber(closestEnemy.hp, 2))
else
    gg.alert("No se encontraron enemigos cercanos.")
end
