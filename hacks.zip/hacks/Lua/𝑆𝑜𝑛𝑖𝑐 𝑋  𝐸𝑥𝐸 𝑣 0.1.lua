gg.alert("Creator: 𝑆𝑜𝑛𝑖𝑐 𝐸𝑥𝐸   𝑉 𝟎.𝟏\nHelper/Enc: Stormii LuarcV1.2")
 gg.alert("𝑆𝑐𝑟𝑖𝑝𝑡 𝑖𝑛𝑓𝑜 - [ 𝐵𝑎𝑠𝑖𝑐 32-64 𝑏𝑖𝑡 𝑠𝑐𝑟𝑖𝑝𝑡 𝑉 0.1 ]")
 gg.alert(" [ 🔴- 𝑤𝑎𝑟𝑛𝑖𝑛𝑔 𝑠𝑖𝑔𝑛𝑎𝑙𝑠 ] ")
 gg.alert(" [ 𝑁𝑒𝑥𝑡 𝑠𝑐𝑟𝑖𝑝𝑡 𝑢𝑝𝑑𝑎𝑡𝑒 𝑆𝑜𝑜𝑛 𝖷𝖣 ×͜× ]") 
local menuVisible = true  
local lk = 16384  

function main()
    while true do
        if menuVisible then
            local menu = {
             "👤 𝐶𝑟𝑒𝑎𝑡𝑜𝑟𝑠/𝑆𝑐𝑟𝑖𝑝𝑡 𝑖𝑛𝑓𝑜  [!!@𝑆𝑜𝑛𝑖𝑐.ExE 𝑋 !!]\nHelper: Stormii",
                "🛡️ 𝐵𝑦𝑝𝑎𝑠𝑠 [!!𝐎𝐍 🔴!!] ",
                "⚔️ 𝐶𝑜𝑚𝑏𝑎𝑡 [!!𝐎𝐏𝐏!!] ",
                "🏃 𝑀𝑜𝑣𝑒𝑚𝑒𝑛𝑡 [!!FoV 𝐎𝐅𝐅🔴!!] ",
                "❌ 𝐶𝑙𝑜𝑠𝑒 𝑀𝑒𝑛𝑢",
                "🚪 𝐸𝑥𝑖𝑡"
            }

            local choice = gg.multiChoice(menu)

            if choice then  
                if choice[1] then
                    gg.alert("Creator/Coded: 𝑏𝑦 𝑆𝑜𝑛𝑖𝑐.𝐸𝑥𝐸  𝑉 𝟎.𝟏\nHelper/Enc: Stormii")
                    gg.alert("𝑆𝑐𝑟𝑖𝑝𝑡 𝑖𝑛𝑓𝑜 - [ 𝐵𝑎𝑠𝑖𝑐 32-64 𝑏𝑖𝑡 𝑠𝑐𝑟𝑖𝑝𝑡 𝑉 0.1 ]")
                     gg.alert(" [ 🔴- 𝑤𝑎𝑟𝑛𝑖𝑛𝑔 𝑠𝑖𝑔𝑛𝑎𝑙𝑠 ] ")
                     gg.alert(" [ 𝑁𝑒𝑥𝑡 𝑠𝑐𝑟𝑖𝑝𝑡 𝑢𝑝𝑑𝑎𝑡𝑒 𝑆𝑜𝑜𝑛 𝖷𝖣 ×͜× ]")                                                                                 
                    
                end
                if choice[2] then
                    bypassMenu()
                end
                if choice[3] then
                    combatMenu()
                end
                if choice[4] then
                    movementMenu()
                end
                if choice[5] then
                    menuVisible = false  
                    gg.setVisible(false) 
                end
                if choice[6] then
                    gg.toast("Exiting...") 
                    gg.clearResults() 
                    gg.clearList()     
                    os.exit()
                end
            end
        end


        gg.sleep(100) 
        if not menuVisible and gg.isVisible(true) then
            menuVisible = true  
            gg.setVisible(true) 
        end
    end
end

function bypassMenu()
    local bypassOptions = {
        "🛡️ 𝐵𝑦𝑝𝑎𝑠𝑠 1",
        "🛡️ 𝐵𝑦𝑝𝑎𝑠𝑠 2",
        "🛡️ 𝐵𝑦𝑝𝑎𝑠𝑠 3 by Stormii"
    }

    local bypassChoice = gg.multiChoice(bypassOptions)

    if bypassChoice then  
        if bypassChoice[1] then
            menuVisible = false  
            gg.setVisible(false)  
            gg.setRanges(lk)
            gg.searchNumber("h000000000000000080842E41CDCCCCCC", 1)
            gg.getResults(lk)
            gg.editAll("h000000000000000000000000CDCCCCCC", 1)
            gg.clearResults()
            gg.toast("done")
            menuVisible = true 
            gg.setVisible(true) 
        end
        if bypassChoice[2] then
             menuVisible = false  
            gg.setVisible(false)  
            gg.setRanges(4^7)
            
            function V(s, t)
                gg.searchNumber(s, t)
                gg.getResults(1e5)
                gg.editAll(0, t)
                gg.clearResults()
            end
            
            V(1e6, 64)
            V('131277A;0~~0;4096::1877', 4)
            
            gg.toast("Bypass 2 done")
            
            menuVisible = true 
            gg.setVisible(true)  
        end
        if bypassChoice[3] then
            menuVisible = false
            gg.setRanges(gg.REGION_CODE_APP)
            gg.setVisible(false) 
            gg.searchNumber("h63 65 5F 63 73 33 00 48 42 43 68 65 63 6B 00 63 73 63 21 25 73 00 63 73 66 21 25 73 00 63 73 5F 38 30 5F 70 6F 72 74 00 30 5F 30 5F 25 7A 75 00 43 53 33 2C 20 4F 6E 54 69 63 6B 65 74 4F 4B 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 68 65 6C 6C 6F 2C 20 77 6F 72 6C 64 00 00 72 6F 6C 65 5F 69 64 3A 25 73 3B 69 6E 63 5F 69 64 3A 25 64 00 67 65 74 5F 31 5F 25 64 3A 25 70 2C 20 6E 6F 64 65 5F 63 6E 74 3A 25 64 2C 20 72 65 6D 61 69 6E 3A 25 64 2C 20 63 73 33 00 64 65 6C 5F 31 5F 25 64 3A 25 70 2C 20 72 65 6D 61 69 6E 3A 25 64 2C 20 63 73 33 00 63 32 67 5F 72 65 64 69 65 63 74 00 00 04 08 18 0E 61 74 65 5F 62 69 00 63 68 65 63 6B 5F 65 78 74 5F 65 6D 75 5F 66 65 61 74 75 72 65 00 25 63 25 63 3A 25 64 2C 00 65 6D 75 5F 61 6C 65 72 74 3A 25 73 00 65 6D 75 5F 61 6C 65 72 74 00 65 5F 63 5F 6D 21 00 49 43 4F 4E 3A 25 73 3A 00 25 73 57 61 72 6E 69 6E 67 00 49 74 20 69 73 20 66 6F 75 6E 64 20 74 68 61 74 20 79 6F 75 20 61 72 65 20 72 75 6E 6E 69 6E 67 20 69 6E 20 61 6E 20 41 6E 64 72 6F 69 64 20 65 6D 75 6C 61 74 6F 72 2E 20 50 6C 65 61 73 65 20 72 65 73 75 6D 65 20 74 68 65 20 67 61 6D 65 20 61 66 74 65 72 20 72 65 74 75 72 6E 69 6E 67 20 74 6F 20 70 68 79 73 69 63 61 6C 20 64 65 76 69 63 65 73 2E 00 45 78 69 74 00 02 00 04 06 00 66 6F 6F 00 73 74 61 74 5F 72 70 74 00 61 63 65 5F 77 6F 72 6B 65 72 00 61 63 65 5F 77 6F 72 6B 65 72 25 64 00 73 63 5F 69 64 6C 65 00 00 00 00 00 00 00 00 80 84 2E 41 CD CC CC CC CC CC FC 3F 66 66 66 66 66 66 FE 3F 00 00 00 00 00 00 00 00 00 00 00 00 2C 01 00 00 00 00 00 00 84 03 00 00 96 00 00 00 08 00 00 00 3C 00 00 00 00 00 00 00 61 63 65 5F 73 63 68 65 64 75 6C 65 33 00 73 63 5F 64 6C 70 00 2B 20 72 65 70 6F 72 74 5F 62 6B 00 68 62 5F 6C 6F 6F 70 00 71 6F 73 5F 6C 6F 6F 70 00 69 6E 74 65 72 66 61 63 65 5F 74 65 73 74 00 73 63 00 25 64 3A 25 64 3A 25 64 3A 25 64 00 72 32 72 33 5F 65 72 72 00 6E 61 6D 65 3A 25 73 2C 20 63 61 73 74 3A 25 6C 64 00 6F 6E 73 65 6C 65 63 74 5F 61 6C 65 72 74 00 66 63 63 31 2E 64 00 21 64 6C 20 25 64 00 63 64 6E 3A 25 73 00 63 6F 6E 66 69 67 32 2E 78 6D 6C 00 21 64 63 66 00 21 70 63 66 00 21 64 73 66 00 64 6C 20 25 73 2C 20 72 65 74 76 61 6C 3A 25 64 2C 20 73 69 7A 65 3A 25 64 2C 20 63 61 63 68 65 3A 25 64 2C 20 6A 64 3A 25 64 00 63 6F 6D 6D 5F 66 69 72 73 74 00 73 69 67 20 63 75 73 74 6F 6D 2C 20 6E 61 6D 65 3A 25 73 2C 20 6C 65 6E 3A 25 64 2C 20 63 72 63 3A 25 30 38 78 00 63 6F 6E 66 69 67 33 2E 78 6D 6C 00 6D 65 6D 73 61 66 65 00 76 65 72 3A 25 73 20 61 70 70 5F 76 65 72 3A 25 73 20 63 6F 64 65 5F 73 69 7A 65 3A 25 73 20 63 72 63 3A 25 73 00 72 62 00 00 00 00 00 00 00 00 00 00 00 00 00 00 05 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 72 65 73 75 6C 74 3D 65 72 72 6F 72 00 00 00 00 38 DE 00 00 01 00 00 00 39 DE 00 00 01 00 00 00 3A DE 00 00 01 00 00 00 00 64 FD 82 FD FD FD A1 00 16 35 20 35 35 35 2A 00 00 00 00 00 00 00 00 01 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 77 73 61 5F 70 6F 70 65 6E 5F 69 70 00 77 73 61 5F 6E 65 74 6C 69 6E 6B 5F 69 70 00 77 73 61 5F 75 64 70 5F 69 70 00 25 75 3A 73 3B 70 3A 25 73 00 00 00 00 3A 8F 00 00 91 93 00 00 E8 97 00 00 00 61 22 3D 61 61 61 61 61 28 00 72 39 72 5A 72 72 63 72 6C 72 63 76 5F 25 64 2C 6C 65 6E 3A 25 64 2C 63 73 3A 25 64 00 67 5F 64 6C 5F 63 68 61 6E 6E 65 6C 00 70 5F 69 37 2E 64 61 74 00 72 5F 69 37 2E 64 61 74 00 72 65 63 6F 72 64 00 66 69 6C 65 73 2D 64 69 72 3A 25 73 2C 20 69 6E 69 74 65 64 3A 31 00 66 6C 61 67 73 3A 00 72 61 74 65 3A 25 64 00 67 61 6D 65 5F 76 65 72 3A 25 73 20 73 64 6B 5F 76 65 72 3A 25 73 00 33 2E 31 00 6A 61 72 5F 76 65 72 3A 25 73 2C 63 65 72 74 5F 65 6E 76 3A 25 73 00 6D 69 6E 5F 61 70 69 3A 25 64 2C 74 61 72 67 65 74 5F 61 70 69 3A 25 64 00 6D 61 78 5F 75 73 65 72 5F 77 61 74 63 68 65 73 3A 25 73 00 72 6F 6F 74 5F 61 6C 65 72 74 3A 25 73 00 72 6F 6F 74 5F 61 6C 65 72 74 00 72 70 64 61 74 61 32 00 63 73 3A 25 73 00 25 30 38 78 25 30 38 78 25 30 38 78 00 00 30 75 00 00 40 00 00 00 03 00 00 00 00 00 00 00 63 6C 6B 5F 61 64 62 00 41 75 74 6F 43 6C 69 63 6B 65 72 20 66 6F 75 6E 64 20 6F 6E 20 79 6F 75 72 20 70 68 6F 6E 65 2E 20 54 6F 20 63 6F 6E 74 69 6E 75 65 2C 20 64 72 61 67 20 74 68 65 20 73 63 72 6F 6C 6C 20 62 61 72 20 74 6F 20 74 68 65 20 6E 75 6D 62 65 72 20 25 64 2E 00 43 75 72 72 65 6E 74 20 6E 75 6D 62 65 72 20 69 73 3A 20 3B 25 64 3B 25 64 00 63 6C 6B 5F 72 70 74 00 25 73 2F 25 73 00 63 6F 6D 2F 63 6F 63 6F 73 2F 6C 69 62 2F 43 6F 63 6F 73 41 63 74 69 76 69 74 79 00 64 74 00 6D 53 75 72 66 61 63 65 56 69 65 77 00 4C 63 6F 6D 2F 63 6F 63 6F 73 2F 6C 69 62 2F 43 6F 63 6F 73 53 75 72 66 61 63 65 56 69 65 77 3B 00 73 65 74 4F 6E 74 6F 75 63 68 52 65 74 56 61 6C 00 28 5A 29 56 00 00 00 01 02 03 04 05 06 07 08 09 0A 0B 0C 0D 0E 0F 9A 99 99 99 99 99 C9 3F 71 3D 0A D7 A3 70 E5 3F 61 6E 6F 2C 64 72 6F 70 3A 25 73 3A 25 73 00 61 6E 6F 5F 74 69 70 5F 70 6B 67 00 6D 73 67 62 6F 78 5F 62 75 74 74 6F 6E 5F 31 30 30 30 31 00 61 6E 6F 5F 69 63 6F 6E 00 6D 73 67 62 6F 78 5F 63 6F 6E 74 65 6E 74 5F 31 30 30 30 31 00 4D 61 6C 77 61 72 65 20 66 6F 75 6E 64 20 6F 6E 20 79 6F 75 72 20 70 68 6F 6E 65 2E 20 50 6C 65 61 73 65 20 75 6E 69 6E 73 74 61 6C 6C 20 69 74 20 62 65 66 6F 72 65 20 65 6E 74 65 72 69 6E 67 20 74 68 65 20 67 61 6D 65 2E 28 00 61 6E 6F 5F 74 69 6D 65 00 21 66 6F 72 63 65 3A 6D 73 67 5F 62 6F 78 3A 74 69 6D 65 6F 75 74 00 77 68 6F 61 72 65 79 6F 75 3F 00 61 6E 6F 5F 66 63 00 61 6E 6F 5F 63 65 72 74 5F 6D 64 35 00 47 47 00 67 67 00 63 6F 6D 2E 00 61 6E 6F 5F 69 67 6E 6F 72 65 5F 64 65 74 65 63 74 00 61 6E 6F 5F 73 79 73 00 61 6E 6F 5F 63 66 69 6C 74 00 25 75 2E 25 75 2E 25 73 00 44 65 78 53 63 61 6E 00 63 6F 6D 2E 64 74 73 2E 66 72 65 65 66 69 72 65 74 68", gg.TYPE_BYTE, false, gg.SIGN_EQUAL, 0, -1, 0)
            revert = gg.getResults(100000, nil, nil, nil, nil, nil, nil, nil, nil)
            gg.editAll("0", gg.TYPE_BYTE)
            revert = gg.getResults(100000, nil, nil, nil, nil, nil, nil, nil, nil)
            gg.editAll("0", gg.TYPE_BYTE)
            gg.setVisible(false)
            gg.clearResults()
            gg.setRanges(gg.REGION_CODE_APP)
            gg.searchNumber("28 548 151 168 164 723", gg.TYPE_QWORD)
            local b = gg.getResults(99999)
            gg.addListItems(b)
            b = nil
            local a = false
            local b = gg.getListItems()
            if not a then gg.removeListItems(b) end
            for i, v in ipairs(b) do
                v.address = v.address + 0x13
                if a then v.name = v.name..' #2' end
            end
            gg.addListItems(b)
            b = nil
            a = nil
            revert = gg.getListItems()
            local b = gg.getListItems()
            for i, v in ipairs(b) do
                    v.flags = gg.TYPE_BYTE
                    v.value = "0"
                    v.freeze = true
                    v.freezeType = gg.FREEZE_IN_RANGE
                    v.freezeFrom = "0"
                    v.freezeTo = "1"
            end
            gg.addListItems(b)
            b = nil
            gg.clearResults()
            gg.clearList()
            gg.toast('Successfully!🟢 🔴Double Bypass by Stormii🔴')
        end
    end
end        
local noDelayEnabled = false
local fastBreakEnabled = false
local hitboxEnabled = false
local attackCooldownEnabled = false
local fpsUnlockEnabled = false
local fovEnabled = false
local AutoClickerEnabled = false
function clearSearchList()
    gg.clearResults()  
end

function enableHitbox()
    gg.setVisible(false)
    gg.clearResults()            

gg.setRanges(gg.REGION_C_ALLOC)


gg.searchNumber("1058642330D;180", gg.TYPE_FLOAT)
gg.refineNumber("1058642330", gg.TYPE_DWORD)
local results2 = gg.getResults(1000)  

if #results2 > 0 then
    for i, v in ipairs(results2) do
        v.value = 1083642330  
        v.flags = gg.TYPE_DWORD
    end
    gg.setValues(results2)
end


gg.clearResults()


gg.searchNumber("1083642330D;1.62", gg.TYPE_FLOAT)


gg.refineNumber("1083642330", gg.TYPE_DWORD)


local refinedResults = gg.getResults(1000)  
if #refinedResults > 0 then
    for i, v in ipairs(refinedResults) do
        v.value = 1058642330  
        v.flags = gg.TYPE_DWORD
    end
    gg.setValues(refinedResults)
end


gg.clearResults()


gg.searchNumber("1.8;180", gg.TYPE_FLOAT)
gg.refineNumber("1.8", gg.TYPE_FLOAT)
local results3 = gg.getResults(1000) 

if #results3 > 0 then
    for i, v in ipairs(results3) do
        v.value = 2.4 
    end
    gg.setValues(results3)
    
    gg.clearResults()
end


gg.toast("HB enabled successfully.")

function clearSearchList()
    gg.clearResults()  
end

end
function disableHitbox()
    clearSearchList()  
    gg.setRanges(gg.REGION_C_ALLOC)  

    gg.searchNumber("1083642330D;180", gg.TYPE_FLOAT)
    gg.refineNumber("1083642330", gg.TYPE_DWORD)
    local results2 = gg.getResults(1000)  

    if #results2 > 0 then
        for i, v in ipairs(results2) do
            v.value = 1058642330  
            v.flags = gg.TYPE_DWORD
        end
        gg.setValues(results2)
    end

    clearSearchList()  

    gg.searchNumber("2.4;180", gg.TYPE_FLOAT)
    gg.refineNumber("2.4", gg.TYPE_FLOAT)
    local results3 = gg.getResults(1000)  

    if #results3 > 0 then
        for i, v in ipairs(results3) do
            v.value = 1.8  
        end
        gg.setValues(results3)
    end

    clearSearchList()  
    gg.toast("HB disabled successfully.")
end

function clearSearchList()
    gg.clearResults() 
end

function enableNoDelay()    
    clearSearchList() 
    gg.setRanges(gg.REGION_C_ALLOC)
    gg.searchNumber("200;5;6.5", gg.TYPE_FLOAT)
    gg.refineNumber("6.5", gg.TYPE_FLOAT)
    local results = gg.getResults(1)

    if #results > 0 then
        local targetAddress = results[1].address - 608
        gg.setValues({{address = targetAddress, flags = gg.TYPE_DWORD, value = 1}})
        gg.addListItems({{address = targetAddress, flags = gg.TYPE_DWORD, value = 1}})
        gg.toast("No Delay Enabled")
    else
        gg.toast("No Delay Search Failed")
    end

    clearSearchList()
    gg.clearList()  
end

function disableNoDelay()
    clearSearchList() 
    gg.setRanges(gg.REGION_C_ALLOC)
    gg.searchNumber("200;5;6.5", gg.TYPE_FLOAT)
    gg.refineNumber("6.5", gg.TYPE_FLOAT)
    local results = gg.getResults(1)

    if #results > 0 then
        local targetAddress = results[1].address - 608
        gg.setValues({{address = targetAddress, flags = gg.TYPE_DWORD, value = 0}})
        gg.removeListItems(results)
        gg.toast("No Delay Disabled")
    else
        gg.toast("No Delay Search Failed")
    end
clearSearchList() 
    gg.clearList() 
end

function enableFastBreak()
    clearSearchList()  
    gg.setRanges(gg.REGION_C_ALLOC)
    gg.searchNumber("4 575 657 222 467 066 266", gg.TYPE_QWORD, false, gg.SIGN_EQUAL, 0, -1, 0)
    local results = gg.getResults(99999)

    
    local originalValues = {}
    for i, item in ipairs(results) do
        
        table.insert(originalValues, {address = item.address - 68, value = item.value, flags = item.flags})
    end

    gg.addListItems(results)

    for _, item in ipairs(results) do
        item.address = item.address - 68
        item.flags = gg.TYPE_FLOAT
    end

    gg.addListItems(results)
    gg.loadResults(results)

    gg.refineNumber("0.00001~1000", gg.TYPE_FLOAT)
    local refinedResults = gg.getResults(99999)
    if #refinedResults > 0 then
        gg.editAll("0", gg.TYPE_FLOAT)
    else
        gg.toast("Fast Break Search Failed")
    end

    clearSearchList() 
    gg.clearList() 
    gg.toast("Fast Break Enabled")
end

function disableFastBreak()
    clearSearchList()
    gg.setRanges(gg.REGION_C_ALLOC)
    gg.searchNumber("4 575 657 222 467 066 266", gg.TYPE_QWORD, false, gg.SIGN_EQUAL, 0, -1, 0)
    local results = gg.getResults(99999)

  
    local originalValues = {}
    for i, item in ipairs(results) do
       
        table.insert(originalValues, {address = item.address - 68, value = item.value, flags = item.flags})
    end

    if originalValues ~= nil then
        for _, item in ipairs(originalValues) do
            gg.setValues({item})  
        end
    end

    clearSearchList()  
    gg.clearList()  
    gg.toast("Fast Break Disabled")
end

function enableAttackCooldown()
    gg.setRanges(gg.REGION_C_ALLOC)
    gg.setVisible(false)
    gg.searchNumber("7405825", gg.TYPE_DWORD)

    local results = gg.getResults(gg.getResultCount())
    for i, v in ipairs(results) do
        v.address = v.address - 8
        v.value = "0"
        v.freeze = true
    end
    gg.setValues(results)
    gg.addListItems(results)

    gg.clearResults()
    gg.searchNumber("7405825", gg.TYPE_DWORD)

    local results2 = gg.getResults(gg.getResultCount())
    for i, v in ipairs(results2) do
        v.address = v.address + 0x28
        v.value = "0"
        v.freeze = true
    end
    gg.setValues(results2)
    gg.addListItems(results2)

    gg.clearResults()
    gg.toast("Attack Cooldown Enabled.")
end

function disableAttackCooldown()
    gg.setRanges(gg.REGION_C_ALLOC)
    gg.setVisible(false)
    gg.searchNumber("7405825", gg.TYPE_DWORD)

    local results = gg.getResults(gg.getResultCount())
    for i, v in ipairs(results) do
        v.address = v.address - 8
        gg.removeListItems({v})
    end

    gg.clearResults()
    gg.searchNumber("7405825", gg.TYPE_DWORD)

    local results2 = gg.getResults(gg.getResultCount())
    for i, v in ipairs(results2) do
        v.address = v.address + 0x28
        gg.removeListItems({v})
    end

    gg.clearResults()
    gg.toast("Attack Cooldown Disabled.")
end
function enableFPSUnlock()
    gg.clearResults()
    gg.setRanges(gg.REGION_ANONYMOUS)
 gg.searchNumber("16", gg.TYPE_BYTE)
 results = gg.getResults(100)

 if #results > 0 then
    for i = 1, math.min(2, #results) do
        results[i].value = 0
    end
    gg.setValues(results)
    gg.clearResults()
    gg.toast("fps unlocked")
    else
    gg.toast("No results found.")
 end
end
function disableFPSUnlock()
    gg.clearResults()
    gg.setRanges(gg.REGION_ANONYMOUS)

    local address = {{address = 0x08FEE224, flags = gg.TYPE_BYTE}}
    gg.getValues(address)
    address[1].value = 16 
    gg.setValues(address)

    gg.clearResults()
    gg.toast("FPS Unlock Disabled.")
end
function enableFOV()
    clearSearchList()
    gg.setRanges(gg.REGION_C_ALLOC)
    gg.searchNumber("1.62", gg.TYPE_FLOAT)

    local results = gg.getResults(100)  
    for i = 1, #results do
        results[i].value = 1.7
    end
    gg.setValues(results)

    clearSearchList()
    gg.toast("FOV Enabled.")
end
function disableFOV()
    clearSearchList()
    gg.setRanges(gg.REGION_C_ALLOC)

    gg.searchNumber("1.7", gg.TYPE_FLOAT)

    local results = gg.getResults(100)  
    for i = 1, #results do
        results[i].value = 1.62
    end
    gg.setValues(results)

    clearSearchList()
    gg.toast("FOV Disabled.")
  end

function enableAutoClicker()
    gg.setRanges(gg.REGION_C_ALLOC)  
    gg.searchNumber('1054168405', gg.TYPE_DWORD)  
    local results = gg.getResults(1)  

    if #results > 0 then
        results[1].address = results[1].address + 0x48  
        results[1].flags = gg.TYPE_DWORD  
        results[1].value = 1  
        gg.setValues(results)  

        results[1].freeze = true  
        gg.setValues(results)  

        gg.addListItems(results)  
        gg.toast('Value edited and frozen successfully!')
    else
        gg.toast('No results found for 1054168405')
    end

    gg.clearResults()  
end
function disableAutoClicker()
    local results = gg.getListItems()  
    for i, item in ipairs(results) do
        if item.value == 1 then  
            item.freeze = false  
            gg.setValues({item})  
            gg.removeListItems({item})  
            gg.toast('Value unfrozen and removed from the save list!')
            return
        end
    end
    gg.toast('No matching value found to turn off.')
end
function Aimbot()
    function Sv(v, rg, fg)
        rt = {}
        gg.setRanges(rg)
        gg.searchNumber(v[1], fg)
        local r = gg.getResults(999999)
        if #r == 0 then gg.toast("NOT VALUE 1") return rt end
        for iv = 2, #v do
            for i = 1, #r do
                r[i].address = r[i].address + v[iv][2]
            end
            local rr = gg.getValues(r)
            tt = {}
            for i = 1, #rr do
                if rr[i].value == v[iv][1] then
                    ii = #tt + 1
                    tt[ii] = {}
                    tt[ii].address = rr[i].address - v[iv][2]
                    tt[ii].flags = fg
                end
            end
            if #tt == 0 then gg.clearResults() gg.toast("NOT VALUE 2") return rt end
            r = gg.getValues(tt)
            if iv == #v then rt = r return rt end
        end
        gg.clearResults()
        return rt
    end
    
    gg.sleep(1000)
    
    function F()
        gg.clearList()
        gg.clearResults()
        v = 1
        gg.setVisible(false)
        rr = Sv({1127481344, {300, -71 * 4}, {0, -75 * 4}}, 4, 4)
        if #rr == 0 then gg.clearResults() gg.toast("NOT VALUE 1") return else
            gg.clearResults() gg.toast(#rr .. " PLAYER")
            r = Sv({1070554153, {1070554153, 0}}, 4, 4)
            if #r == 0 then gg.clearResults() gg.toast("NOT VALUE 2") return else
                gg.clearResults() gg.toast("AIMBOT Is ON")
            end
        end
     gg.setVisible(false)
    
       
        local smoothFactor = 0.2 
        local currentYaw = 0
        local currentPitch = 0
    
        while true do
            if gg.isVisible(true) then
                gg.setVisible(false) gg.clearList() gg.clearResults()
                gg.toast("AIMBOT OFF") return
            end
            if v == #rr + 1 then v = 1 end
            if rr[v].value ~= 1127481344 then
                v = v + 1
            else
                u = v
                for i, v in ipairs(r) do
                    local address = v.address
                    xA = gg.getValues({{address = address - 40 * 4, flags = 16}})[1].value
                    yA = gg.getValues({{address = address - 41 * 4, flags = 16}})[1].value
                    zA = gg.getValues({{address = address - 42 * 4, flags = 16}})[1].value
                    myHP = gg.getValues({{address = address + 28 * 4, flags = 64}})[1].value
                end
                
                local xx = {}
                xx[u] = {}
                xx[u].flags = 16
                xx[u].address = rr[u].address + -115 * 4
                xB = gg.getValues(xx)[u].value
                xx[u].address = rr[u].address + -116 * 4
                yB = gg.getValues(xx)[u].value
                xx[u].address = rr[u].address + -117 * 4
                zB = gg.getValues(xx)[u].value
                
                local hp = {}
                hp[u] = {}
                hp[u].flags = 64
                hp[u].address = rr[u].address + -47 * 4
                HP = gg.getValues(hp)[u].value    
     if myHP < 0.123 then
                    gg.toast("AIMBOT Is OFF") gg.clearList() return
                end
                if HP < 0.123 then v = v + 1 else
                    local kc = math.sqrt((xB - xA)^2 + (zB - zA)^2)
                    local ha = yB - yA
                    local hh = math.abs(ha)
                    local ka = math.abs(kc)
                    if kc > 7 then v = v + 1 else
                        if hh > 7 then v = v + 1 else
                            local targetPitch = math.atan2(hh, ka) * 180 / math.pi
                            if ha > 0 then targetPitch = targetPitch * (-1) end
                            local targetYaw = math.atan2(xB - xA, zB - zA) * 180 / math.pi - 90
                            
                           
                            local adaptiveSmoothFactor = smoothFactor + (kc / 15) 
                            
                            
                            currentYaw = currentYaw + (targetYaw - currentYaw) * adaptiveSmoothFactor
                            currentPitch = currentPitch + (targetPitch - currentPitch) * adaptiveSmoothFactor
    
                            
                            tt = {}
                            for i = 1, #r do
                                ii = #tt + 1
                                tt[ii] = {}
                                tt[ii].flags = 16
                                tt[ii].address = r[i].address + -47 * 4
                                tt[ii].value = currentPitch
                                gg.setValues(tt)
                                tt[ii].address = r[i].address + -48 * 4
                                tt[ii].value = currentYaw
                                gg.setValues(tt)
                            end
                        end
                    end    
        
                end
            end
            gg.sleep(5) 
        end
    end
    
    F()
end
function combatMenu()
    local combatOptions = {
        "⏱️ 𝑁𝑜 𝑑𝑒𝑙𝑎𝑦: " .. (noDelayEnabled and "✘" or "✓"),  
        "🪓 𝐹𝑎𝑠𝑡 𝐵𝑟𝑎𝑘𝑒: " .. (fastBreakEnabled and "[!!🔴𝑴𝒂𝒚 𝑪𝒓𝒂𝒔𝒉 𝒔𝒐 𝒅𝒐𝒏'𝒕 𝒐𝒇𝒇🔴!!] ✘" or "✓"),
        "🎯 𝐻𝑖𝑡𝑏𝑜𝑥" .. (hitboxEnabled and "✘" or "✓"),
        "🏰 𝐵𝑒𝑑 𝑤𝑎𝑟𝑠 𝑎𝑡𝑘 𝐶𝐷 🛏️" .. (attackCooldownEnabled and "✘" or "✓"),
        "🖥️ 𝐹𝑝𝑠 𝑈𝑛𝑙𝑜𝑐𝑘" .. (fpsUnlockEnabled and "✘" or "✓"),
        "🔍 𝐹𝑜𝑣"  .. (fovEnabled and "✘" or "✓"),
        "⚡ 𝐴𝑢𝑡𝑜𝑐𝑙𝑖𝑐𝑘𝑒𝑟" .. (AutoClickerEnabled and "✘" or "✓"),
        "Aimbot",
    }
    local combatChoice = gg.multiChoice(combatOptions)

    if combatChoice then
        if combatChoice[1] then
            noDelayEnabled = not noDelayEnabled  
            if noDelayEnabled then
                gg.setVisible(false)  
                enableNoDelay() 
            else
                gg.setVisible(false)  
                disableNoDelay() 
            end
        end

        if combatChoice[2] then
            fastBreakEnabled = not fastBreakEnabled  
            if fastBreakEnabled then
                gg.setVisible(false) 
                enableFastBreak() 
            else
                gg.setVisible(false) 
                disableFastBreak()  
            end
        end
  if combatChoice[3] then
            hitboxEnabled = not hitboxEnabled
            if hitboxEnabled then
            gg.setVisible(false)
if gg.setVisible(true) then
    gg.clearResults() 
    gg.clearList()     
    os.exit() 
end                                                                                                                       enableHitbox()  
            else
                gg.setVisible(false)  
                disableHitbox()  
            end
        end
                      
  if combatChoice[4] then
                attackCooldownEnabled = not attackCooldownEnabled  
                if attackCooldownEnabled then
                    gg.setVisible(false)  
                    enableAttackCooldown()  
                else
                    gg.setVisible(false)  
                    disableAttackCooldown()  
                end
            end
  if combatChoice[5] then
        fpsUnlockEnabled = not fpsUnlockEnabled
        if fpsUnlockEnabled then
            gg.setVisible(false)                                                                                
            enableFPSUnlock()                                                  
            else                                                                                                                   gg.setVisible(false)                                                                                                    disableFPSUnlock() 
         end   
      end                 
  if combatChoice[6]  then        
      fovEnabled = not fovEnabled
        if fovEnabled then 
        gg.setVisible (false)        
        enableFOV() 
        else 
        gg.setVisible(false)                
        disableFOV()                                              
     end               
   end  
  if combatChoice [7]  then
    AutoClickerEnabled = not AutoClickerEnabled
     if AutoClickerEnabled  then                            
      gg.setVisible (false)
        enableAutoClicker()
      else
          gg.setVisible(false)
          disableAutoClicker()
      end               
   end
 end
 if combatChoice [8] then
    gg.setVisible(false)
    Aimbot()
else
end
end


function speedMenu()
    local speedOptions = {
        "⚡ Speed x1 " .. (speedX1Enabled and "✘" or "✓"),
        "⚡ Speed x2 " .. (speedX2Enabled and "✘" or "✓"),
        "⚡ Speed x3 " .. (speedX3Enabled and "✘" or "✓"),
    }

    local speedChoice = gg.multiChoice(speedOptions)

    if speedChoice then
        if speedChoice[1] then
            if speedX1Enabled then
                speedX1Off()
            else
                speedX1()
            end
            speedX1Enabled = not speedX1Enabled
        end

        if speedChoice[2] then
            if speedX2Enabled then
                speedX2Off()
            else
                speedX2()
            end
            speedX2Enabled = not speedX2Enabled
        end

        if speedChoice[3] then
            if speedX3Enabled then
                speedX3Off()
            else
                speedX3()
            end
            speedX3Enabled = not speedX3Enabled
        end
    end
end

 
function speedX1()
    gg.setVisible(false) 
    gg.clearResults() 

    
    gg.setRanges(gg.REGION_CODE_APP)

    
    gg.searchNumber("1.62", gg.TYPE_FLOAT)

   
    local results = gg.getResults(100)

    if #results == 0 then
        gg.toast("No results found")
    else
       
        for i, v in ipairs(results) do
            results[i].address = v.address - 0x1C4 
            results[i].flags = gg.TYPE_FLOAT
            results[i].value = "0.25" 
        end

        gg.setValues(results)
        gg.toast("Speed x1 enabled successfully!")
    end

    gg.clearResults()  
end
function speedX1Off()
    gg.setVisible(false)  
    gg.clearResults() 

    
    gg.setRanges(gg.REGION_CODE_APP)

   
    gg.searchNumber("1.62", gg.TYPE_FLOAT)

   
    local results = gg.getResults(100)

    if #results == 0 then
        gg.toast("No results found")
    else
        
        for i, v in ipairs(results) do
            results[i].address = v.address - 0x1C4  
            results[i].flags = gg.TYPE_FLOAT
            results[i].value = "0.16277135909" 
        end

        gg.setValues(results)
        gg.toast("Speed disabled successfully!")
    end

    gg.clearResults()  
end
function speedX2()
    gg.setVisible(false) 
    gg.clearResults() 

    
    gg.setRanges(gg.REGION_CODE_APP)

   
    gg.searchNumber("1.62", gg.TYPE_FLOAT)

    
    local results = gg.getResults(100)

    if #results == 0 then
        gg.toast("No results found")
    else
       
        for i, v in ipairs(results) do
            results[i].address = v.address - 0x1C4 
            results[i].flags = gg.TYPE_FLOAT
            results[i].value = "0.30"  
        end

        gg.setValues(results)
        gg.toast("Speed enabled successfully!")
    end

    gg.clearResults() 
end
function speedX2Off()
    gg.setVisible(false)  
    gg.clearResults()  

    
    gg.setRanges(gg.REGION_CODE_APP)

    
    gg.searchNumber("1.62", gg.TYPE_FLOAT)

   
    local results = gg.getResults(100)

    if #results == 0 then
        gg.toast("No results found")
    else
        
        for i, v in ipairs(results) do
            results[i].address = v.address - 0x1C4 
            results[i].flags = gg.TYPE_FLOAT
            results[i].value = "0.16277135909" 
        end
        
        gg.setValues(results)
        gg.toast("Speed disabled successfully!")
    end

    gg.clearResults() 
end
function speedX3()
    gg.clearResults()  

    
    gg.setRanges(gg.REGION_CODE_APP)

    
    gg.searchNumber("1.62", gg.TYPE_FLOAT)

   
    local results = gg.getResults(100)

    if #results == 0 then
        gg.toast("No results found")
    else
        
        for i, v in ipairs(results) do
            results[i].address = v.address - 0x1C4  
            results[i].flags = gg.TYPE_FLOAT
            results[i].value = "0.35" 
        end
        
        gg.setValues(results)
        gg.toast("Speed enabled successfully!")
    end

    gg.clearResults()  
end
function speedX3Off()
    gg.clearResults()  

   
    gg.setRanges(gg.REGION_CODE_APP)

   
    gg.searchNumber("1.62", gg.TYPE_FLOAT)

   
    local results = gg.getResults(100)

    if #results == 0 then
        gg.toast("No results found")
    else
       
        for i, v in ipairs(results) do
            results[i].address = v.address - 0x1C4 
            results[i].flags = gg.TYPE_FLOAT
            results[i].value = "0.16277135909"  
        end
        
        gg.setValues(results)
        gg.toast("Speed disabled successfully!")
    end

    gg.clearResults()  
end
function gameSpeedMenu()
    local gameSpeedOptions = {
        "🎮 Game Speed x1 " .. (gameSpeedX1Enabled and "✘" or "✓"),
        "🎮 Game Speed x2 " .. (gameSpeedX2Enabled and "✘" or "✓"),
        "🎮 Game Speed x3 " .. (gameSpeedX3Enabled and "✘" or "✓"),
    }

    local gameSpeedChoice = gg.multiChoice(gameSpeedOptions)

    if gameSpeedChoice then
     if gameSpeedChoice[1] then
            if gameSpeedX1Enabled then
                gameSpeedX1Off()
            else
                gameSpeedX1()
            end
            gameSpeedX1Enabled = not gameSpeedX1Enabled
        end
     if gameSpeedChoice[2] then
            if gameSpeedX2Enabled then
                gameSpeedX2Off()
            else
                gameSpeedX2()
            end
            gameSpeedX2Enabled = not gameSpeedX2Enabled
        end
        if gameSpeedChoice[3] then
            if gameSpeedX3Enabled then
                gameSpeedX3Off()
            else
                gameSpeedX3()
            end
            gameSpeedX3Enabled = not gameSpeedX3Enabled
        end
    end
end
function gameSpeedX1()
    gg.setVisible(false)
    gg.clearResults()
    gg.setRanges(gg.REGION_CODE_APP)
    gg.searchNumber("1.62", gg.TYPE_FLOAT)
    local results = gg.getResults(100)

    if #results == 0 then
        gg.toast("No results found")
    else
        for i, v in ipairs(results) do
            results[i].address = v.address - 0x2D0
            results[i].flags = gg.TYPE_FLOAT
            results[i].value = "-0.04000006791"  
        end
        gg.setValues(results)
        gg.toast("Game Speed x1 enabled successfully!")
    end

    gg.clearResults()
end
function gameSpeedX1Off()
    gg.setVisible(false)
    gg.clearResults()
    gg.setRanges(gg.REGION_CODE_APP)
    gg.searchNumber("1.62", gg.TYPE_FLOAT)
    local results = gg.getResults(100)

    if #results == 0 then
        gg.toast("No results found")
    else
        for i, v in ipairs(results) do
            results[i].address = v.address - 0x2D0
            results[i].flags = gg.TYPE_FLOAT
            results[i].value = "-0.05000006791"  
        end
        gg.setValues(results)
        gg.toast("Game Speed x1 disabled successfully!")
    end

    gg.clearResults()
end
function gameSpeedX2()
    gg.setVisible(false)
    gg.clearResults()
    gg.setRanges(gg.REGION_CODE_APP)
    gg.searchNumber("1.62", gg.TYPE_FLOAT)
    local results = gg.getResults(100)

    if #results == 0 then
        gg.toast("No results found")
    else
        for i, v in ipairs(results) do
            results[i].address = v.address - 0x2D0
            results[i].flags = gg.TYPE_FLOAT
            results[i].value = "-0.03000006791" 
        end
        gg.setValues(results)
        gg.toast("Game Speed x2 enabled successfully!")
    end

    gg.clearResults()
end
function gameSpeedX2Off()
    gg.setVisible(false)
    gg.clearResults()
    gg.setRanges(gg.REGION_CODE_APP)
    gg.searchNumber("1.62", gg.TYPE_FLOAT)
    local results = gg.getResults(100)

    if #results == 0 then
        gg.toast("No results found")
    else
        for i, v in ipairs(results) do
            results[i].address = v.address - 0x2D0
            results[i].flags = gg.TYPE_FLOAT
            results[i].value = "-0.05000006791"  
        end
        gg.setValues(results)
        gg.toast("Game Speed x2 disabled successfully!")
    end

    gg.clearResults()
end  
function gameSpeedX3()
    gg.setVisible(false)
    gg.clearResults()
    gg.setRanges(gg.REGION_CODE_APP)
    gg.searchNumber("1.62", gg.TYPE_FLOAT)
    local results = gg.getResults(100)

    if #results == 0 then
        gg.toast("No results found")
    else
        for i, v in ipairs(results) do
            results[i].address = v.address - 0x2D0
            results[i].flags = gg.TYPE_FLOAT
            results[i].value = "-0.02000006791" 
        end
        gg.setValues(results)
        gg.toast("Game Speed x3 enabled successfully!")
    end

    gg.clearResults()
end
function gameSpeedX3Off()
    gg.setVisible(false)
    gg.clearResults()
    gg.setRanges(gg.REGION_CODE_APP)
    gg.searchNumber("1.62", gg.TYPE_FLOAT)
    local results = gg.getResults(100)

    if #results == 0 then
        gg.toast("No results found")
    else
        for i, v in ipairs(results) do
            results[i].address = v.address - 0x2D0
            results[i].flags = gg.TYPE_FLOAT
            results[i].value = "-0.05000006791" 
        end
        gg.setValues(results)
        gg.toast("Game Speed x3 disabled successfully!")
    end

    gg.clearResults()
end   
function airspeedMenu()
    local airspeedOptions = {
        "💨 Airspeed x1 " .. (airspeedX1Enabled and "✘" or "✓"),
        "💨 Airspeed x2 " .. (airspeedX2Enabled and "✘" or "✓"),
        "💨 Airspeed x3 " .. (airspeedX3Enabled and "✘" or "✓"),
    }

    local airspeedChoice = gg.multiChoice(airspeedOptions)

    if airspeedChoice then
        if airspeedChoice[1] then
            if airspeedX1Enabled then
                airspeedX1Off()
            else
                airspeedX1()
            end
            airspeedX1Enabled = not airspeedX1Enabled
        end
        if airspeedChoice[2] then
            if airspeedX2Enabled then
                airspeedX2Off()
            else
                airspeedX2()
            end
            airspeedX2Enabled = not airspeedX2Enabled
        end
        if airspeedChoice[3] then
            if airspeedX3Enabled then
                airspeedX3Off()
            else
                airspeedX3()
            end
            airspeedX3Enabled = not airspeedX3Enabled
        end
    end
end
function airspeedX1()
    gg.setVisible(false)
    gg.clearResults()

    gg.setRanges(gg.REGION_C_ALLOC)
    gg.searchNumber("1.62", gg.TYPE_FLOAT)

    local results = gg.getResults(100)

    if #results == 0 then
        gg.toast("No results found")
    else
        for i, v in ipairs(results) do
            gg.addListItems(results)
            results[i].address = v.address + 0x2B0
            results[i].flags = gg.TYPE_FLOAT
            results[i].value = "0.03"
        end

        gg.setValues(results)
        gg.toast("Airspeed x1 enabled successfully!")
    end

    gg.clearResults()
end
function airspeedX1Off()
    gg.setVisible(false)
    gg.clearResults()

    gg.setRanges(gg.REGION_C_ALLOC)
    gg.searchNumber("1.62", gg.TYPE_FLOAT)

    local results = gg.getResults(100)

    if #results == 0 then
        gg.toast("No results found")
    else
        for i, v in ipairs(results) do
            gg.addListItems(results)
            results[i].address = v.address + 0x2B0
            results[i].flags = gg.TYPE_FLOAT
            results[i].value = "0.02"
        end

        gg.setValues(results)
        gg.toast("Airspeed x1 disabled successfully!")
    end

    gg.clearResults()
end
function airspeedX2()
    gg.setVisible(false)
    gg.clearResults()

    gg.setRanges(gg.REGION_C_ALLOC)
    gg.searchNumber("1.62", gg.TYPE_FLOAT)

    local results = gg.getResults(100)

    if #results == 0 then
        gg.toast("No results found")
    else
        for i, v in ipairs(results) do
            gg.addListItems(results)
            results[i].address = v.address + 0x2B0
            results[i].flags = gg.TYPE_FLOAT
            results[i].value = "0.04"
        end

        gg.setValues(results)
        gg.toast("Airspeed x2 enabled successfully!")
    end

    gg.clearResults()
end
function airspeedX2Off()
    gg.setVisible(false)
    gg.clearResults()

    gg.setRanges(gg.REGION_C_ALLOC)
    gg.searchNumber("1.62", gg.TYPE_FLOAT)

    local results = gg.getResults(100)

    if #results == 0 then
        gg.toast("No results found")
    else
        for i, v in ipairs(results) do
            gg.addListItems(results)
            results[i].address = v.address + 0x2B0
            results[i].flags = gg.TYPE_FLOAT
            results[i].value = "0.02"
        end

        gg.setValues(results)
        gg.toast("Airspeed x2 disabled successfully!")
    end

    gg.clearResults()
end  
function airspeedX3()
    gg.setVisible(false)
    gg.clearResults()

    gg.setRanges(gg.REGION_C_ALLOC)
    gg.searchNumber("1.62", gg.TYPE_FLOAT)

    local results = gg.getResults(100)

    if #results == 0 then
        gg.toast("No results found")
    else
        for i, v in ipairs(results) do
            gg.addListItems(results)
            results[i].address = v.address + 0x2B0
            results[i].flags = gg.TYPE_FLOAT
            results[i].value = "0.05"
        end

        gg.setValues(results)
        gg.toast("Airspeed x3 enabled successfully!")
    end

    gg.clearResults()
end
function airspeedX3Off()
    gg.setVisible(false)
    gg.clearResults()

    gg.setRanges(gg.REGION_C_ALLOC)
    gg.searchNumber("1.62", gg.TYPE_FLOAT)

    local results = gg.getResults(100)

    if #results == 0 then
        gg.toast("No results found")
    else
        for i, v in ipairs(results) do
            gg.addListItems(results)
            results[i].address = v.address + 0x2B0
            results[i].flags = gg.TYPE_FLOAT
            results[i].value = "0.02"
        end

        gg.setValues(results)
        gg.toast("Airspeed x3 disabled successfully!")
    end
    gg.clearResults()
   end
local speedV2Enabled = false
local speedV2X2Enabled = false
local speedV2X3Enabled = false

function speedV2Menu()
    local speedV2Options = {
        "⚡ SPEED V2 X1 " .. (speedV2Enabled and "✘" or "✓"),
        "⚡ SPEED V2 X2 " .. (speedV2X2Enabled and "✘" or "✓"),
        "⚡ SPEED V2 X3 " .. (speedV2X3Enabled and "✘" or "✓"),
    }
    
    local choices = gg.multiChoice(speedV2Options, nil, "SELECT SPEED V2 OPTIONS:")
    
    if choices then
    if choices[1] then
            if speedV2Enabled then
                offSpeedV2X1()
            else
                onSpeedV2X1()
            end
            speedV2Enabled = not speedV2Enabled
        end
        if choices[2] then
            if speedV2X2Enabled then
                offSpeedV2X2()
            else
                onSpeedV2X2()
            end
            speedV2X2Enabled = not speedV2X2Enabled
        end
        if choices[3] then
            if speedV2X3Enabled then
                offSpeedV2X3()
            else
                onSpeedV2X3()
            end
            speedV2X3Enabled = not speedV2X3Enabled
        end
    end
end
    
function onSpeedV2X1()
    gg.setVisible(false)
    gg.setRanges(gg.REGION_C_ALLOC)
    gg.searchNumber("1.62", gg.TYPE_FLOAT)
    local results = gg.getResults(gg.getResultCount())
    
    if #results > 0 then
        gg.addListItems(results)
        for i, v in ipairs(results) do
            v.address = v.address + 376
            v.value = "0.1"
            v.freeze = true
        end
        gg.setValues(results)
        gg.toast("SPEED V2 X1 ENABLED.")
    else
        gg.toast("NO RESULTS FOUND.")
    end
    
    gg.clearResults()
end

function offSpeedV2X1()
    gg.setVisible(false)
    gg.setRanges(gg.REGION_C_ALLOC)
    gg.searchNumber("1.62", gg.TYPE_FLOAT)
    local results = gg.getResults(gg.getResultCount())
    
    if #results > 0 then
        gg.addListItems(results)
        for i, v in ipairs(results) do
            v.address = v.address + 376
            v.value = "0"
            v.freeze = true
        end
        gg.setValues(results)
        gg.toast("SPEED V2 X1 DISABLED.")
    else
        gg.toast("NO RESULTS FOUND.")
    end
    
    gg.clearResults()
end

function onSpeedV2X2()
    gg.setVisible(false)
    gg.setRanges(gg.REGION_C_ALLOC)
    gg.searchNumber("1.62", gg.TYPE_FLOAT)
    local results = gg.getResults(gg.getResultCount())
    
    if #results > 0 then
        gg.addListItems(results)
        for i, v in ipairs(results) do
            v.address = v.address + 376
            v.value = "0.2"
            v.freeze = true
        end
        gg.setValues(results)
        gg.toast("SPEED V2 X2 ENABLED.")
    else
        gg.toast("NO RESULTS FOUND.")
    end
    
    gg.clearResults()
end

function offSpeedV2X2()
    gg.setVisible(false)
    gg.setRanges(gg.REGION_C_ALLOC)
    gg.searchNumber("1.62", gg.TYPE_FLOAT)
    local results = gg.getResults(gg.getResultCount())
    
    if #results > 0 then
        gg.addListItems(results)
        for i, v in ipairs(results) do
            v.address = v.address + 376
            v.value = "0"
            v.freeze = true
        end
       gg.setValues(results)
        gg.toast("SPEED V2 X2 DISABLED.")
    else
        gg.toast("NO RESULTS FOUND.")
    end
    
    gg.clearResults()
end

function onSpeedV2X3()
    gg.setVisible(false)
    gg.setRanges(gg.REGION_C_ALLOC)
    gg.searchNumber("1.62", gg.TYPE_FLOAT)
    local results = gg.getResults(gg.getResultCount())
    
    if #results > 0 then
        gg.addListItems(results)
        for i, v in ipairs(results) do
            v.address = v.address + 376
            v.value = "0.3"
            v.freeze = true
        end
        gg.setValues(results)
        gg.toast("SPEED V2 X3 ENABLED.")
    else
        gg.toast("NO RESULTS FOUND.")
    end
    
    gg.clearResults()
end

function offSpeedV2X3()
    gg.setVisible(false)
    gg.setRanges(gg.REGION_C_ALLOC)
    gg.searchNumber("1.62", gg.TYPE_FLOAT)
    local results = gg.getResults(gg.getResultCount())
    
    if #results > 0 then
        gg.addListItems(results)
        for i, v in ipairs(results) do
            v.address = v.address + 376
            v.value = "0"
            v.freeze = true
        end
        gg.setValues(results)
        gg.toast("SPEED V2 X3 DISABLED.")
    else
        gg.toast("NO RESULTS FOUND.")
    end
    
    gg.clearResults()
end

function movementMenu  ()
    local movementOptions = {
        "🪂 𝐴𝑖𝑟𝑗𝑢𝑚𝑝 " .. (airjumpEnabled and "✘" or "✓"),
        "🏃 𝑆𝑝𝑒𝑒𝑑 " .. (speedEnabled and "✘" or "✓"),
        "⏳ 𝐺𝑎𝑚𝑒 𝑆𝑝𝑒𝑒𝑑 " .. (gameSpeedEnabled and "✘" or "✓"),
        "💨 𝐴𝑖𝑟𝑠𝑝𝑒𝑒𝑑 " .. (airspeedEnabled and "✘" or "✓"),
        "⚡ 𝑆𝑝𝑒𝑒𝑑 𝑣2 " .. (speedV2Enabled and "✘" or "✓")
    }

    local movementChoice = gg.multiChoice(movementOptions)

    if movementChoice then
        if movementChoice[1] then
            airjumpEnabled = not airjumpEnabled
            if airjumpEnabled then
                -- Airjump ON
                gg.setVisible(false)
                gg.setRanges(gg.REGION_CODE_APP)
                gg.searchNumber("1.62", gg.TYPE_FLOAT)
                local results = gg.getResults(gg.getResultCount())
                
                if #results > 0 then
                    gg.addListItems(results)
                    for i, v in ipairs(results) do
                        v.address = v.address - 0x478
                        v.value = "-3"
                        v.freeze = true
                    end
                    gg.setValues(results)
                    gg.toast("AIR JUMP ENABLED.")
                else
                    gg.toast("NO RESULTS FOUND.")
                end
                gg.clearResults()
            else
                -- Airjump OFF
                gg.setVisible(false)
                gg.setRanges(gg.REGION_CODE_APP)
                gg.searchNumber("1.62", gg.TYPE_FLOAT)
                local results = gg.getResults(gg.getResultCount())
                
                if #results > 0 then
                    gg.addListItems(results)
                    for i, v in ipairs(results) do
                        v.address = v.address - 0x478
                        v.value = "0.0001"
                        v.freeze = false
                    end
                    gg.setValues(results)
                    gg.toast("AIR JUMP DISABLED.")
                else
             gg.toast("NO RESULTS FOUND.")
                end
                gg.clearResults()
            end
        end

        if movementChoice[2] then
            speedMenu()
        end
        if movementChoice[3] then
            gameSpeedMenu()
        end
        if movementChoice[4] then
            airspeedMenu()
        end
        if movementChoice[5] then
            speedV2Menu()
        end
    end
end

main()