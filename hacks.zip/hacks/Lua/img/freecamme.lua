gg.setVisible(false)

-- CONFIGURACIÓN AVANZADA --
local FREE_CAM_OFFSET = 0x758
local HP_OFFSET = 0x70
local X_OFFSET = -0xA0
local Y_OFFSET = -0xA4
local Z_OFFSET = -0xA8
local FREE_CAM_ON = 1.40129846e-45
local FREE_CAM_OFF = 0.0
local HP_BASE_VALUE = 1.62
local ACTIVATE_HP = 20.0
local DEACTIVATE_HP = 100.0
local DELAY_DESACTIVACION = 2

-- VARIABLES GLOBALES --
local baseAddress, freecamAddress, hpAddress, xAddress, yAddress, zAddress
local isFreecamActive = false
local tiempoDesactivacion = 0
local posicionMuerte = {}

-- BUSCAR DIRECCIONES --
function buscarDirecciones()
    gg.clearResults()
    gg.setRanges(gg.REGION_C_ALLOC)
    gg.searchNumber(HP_BASE_VALUE, gg.TYPE_FLOAT)
    
    local resultados = gg.getResults(1)
    if #resultados == 0 then
        gg.alert("ERROR: Valor base no encontrado")
        os.exit()
    end
    
    baseAddress = resultados[1].address
    hpAddress = baseAddress + HP_OFFSET
    freecamAddress = baseAddress + FREE_CAM_OFFSET
    xAddress = baseAddress + X_OFFSET
    yAddress = baseAddress + Y_OFFSET
    zAddress = baseAddress + Z_OFFSET
end

-- GUARDAR EN LISTA GG --
function guardarEnLista()
    local items = {
        { address = freecamAddress, flags = gg.TYPE_FLOAT, value = FREE_CAM_OFF, name = "🛠️ Freecam" },
        { address = hpAddress, flags = gg.TYPE_DOUBLE, value = 0, name = "❤️ HP" },
        { address = xAddress, flags = gg.TYPE_FLOAT, value = 0, name = "📌 X" },
        { address = yAddress, flags = gg.TYPE_FLOAT, value = 0, name = "📌 Y" },
        { address = zAddress, flags = gg.TYPE_FLOAT, value = 0, name = "📌 Z" }
    }
    gg.addListItems(items)
    gg.toast("Configuración guardada!")
end

-- CARGAR DESDE LISTA GG --
function cargarDesdeLista()
    local items = gg.getListItems()
    for _, v in ipairs(items) do
        if v.name == "🛠️ Freecam" then freecamAddress = v.address end
        if v.name == "❤️ HP" then hpAddress = v.address end
        if v.name == "📌 X" then xAddress = v.address end
        if v.name == "📌 Y" then yAddress = v.address end
        if v.name == "📌 Z" then zAddress = v.address end
    end
end

-- TOGGLE FREECAM --
function toggleFreecam(state)
    gg.setValues({{
        address = freecamAddress,
        flags = gg.TYPE_FLOAT,
        value = state and FREE_CAM_ON or FREE_CAM_OFF
    }})
    isFreecamActive = state
    gg.toast("Freecam: " .. (state and "🔥 ON" or "❄️ OFF"))
end

-- MONITOREO --
function monitorearHP()
    while true do
        local hp = gg.getValues({{address = hpAddress, flags = gg.TYPE_DOUBLE}})[1].value
        
        if hp < ACTIVATE_HP and not isFreecamActive then
            toggleFreecam(true)
            tiempoDesactivacion = 0
        end
        
        if hp >= DEACTIVATE_HP and isFreecamActive then
            if tiempoDesactivacion == 0 then
                tiempoDesactivacion = os.time()
                gg.toast("Desactivando en 2 segundos...")
            else
                if (os.time() - tiempoDesactivacion) >= 2 then
                    toggleFreecam(false)
                    tiempoDesactivacion = 0
                end
            end
        end
        
        gg.sleep(4)
    end
end

-- INICIALIZACIÓN --
if pcall(cargarDesdeLista) and freecamAddress and hpAddress then
    gg.toast("Configuración cargada!")
else
    buscarDirecciones()
    guardarEnLista()
end

monitorearHP()