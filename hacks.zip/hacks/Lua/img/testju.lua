-- Valor base que conoces (1.62 en float)
local valorBase = 1.62

-- Buscar el valor base en la memoria (float)
gg.clearResults()
gg.searchNumber(valorBase, gg.TYPE_FLOAT)

-- Verificar si se encontraron resultados
local resultados = gg.getResults(1)
if #resultados == 0 then
    gg.toast("No se encontró el valor base en la memoria.")
    return
end

-- Obtener la dirección base del primer resultado
local direccionBase = resultados[1].address
gg.toast("Dirección base encontrada: " .. string.format("%X", direccionBase))

-- Calcular los offsets basados en la dirección base
local xA_offset = -160
local yA_offset = -164
local zA_offset = -168
local myHP_offset = 112

-- Obtener los valores en las direcciones con offsets
local xA = gg.getValues({{address = direccionBase + xA_offset, flags = gg.TYPE_FLOAT}})[1].value
local yA = gg.getValues({{address = direccionBase + yA_offset, flags = gg.TYPE_FLOAT}})[1].value
local zA = gg.getValues({{address = direccionBase + zA_offset, flags = gg.TYPE_FLOAT}})[1].value
local myHP = gg.getValues({{address = direccionBase + myHP_offset, flags = gg.TYPE_DOUBLE}})[1].value

-- Mostrar los valores encontrados
gg.toast(string.format("xA: %.2f, yA: %.2f, zA: %.2f, myHP: %.2f", xA, yA, zA, myHP))

-- Crear una lista de valores para guardar en GG
local listaValores = {
    {address = direccionBase + xA_offset, flags = gg.TYPE_FLOAT, value = xA, name = "xA"},
    {address = direccionBase + yA_offset, flags = gg.TYPE_FLOAT, value = yA, name = "yA"},
    {address = direccionBase + zA_offset, flags = gg.TYPE_FLOAT, value = zA, name = "zA"},
    {address = direccionBase + myHP_offset, flags = gg.TYPE_DOUBLE, value = myHP, name = "myHP"}
}

-- Guardar los valores en la lista de GG
gg.addListItems(listaValores)
gg.toast("Valores guardados en la lista de GG")

-- Variables para controlar el estado
local ejecutado = false
local xA_original = xA
local zA_original = zA
local yA_original = yA

-- Función para verificar el HP y modificar las coordenadas
local function verificarHP()
    while true do
        -- Obtener el valor actual de myHP (double)
        local myHP_actual = gg.getValues({{address = direccionBase + myHP_offset, flags = gg.TYPE_DOUBLE}})[1].value

        -- Verificar si el HP está por debajo de 10.0 (con decimales)
        if myHP_actual < 10.0 and not ejecutado then
            -- Congelar xA y zA
            gg.setValues({
                {address = direccionBase + xA_offset, flags = gg.TYPE_FLOAT, value = xA},
                {address = direccionBase + zA_offset, flags = gg.TYPE_FLOAT, value = zA}
            })

            -- Sumar 5 a yA (ajustado a tu ejemplo)
            local nuevo_yA = yA + 5
            gg.setValues({
                {address = direccionBase + yA_offset, flags = gg.TYPE_FLOAT, value = nuevo_yA}
            })

            gg.toast("HP bajo 10.0: xA/zA congelados, yA +5")
            ejecutado = true
        end

        -- Verificar si el HP es superior o igual a 10.0 para restaurar
        if myHP_actual >= 10.0 and ejecutado then
            -- Restaurar valores originales
            gg.setValues({
                {address = direccionBase + xA_offset, flags = gg.TYPE_FLOAT, value = xA_original},
                {address = direccionBase + zA_offset, flags = gg.TYPE_FLOAT, value = zA_original},
                {address = direccionBase + yA_offset, flags = gg.TYPE_FLOAT, value = yA_original}
            })

            gg.toast("HP >= 10.0: Valores restaurados")
            ejecutado = false
        end

        -- Descongelar xA/zA si estamos en el aire (ejecutado = true)
        if ejecutado then
            -- Forzar la actualización de xA/zA permitiendo su cambio
            local xA_actual = gg.getValues({{address = direccionBase + xA_offset, flags = gg.TYPE_FLOAT}})[1].value
            local zA_actual = gg.getValues({{address = direccionBase + zA_offset, flags = gg.TYPE_FLOAT}})[1].value

            gg.setValues({
                {address = direccionBase + xA_offset, flags = gg.TYPE_FLOAT, value = xA_actual},
                {address = direccionBase + zA_offset, flags = gg.TYPE_FLOAT, value = zA_actual}
            })
        end

        -- Esperar 100 ms para no saturar la CPU
        gg.sleep(100)
    end
end

-- Iniciar la verificación
verificarHP()