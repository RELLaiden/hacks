gg.setRanges(gg.REGION_C_ALLOC)
gg.searchNumber("4 879 509 459 916 881 920", gg.TYPE_QWORD, false, gg.SIGN_EQUAL, 0, -1, 0)
r = gg.getResults(1, nil, nil, nil, nil, nil, nil, nil, nil)
local t = {}
t[1] = {}
t[1].address = r[1].address - 168
t[1].flags = gg.TYPE_DWORD
t[1].value = 257
t[1].freeze = false
gg.setValues(t)
