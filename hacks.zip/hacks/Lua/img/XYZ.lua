-- Valor base conocido (1.62 en float)
local valorBase = 1.62

-- Buscar el valor base en la memoria y limpiar resultados previos
gg.clearResults()
gg.searchNumber(valorBase, gg.TYPE_FLOAT)
local resultados = gg.getResults(1)
if #resultados == 0 then
  gg.toast("No se encontró el valor base en la memoria.")
  return
end

-- Obtener la dirección base del primer resultado
local direccionBase = resultados[1].address
gg.toast("Dirección base encontrada: " .. string.format("%X", direccionBase))

-- Definir offsets para las variables
local xA_offset    = -160
local yA_offset    = -164
local zA_offset    = -168
local myHP_offset  = 112

-- Obtener valores iniciales
local valoresIniciales = gg.getValues({
  {address = direccionBase + xA_offset, flags = gg.TYPE_FLOAT},
  {address = direccionBase + yA_offset, flags = gg.TYPE_FLOAT},
  {address = direccionBase + zA_offset, flags = gg.TYPE_FLOAT},
  {address = direccionBase + myHP_offset, flags = gg.TYPE_DOUBLE}
})
local xA   = valoresIniciales[1].value
local yA   = valoresIniciales[2].value
local zA   = valoresIniciales[3].value
local myHP = valoresIniciales[4].value

gg.toast(string.format("xA: %.2f, yA: %.2f, zA: %.2f, myHP: %.2f", xA, yA, zA, myHP))

-- Agregar los valores iniciales a la lista de GG (opcional)
local listaValores = {
  {address = direccionBase + xA_offset, flags = gg.TYPE_FLOAT, value = xA, name = "xA"},
  {address = direccionBase + yA_offset, flags = gg.TYPE_FLOAT, value = yA, name = "yA"},
  {address = direccionBase + zA_offset, flags = gg.TYPE_FLOAT, value = zA, name = "zA"},
  {address = direccionBase + myHP_offset, flags = gg.TYPE_DOUBLE, value = myHP, name = "myHP"}
}
gg.addListItems(listaValores)
gg.toast("Valores guardados en la lista de GG")

---------------------------------------------------------------------
-- Variables para controlar el estado del TP
local teleporting = false   -- Indica si se inició el proceso de TP
local freezeItems = nil     -- Almacenará los elementos congelados (X y Z)
local savedY = nil          -- Valor original de Y cuando se inició el TP

-- Bucle principal de verificación (se ejecuta cada ~4 ms)
while true do
  local valoresActuales = gg.getValues({
    {address = direccionBase + myHP_offset, flags = gg.TYPE_DOUBLE},
    {address = direccionBase + xA_offset, flags = gg.TYPE_FLOAT},
    {address = direccionBase + yA_offset, flags = gg.TYPE_FLOAT},
    {address = direccionBase + zA_offset, flags = gg.TYPE_FLOAT}
  })
  local hp_actual = valoresActuales[1].value
  local current_x = valoresActuales[2].value
  local current_y = valoresActuales[3].value
  local current_z = valoresActuales[4].value

  -- Si el HP es muy bajo y aún no se inició el proceso de TP:
  if hp_actual <= 16.0 and not teleporting then
    teleporting = true
    savedY = current_y  -- Guardamos la posición Y original
    -- Congelamos X y Z usando addListItems con freeze = true
    freezeItems = {
      {address = direccionBase + xA_offset, flags = gg.TYPE_FLOAT, value = current_x, freeze = true},
      {address = direccionBase + zA_offset, flags = gg.TYPE_FLOAT, value = current_z, freeze = true}
    }
    gg.addListItems(freezeItems)
    -- Actualizamos Y (sin congelarlo) para “levantar” al personaje
    gg.setValues({
      {address = direccionBase + yA_offset, flags = gg.TYPE_FLOAT, value = current_y + 10}
    })
    gg.toast("TP iniciado: X y Z congelados, Y incrementado.")
  end

  -- Si se inició el TP, verificamos si el personaje ya está en el aire
  if teleporting then
    -- Si Y supera el valor original en al menos 8 unidades (umbral ajustable)
    if current_y >= savedY + 8 then
      -- Descongelamos X y Z removiendo los elementos de la lista
      gg.removeListItems(freezeItems)
      teleporting = false
      gg.toast("TP completado: X y Z descongelados.")
    end
  end

  gg.sleep(4)
end
