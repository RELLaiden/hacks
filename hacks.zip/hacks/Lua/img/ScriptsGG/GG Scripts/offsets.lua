-- Script para identificar si una dirección es fija en GameGuardian

function main()
    gg.clearResults()
    gg.toast("Bienvenido al buscador de direcciones fijas.")
    
    -- Solicita la dirección deseada al usuario
    local input = gg.prompt(
        {"Introduce la dirección (en hexadecimal):"}, 
        {""}, 
        {"text"}
    )
    
    if input == nil or input[1] == "" then
        gg.alert("No se proporcionó una dirección. Saliendo del script.")
        os.exit()
    end
    
    local desiredAddress = tonumber(input[1], 16)
    
    if not desiredAddress then
        gg.alert("La dirección proporcionada no es válida.")
        os.exit()
    end
    
    gg.toast(string.format("Buscando en la dirección: 0x%X", desiredAddress))
    
    -- Configurar regiones de memoria estables
    gg.setRanges(gg.REGION_C_ALLOC | gg.REGION_CODE_APP)
    
    -- Recupera el valor en la dirección deseada
    local values = gg.getValues({{address = desiredAddress, flags = gg.TYPE_DWORD}})
    
    if #values == 0 then
        gg.alert("No se encontró un valor en la dirección especificada.")
        os.exit()
    end
    
    local originalValue = values[1].value
    gg.toast(string.format("Valor en 0x%X: %d", desiredAddress, originalValue))
    
    -- Congela la dirección temporalmente
    gg.addListItems({{address = desiredAddress, flags = gg.TYPE_DWORD, value = originalValue}})
    gg.toast("Dirección añadida a la lista. Por favor, reinicia el juego y vuelve a ejecutar este script.")
    
    -- Mensaje final
    gg.alert("Reinicia el juego y vuelve a usar este script. Si la dirección sigue teniendo el mismo valor tras reiniciar, es fija.")
end

-- Llama a la función principal
main()
