gg.setVisible(not true)
gg.clearList()
gg.clearResults()
gg.setRanges(4)
gg.searchNumber(':DisableMovement',1)
gg.getResults(99999)
gg.editAll(':SuckMyDickLol',1)
gg.clearResults()
gg.searchNumber(';SkyBlockCustomDialog',2)
gg.getResults(99999)
gg.refineNumber(103,2)
t = gg.getResults(99999)
gg.clearResults()
for i,v in pairs(t) do
v.flags = 4
v.address = v.address + 0x22
end
gg.loadResults(t)
gg.getResults(99999)
gg.refineNumber('1~257',4)
t = gg.getResults(99999)
gg.clearResults()
for i,v in pairs(t) do
v.flags = 16
v.address = v.address + 0x84
end
gg.loadResults(t)
gg.getResults(99999)
gg.refineNumber(1,16)
t = gg.getResults(99999)
for i,v in pairs(t) do
v.value = 999
v.freeze = true
gg.addListItems(t)
v.flags = 4
v.address = v.address + -132
v.value = 1
v.freeze = true
gg.addListItems(t)
end
gg.clearResults()
gg.searchNumber(1.62,16)
t = gg.getResults(99999)
gg.clearResults()
for i,v in pairs(t) do
v.address = v.address + 0x178
v.value = 0.08
v.freeze = true
gg.addListItems(t)
end

gg.clearResults()
gg.searchNumber(';Main-Jump',2)
gg.getResults(99999)
gg.refineNumber(74,2)
t = gg.getResults(99999)
gg.clearResults()
for i,v in pairs(t) do
v.flags=4
v.address = v.address + 0x3E
end
gg.loadResults(t)
gg.getResults(99999)
gg.refineNumber('256~257',4)
t = gg.getResults(99999)
gg.clearResults()
for i,v in pairs(t) do
v.value = 257
v.freeze = true
gg.addListItems(t)
end
