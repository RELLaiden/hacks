-- Create a table to hold the value information
local saveItem = {
    {
        address = 0x7680c14,  -- Memory address to save (0x7680c14 in this case)
        flags = gg.TYPE_DWORD,  -- Data type (DWORD = 4 bytes, which is an integer)
        value = 100,  -- New value to save (change to whatever you want)
        freeze = false,  -- Set to true if you want to freeze the value (prevent changes)
        name = "My Saved Value"  -- Optional: Give it a name in the save list for reference
    }
}

-- Set the value at the address (optional, you can skip if you don't want to modify it first)
gg.setValues(saveItem)

-- Add the value to the save list
gg.addListItems(saveItem)

-- Display a toast message to confirm the action
gg.toast("Value saved to list with address 0x7680c14")