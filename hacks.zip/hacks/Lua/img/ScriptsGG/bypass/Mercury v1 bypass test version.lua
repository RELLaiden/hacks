lk = 16384
gg.setRanges(lk) gg.searchNumber("h000000000000000080842E41CDCCCCCC",1) gg.getResults(lk) gg.editAll("h000000000000000000000000CDCCCCCC",1) gg.clearResults()
gg.toast("CREDITS MERCURY ")