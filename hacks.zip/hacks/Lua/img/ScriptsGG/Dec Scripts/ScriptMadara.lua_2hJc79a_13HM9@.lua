-- Limpia resultados anteriores
gg.clearResults()

-- Establece la región de memoria en C_ALLOC
gg.setRanges(gg.REGION_C_ALLOC)

-- Realiza la búsqueda inicial
gg.searchNumber("6.5", gg.TYPE_FLOAT, false, gg.SIGN_EQUAL, 0, -1, 0)
gg.toast("Búsqueda inicial completada.")

-- Refina los resultados para encontrar solo el valor 6.5
gg.refineNumber("6.5", gg.TYPE_FLOAT, false, gg.SIGN_EQUAL, 0, -1, 0)
gg.toast("Refinamiento completado.")

-- Obtiene los resultados
local results = gg.getResults(1) -- Solo necesitamos 1 resultado
if #results == 0 then
    gg.toast("No se encontraron resultados.")
    os.exit()
end

-- Cambia el valor encontrado
local edits = {
    [1] = {
        address = results[1].address, -- Dirección obtenida del resultado
        flags = gg.TYPE_DWORD, -- Cambia a DWORD
        value = "0" -- Establece el valor en 0
    }
}

-- Aplica los cambios
gg.setValues(edits)
gg.toast("Valor modificado con éxito.")
