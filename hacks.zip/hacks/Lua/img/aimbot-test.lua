--[[ 
    Aimbot Mejorado para Blockman Go
    Basado en la estructura funcional del primer script
]]

-- Configuración
local config = {
    ranges = gg.REGION_C_ALLOC,  -- Rango de memoria
    playerMarker = 1127481344,   -- Valor flotante que representa 180.0 (Y base)
    aimState = 1070554153,       -- Estado de mira
    smoothFactor = 0.2,          -- Suavizado del movimiento
    maxDistance = 7.0,           -- Distancia máxima para apuntar
    healthThreshold = 0.123      -- Umbral de salud para desactivar
}

-- Función para buscar valores en memoria
function Sv(v, rg, fg)
    local rt = {}
    gg.setRanges(rg)
    gg.searchNumber(v[1], fg)
    local r = gg.getResults(999999)
    if #r == 0 then
        gg.toast("NOT VALUE 1")
        return rt
    end

    for iv = 2, #v do
        for i = 1, #r do
            r[i].address = r[i].address + v[iv][2]
        end
        local rr = gg.getValues(r)
        local tt = {}
        for i = 1, #rr do
            if rr[i].value == v[iv][1] then
                table.insert(tt, {
                    address = rr[i].address - v[iv][2],
                    flags = fg
                })
            end
        end
        if #tt == 0 then
            gg.clearResults()
            gg.toast("NOT VALUE 2")
            return rt
        end
        r = tt
    end
    gg.clearResults()
    return r
end

-- Función principal
function F()
    gg.clearList()
    gg.clearResults()
    gg.setVisible(false)

    -- Buscar jugadores
    local players = Sv({config.playerMarker, {300, -71 * 4}, {0, -75 * 4}}, config.ranges, gg.TYPE_FLOAT)
    if #players == 0 then
        gg.toast("No se encontraron jugadores")
        return
    else
        gg.toast(#players .. " jugadores detectados")
    end

    -- Buscar estado de mira
    local aimData = Sv({config.aimState, {config.aimState, 0}}, config.ranges, gg.TYPE_FLOAT)
    if #aimData == 0 then
        gg.toast("No se encontró el estado de mira")
        return
    else
        gg.toast("AIMBOT ACTIVADO")
    end

    -- Variables de control
    local currentYaw, currentPitch = 0, 0
    local v = 1

    -- Bucle principal
    while true do
        if gg.isVisible(true) then
            gg.setVisible(false)
            gg.clearList()
            gg.clearResults()
            gg.toast("AIMBOT DESACTIVADO")
            return
        end

        -- Cambiar de jugador si es necesario
        if v > #players then v = 1 end
        if players[v].value ~= config.playerMarker then
            v = v + 1
        else
            -- Obtener posición local
            local myPos = {
                x = gg.getValues({{address = players[v].address - 40 * 4, flags = gg.TYPE_FLOAT}})[1].value,
                y = gg.getValues({{address = players[v].address - 41 * 4, flags = gg.TYPE_FLOAT}})[1].value,
                z = gg.getValues({{address = players[v].address - 42 * 4, flags = gg.TYPE_FLOAT}})[1].value
            }

            -- Obtener posición del enemigo
            local enemyPos = {
                x = gg.getValues({{address = players[v].address - 115 * 4, flags = gg.TYPE_FLOAT}})[1].value,
                y = gg.getValues({{address = players[v].address - 116 * 4, flags = gg.TYPE_FLOAT}})[1].value,
                z = gg.getValues({{address = players[v].address - 117 * 4, flags = gg.TYPE_FLOAT}})[1].value
            }

            -- Verificar salud
            local myHP = gg.getValues({{address = players[v].address + 28 * 4, flags = gg.TYPE_FLOAT}})[1].value
            local enemyHP = gg.getValues({{address = players[v].address - 47 * 4, flags = gg.TYPE_FLOAT}})[1].value

            if myHP < config.healthThreshold or enemyHP < config.healthThreshold then
                gg.toast("Salud baja - AIMBOT DESACTIVADO")
                return
            end

            -- Calcular distancia
            local dx = enemyPos.x - myPos.x
            local dz = enemyPos.z - myPos.z
            local distance = math.sqrt(dx^2 + dz^2)

            if distance <= config.maxDistance then
                -- Calcular ángulos
                local targetYaw = math.atan2(dz, dx) * 180 / math.pi - 90
                local targetPitch = -math.atan2(enemyPos.y - myPos.y, distance) * 180 / math.pi

                -- Suavizado
                currentYaw = currentYaw + (targetYaw - currentYaw) * config.smoothFactor
                currentPitch = currentPitch + (targetPitch - currentPitch) * config.smoothFactor

                -- Aplicar ángulos
                for i = 1, #aimData do
                    gg.setValues({
                        {address = aimData[i].address - 47 * 4, value = currentPitch, flags = gg.TYPE_FLOAT},
                        {address = aimData[i].address - 48 * 4, value = currentYaw, flags = gg.TYPE_FLOAT}
                    })
                end
            end
        end
        gg.sleep(5)
    end
end

-- Ejecutar
F()