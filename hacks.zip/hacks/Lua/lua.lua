gg = require('gg')
gg.setVisible(false)

function buscarHP()
    gg.clearResults()
    gg.setRanges(gg.REGION_C_ALLOC)
    gg.searchNumber('0;200', gg.TYPE_DOUBLE, false, gg.SIGN_EQUAL, 0, 0, -1)

    local resultados = gg.getResults(100)
    local hp_enemigos = {}

    -- Almacenar los valores de HP encontrados
    for i, v in ipairs(resultados) do
        table.insert(hp_enemigos, {address = v.address, value = v.value})
    end

    while true do
        gg.clearResults()
        gg.setRanges(gg.REGION_C_ALLOC)
        gg.searchNumber('0;200', gg.TYPE_DOUBLE, false, gg.SIGN_EQUAL, 0, 0, -1)

        local nuevos_resultados = gg.getResults(100)
        local hp_reducidos = {}

        -- Comparar los nuevos resultados con los anteriores
        for i, v in ipairs(nuevos_resultados) do
            for j, enemigo in ipairs(hp_enemigos) do
                if v.address == enemigo.address then
                    -- Si el valor ha disminuido, lo guardamos
                    if v.value < enemigo.value then
                        table.insert(hp_reducidos, {address = enemigo.address, old_value = enemigo.value, new_value = v.value})
                    end
                end
            end
        end

        -- Mostrar los HP que han disminuido
        if #hp_reducidos > 0 then
            local mensaje = "HP reducidos:\n"
            for i, v in ipairs(hp_reducidos) do
                mensaje = mensaje .. "Dirección: " .. v.address .. " | Valor anterior: " .. v.old_value .. " | Nuevo valor: " .. v.new_value .. "\n"
            end
            gg.alert(mensaje)
        end

        -- Esperar un tiempo antes de volver a buscar
        gg.sleep(2000) -- Espera 2 segundos
    end
end

buscarHP()