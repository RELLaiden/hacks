gg.setRanges(gg.REGION_CODE_APP)
gg.setVisible(false)
gg.searchNumber(
    "h63 65 5F 63 73 33 00 48 42 43 68 65 63 6B 00 63 73 63 21 25 73 00 63 73 66 21 25 73 00 63 73 5F 38 30 5F 70 6F 72 74 00 30 5F 30 5F 25 7A 75 00 43 53 33 2C 20 4F 6E 54 69 63 6B 65 74 4F 4B 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 68 65 6C 6C 6F 2C 20 77 6F 72 6C 64 00 00 72 6F 6C 65 5F 69 64 3A 25 73 3B 69 6E 63 5F 69 64 3A 25 64 00 67 65 74 5F 31 5F 25 64 3A 25 70 2C 20 6E 6F 64 65 5F 63 6E 74 3A 25 64 2C 20 72 65 6D 61 69 6E 3A 25 64 2C 20 63 73 33 00 64 65 6C 5F 31 5F 25 64 3A 25 70 2C 20 72 65 6D 61 69 6E 3A 25 64 2C 20 63 73 33 00 63 32 67 5F 72 65 64 69 65 63 74 00 00 04 08 18 0E 61 74 65 5F 62 69 00 63 68 65 63 6B 5F 65 78 74 5F 65 6D 75 5F 66 65 61 74 75 72 65 00 25 63 25 63 3A 25 64 2C 00 65 6D 75 5F 61 6C 65 72 74 3A 25 73 00 65 6D 75 5F 61 6C 65 72 74 00 65 5F 63 5F 6D 21 00 49 43 4F 4E 3A 25 73 3A 00 25 73 57 61 72 6E 69 6E 67 00 49 74 20 69 73 20 66 6F 75 6E 64 20 74 68 61 74 20 79 6F 75 20 61 72 65 20 72 75 6E 6E 69 6E 67 20 69 6E 20 61 6E 20 41 6E 64 72 6F 69 64 20 65 6D 75 6C 61 74 6F 72 2E 20 50 6C 65 61 73 65 20 72 65 73 75 6D 65 20 74 68 65 20 67 61 6D 65 20 61 66 74 65 72 20 72 65 74 75 72 6E 69 6E 67 20 74 6F 20 70 68 79 73 69 63 61 6C 20 64 65 76 69 63 65 73 2E 00 45 78 69 74 00 02 00 04 06 00 66 6F 6F 00 73 74 61 74 5F 72 70 74 00 61 63 65 5F 77 6F 72 6B 65 72 00 61 63 65 5F 77 6F 72 6B 65 72 25 64 00 73 63 5F 69 64 6C 65 00 00 00 00 00 00 00 00 80 84 2E 41 CD CC CC CC CC CC FC 3F 66 66 66 66 66 66 FE 3F 00 00 00 00 00 00 00 00 00 00 00 00 2C 01 00 00 00 00 00 00 84 03 00 00 96 00 00 00 08 00 00 00 3C 00 00 00 00 00 00 00 61 63 65 5F 73 63 68 65 64 75 6C 65 33 00 73 63 5F 64 6C 70 00 2B 20 72 65 70 6F 72 74 5F 62 6B 00 68 62 5F 6C 6F 6F 70 00 71 6F 73 5F 6C 6F 6F 70 00 69 6E 74 65 72 66 61 63 65 5F 74 65 73 74 00 73 63 00 25 64 3A 25 64 3A 25 64 3A 25 64 00 72 32 72 33 5F 65 72 72 00 6E 61 6D 65 3A 25 73 2C 20 63 61 73 74 3A 25 6C 64 00 6F 6E 73 65 6C 65 63 74 5F 61 6C 65 72 74 00 66 63 63 31 2E 64 00 21 64 6C 20 25 64 00 63 64 6E 3A 25 73 00 63 6F 6E 66 69 67 32 2E 78 6D 6C 00 21 64 63 66 00 21 70 63 66 00 21 64 73 66 00 64 6C 20 25 73 2C 20 72 65 74 76 61 6C 3A 25 64 2C 20 73 69 7A 65 3A 25 64 2C 20 63 61 63 68 65 3A 25 64 2C 20 6A 64 3A 25 64 00 63 6F 6D 6D 5F 66 69 72 73 74 00 73 69 67 20 63 75 73 74 6F 6D 2C 20 6E 61 6D 65 3A 25 73 2C 20 6C 65 6E 3A 25 64 2C 20 63 72 63 3A 25 30 38 78 00 63 6F 6E 66 69 67 33 2E 78 6D 6C 00 6D 65 6D 73 61 66 65 00 76 65 72 3A 25 73 20 61 70 70 5F 76 65 72 3A 25 73 20 63 6F 64 65 5F 73 69 7A 65 3A 25 73 20 63 72 63 3A 25 73 00 72 62 00 00 00 00 00 00 00 00 00 00 00 00 00 00 05 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 72 65 73 75 6C 74 3D 65 72 72 6F 72 00 00 00 00 38 DE 00 00 01 00 00 00 39 DE 00 00 01 00 00 00 3A DE 00 00 01 00 00 00 00 64 FD 82 FD FD FD A1 00 16 35 20 35 35 35 2A 00 00 00 00 00 00 00 00 01 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 77 73 61 5F 70 6F 70 65 6E 5F 69 70 00 77 73 61 5F 6E 65 74 6C 69 6E 6B 5F 69 70 00 77 73 61 5F 75 64 70 5F 69 70 00 25 75 3A 73 3B 70 3A 25 73 00 00 00 00 3A 8F 00 00 91 93 00 00 E8 97 00 00 00 61 22 3D 61 61 61 61 61 28 00 72 39 72 5A 72 72 63 72 6C 72 63 76 5F 25 64 2C 6C 65 6E 3A 25 64 2C 63 73 3A 25 64 00 67 5F 64 6C 5F 63 68 61 6E 6E 65 6C 00 70 5F 69 37 2E 64 61 74 00 72 5F 69 37 2E 64 61 74 00 72 65 63 6F 72 64 00 66 69 6C 65 73 2D 64 69 72 3A 25 73 2C 20 69 6E 69 74 65 64 3A 31 00 66 6C 61 67 73 3A 00 72 61 74 65 3A 25 64 00 67 61 6D 65 5F 76 65 72 3A 25 73 20 73 64 6B 5F 76 65 72 3A 25 73 00 33 2E 31 00 6A 61 72 5F 76 65 72 3A 25 73 2C 63 65 72 74 5F 65 6E 76 3A 25 73 00 6D 69 6E 5F 61 70 69 3A 25 64 2C 74 61 72 67 65 74 5F 61 70 69 3A 25 64 00 6D 61 78 5F 75 73 65 72 5F 77 61 74 63 68 65 73 3A 25 73 00 72 6F 6F 74 5F 61 6C 65 72 74 3A 25 73 00 72 6F 6F 74 5F 61 6C 65 72 74 00 72 70 64 61 74 61 32 00 63 73 3A 25 73 00 25 30 38 78 25 30 38 78 25 30 38 78 00 00 30 75 00 00 40 00 00 00 03 00 00 00 00 00 00 00 63 6C 6B 5F 61 64 62 00 41 75 74 6F 43 6C 69 63 6B 65 72 20 66 6F 75 6E 64 20 6F 6E 20 79 6F 75 72 20 70 68 6F 6E 65 2E 20 54 6F 20 63 6F 6E 74 69 6E 75 65 2C 20 64 72 61 67 20 74 68 65 20 73 63 72 6F 6C 6C 20 62 61 72 20 74 6F 20 74 68 65 20 6E 75 6D 62 65 72 20 25 64 2E 00 43 75 72 72 65 6E 74 20 6E 75 6D 62 65 72 20 69 73 3A 20 3B 25 64 3B 25 64 00 63 6C 6B 5F 72 70 74 00 25 73 2F 25 73 00 63 6F 6D 2F 63 6F 63 6F 73 2F 6C 69 62 2F 43 6F 63 6F 73 41 63 74 69 76 69 74 79 00 64 74 00 6D 53 75 72 66 61 63 65 56 69 65 77 00 4C 63 6F 6D 2F 63 6F 63 6F 73 2F 6C 69 62 2F 43 6F 63 6F 73 53 75 72 66 61 63 65 56 69 65 77 3B 00 73 65 74 4F 6E 74 6F 75 63 68 52 65 74 56 61 6C 00 28 5A 29 56 00 00 00 01 02 03 04 05 06 07 08 09 0A 0B 0C 0D 0E 0F 9A 99 99 99 99 99 C9 3F 71 3D 0A D7 A3 70 E5 3F 61 6E 6F 2C 64 72 6F 70 3A 25 73 3A 25 73 00 61 6E 6F 5F 74 69 70 5F 70 6B 67 00 6D 73 67 62 6F 78 5F 62 75 74 74 6F 6E 5F 31 30 30 30 31 00 61 6E 6F 5F 69 63 6F 6E 00 6D 73 67 62 6F 78 5F 63 6F 6E 74 65 6E 74 5F 31 30 30 30 31 00 4D 61 6C 77 61 72 65 20 66 6F 75 6E 64 20 6F 6E 20 79 6F 75 72 20 70 68 6F 6E 65 2E 20 50 6C 65 61 73 65 20 75 6E 69 6E 73 74 61 6C 6C 20 69 74 20 62 65 66 6F 72 65 20 65 6E 74 65 72 69 6E 67 20 74 68 65 20 67 61 6D 65 2E 28 00 61 6E 6F 5F 74 69 6D 65 00 21 66 6F 72 63 65 3A 6D 73 67 5F 62 6F 78 3A 74 69 6D 65 6F 75 74 00 77 68 6F 61 72 65 79 6F 75 3F 00 61 6E 6F 5F 66 63 00 61 6E 6F 5F 63 65 72 74 5F 6D 64 35 00 47 47 00 67 67 00 63 6F 6D 2E 00 61 6E 6F 5F 69 67 6E 6F 72 65 5F 64 65 74 65 63 74 00 61 6E 6F 5F 73 79 73 00 61 6E 6F 5F 63 66 69 6C 74 00 25 75 2E 25 75 2E 25 73 00 44 65 78 53 63 61 6E 00 63 6F 6D 2E 64 74 73 2E 66 72 65 65 66 69 72 65 74 68",
    gg.TYPE_BYTE, false, gg.SIGN_EQUAL, 0, -1, 0)
revert = gg.getResults(100000, nil, nil, nil, nil, nil, nil, nil, nil)
gg.editAll("0", gg.TYPE_BYTE)
revert = gg.getResults(100000, nil, nil, nil, nil, nil, nil, nil, nil)
gg.editAll("0", gg.TYPE_BYTE)
gg.setVisible(true)
gg.clearResults()
gg.setRanges(gg.REGION_CODE_APP)
gg.searchNumber("28 548 151 168 164 723", gg.TYPE_QWORD)
local b = gg.getResults(99999)
gg.addListItems(b)
b = nil
local a = false
local b = gg.getListItems()
if not a then gg.removeListItems(b) end
for i, v in ipairs(b) do
    v.address = v.address + 0x13
    if a then v.name = v.name .. ' #2' end
end
gg.addListItems(b)
b = nil
a = nil
revert = gg.getListItems()
local b = gg.getListItems()
for i, v in ipairs(b) do
    v.flags = gg.TYPE_BYTE
    v.value = "0"
    v.freeze = true
    v.freezeType = gg.FREEZE_IN_RANGE
    v.freezeFrom = "0"
    v.freezeTo = "1"
end
gg.addListItems(b)
b = nil
gg.clearResults()
gg.clearList()
gg.toast('Bypass by stormii')

-- Flag to check if password has been entered
local passwordEntered = false

-- Function to prompt for password
function passwordPrompt()
    if not passwordEntered then
        local input = gg.prompt({ "Enter Password:" }, nil, { "number" })
        if input == nil then
            gg.toast("Script cancelled")
            os.exit()
        elseif tonumber(input[1]) == 3030 then
            gg.toast("Password correct!")
            passwordEntered = true
            mainMenu()
        else
            gg.toast("Incorrect password!")
            os.exit()
        end
    else
        mainMenu() -- Show the main menu if password has already been entered
    end
end

-- Function to hide the menu but keep the script running
function closeMenu()
    gg.setVisible(false) -- Hides the GG interface but keeps the script running
    gg.toast("Menu hidden! Tap GG icon to reopen.")
end

-- Function to exit the script properly
function exitScript()
    gg.toast("Exiting Script")
    os.exit() -- Completely exits the script
end

-- Function to handle HitBox (HB) submenu
function hitBoxSubMenu()
    local hbOptions = gg.choice({
        "Hbx4",
        "Hbx5",
        "Hbx6",
        "Hbx20"
    }, nil, "Select HitBox (HB) Option")
    if hbOptions == 1 then
        -- Code for Hbx4
    elseif hbOptions == 2 then
        -- Code for Hbx5
    elseif hbOptions == 3 then
        -- Code for Hbx6
    elseif hbOptions == 4 then
        -- Code for Hbx20
    end
end

-- Function to handle Reach Attack submenu
function reachAttackSubMenu()
    local raOptions = gg.choice({
        "Reach X6",
        "Reach X6.5",
        "Reach X7"
    }, nil, "Select Reach Attack Option")

    if raOptions == 1 then
        -- Code for Reach X6
    elseif raOptions == 2 then
        -- Code for Reach X6.5
    elseif raOptions == 3 then
        -- Code for Reach X7
    end
end

-- Function to handle No Clip submenu
function noClipSubMenu()
    local ncOptions = gg.choice({
        "Activate No Clip",
        "Deactivate No Clip"
    }, nil, "No Clip Options")
    if ncOptions == 1 then
        -- Code to activate No Clip
    elseif ncOptions == 2 then
        -- Code to deactivate No Clip
    end
end

-- Function to handle Random Games menu with checkboxes and submenus
function randomGamesMenu()
    local choices = {
        "No Delay or BanCD ⏳",
        "WWE Cam 📸",
        "HitBox (HB) 🎯",
        "Reach Attack ⚔️",
        "Reach Block 🟫",
        "Set Block 🏗️",
        "No Clip 🚫",
        "Blink 👁️",
        "Back to Main Menu"
    }

    local selected = gg.multiChoice(choices, nil, "Random Games Hacks")

    if selected == nil then return end

    -- Handle each selected checkbox
    if selected[1] then
        gg.setRanges(gg.REGION_C_ALLOC)
        gg.searchNumber('200;5;6.5', gg.TYPE_FLOAT)
        gg.getResults(10) -- Obtener los primeros 10 resultados

        -- Refinar la búsqueda para quedarte solo con el valor 6.5
        gg.refineNumber('6.5')
        local results = gg.getResults(10) -- Obtener los resultados refinados

        if results and #results > 0 then
            -- Asumimos que el primer resultado es el correcto
            local baseAddress = results[1].address     -- Dirección del valor refinado 6.5
            local offset = -608                        -- Offset a aplicar
            local targetAddress = baseAddress + offset -- Calcular la dirección con el offset

            -- Crear un nuevo resultado manualmente con la dirección calculada y el tipo Dword
            local newResult = {}
            newResult[1] = {
                address = targetAddress,
                flags = gg.TYPE_DWORD, -- Tipo de datos que queremos modificar (Dword)
                value = 0              -- Valor inicial que esperamos encontrar
            }

            -- Buscar el valor en la nueva dirección calculada con el offset
            gg.setValues(newResult)    -- Aplicar el valor (puedes buscarlo o directamente establecerlo)
            newResult[1].value = 1     -- Cambiar el valor a 1
            newResult[1].freeze = true -- Congelar el valor en 1
            gg.setValues(newResult)    -- Aplicar el cambio y congelar
            gg.addListItems(newResult) -- Añadir a la lista de congelados
            gg.toast('Valor cambiado a 1 y congelado con éxito')
        else
            gg.toast('No se encontraron resultados para el valor 6.5')
        end
    end

    if selected[2] then
        -- Code to activate WWE Cam
    end

    if selected[3] then
        hitBoxSubMenu() -- Show HitBox (HB) submenu
    end

    if selected[4] then
        reachAttackSubMenu() -- Show Reach Attack submenu
    end

    if selected[5] then
        -- Code to activate Reach Block
    end

    if selected[6] then
        -- Code to activate Set Block
    end

    if selected[7] then
        noClipSubMenu() -- Show No Clip submenu
    end

    if selected[8] then
        -- Function to activate Blink
        function activateBlink()
            gg.clearResults() -- Clear previous search results

            -- Perform the search
            gg.searchNumber('200;5;6.5', gg.TYPE_FLOAT)
            gg.toast("Searching for 200;5;6.5...") -- Debugging toast message

            -- Directly get the results after searching
            local results = gg.getResults(10) -- Get up to 10 results

            if #results == 0 then
                gg.toast("No results found for Blink values.")
                return
            end

            local found = false
            for i, result in ipairs(results) do
                -- Debug output for result details
                gg.toast("Found value: " .. result.value .. " at address: " .. string.format("0x%x", result.address))

                if result.value == 6.5 then
                    local baseAddress = result.address

                    -- Calculate the final address using the offset -656
                    local finalAddress = baseAddress + (-656)

                    -- Debug output for final address
                    gg.toast("Final address calculated: " .. string.format("0x%x", finalAddress))

                    -- Edit and freeze the value at the final address
                    local editData = { address = finalAddress, flags = gg.TYPE_DWORD, value = 0 }
                    gg.setValues({ editData })    -- Edit the value
                    gg.addListItems({ editData }) -- Add to the list and freeze

                    gg.toast("Blink activated and frozen!")
                    found = true
                    break
                end
            end

            if not found then
                gg.toast("No matching Blink value found!")
            end
        end

        -- Call the function to test it
        activateBlink()
    end

    if selected[9] then
        mainMenu() -- Return to the main menu
    end
end

-- Function to handle Combat Hacks On Menu
function combatOnMenu()
    local combatOnMenuChoice = gg.choice({
        "Random Games 💀",
        "Skyblock 🟩",
        "Bedwars 🛏️",
        "Best for Legit 1v1 🔥",
        "Best for Legit HB 1v1 💥",
        "Go Back to Main Menu"
    }, nil, "Combat Hacks On Menu")
    if combatOnMenuChoice == 1 then
        randomGamesMenu() -- Call the Random Games menu with submenus
    elseif combatOnMenuChoice == 2 then
        -- Code for Skyblock menu
    elseif combatOnMenuChoice == 3 then
        -- Code for Bedwars menu
    elseif combatOnMenuChoice == 4 then
        -- Code for Best for Legit 1v1
    elseif combatOnMenuChoice == 5 then
        -- Code for Best for Legit HB 1v1
    elseif combatOnMenuChoice == 6 then
        mainMenu() -- Return to the main menu
    end
end

-- Function to handle Random Games Off menu with checkboxes and submenus
function randomGamesOffMenu()
    local choices = {
        "No Delay or BanCD ⏳ ❌",
        "WWE Cam 📸 ❌",
        "HitBox (HB) 🎯 ❌",
        "Reach Attack ⚔️ ❌",
        "Reach Block 🟫 ❌",
        "Set Block 🏗️ ❌",
        "No Clip 🚫 ❌",
        "Blink 👁️ ❌",
        "Back to Main Menu"
    }

    local selected = gg.multiChoice(choices, nil, "Random Games Hacks Off")

    if selected == nil then return end

    -- Handle each selected checkbox
    if selected[1] then
        gg.toast("No Delay or BanCD deactivated")
        -- Code to deactivate No Delay or BanCD here
    end

    if selected[2] then
        gg.toast("WWE Cam deactivated")
        -- Code to deactivate WWE Cam here
    end

    if selected[3] then
        gg.toast("HitBox (HB) deactivated")
        -- Code to deactivate HitBox here
    end

    if selected[4] then
        gg.toast("Reach Attack deactivated")
        -- Code to deactivate Reach Attack here
    end

    if selected[5] then
        gg.toast("Reach Block deactivated")
        -- Code to deactivate Reach Block here
    end

    if selected[6] then
        gg.toast("Set Block deactivated")
        -- Code to deactivate Set Block here
    end

    if selected[7] then
        gg.toast("No Clip deactivated")
        -- Code to deactivate No Clip here
    end

    if selected[8] then
        gg.toast("Blink deactivated")
        -- Function to deactivate Blink and revert offset value
        function deactivateBlink()
            gg.clearResults() -- Clear previous search results

            -- Step 1: Search for '200;5;6.5' in float
            gg.searchNumber('200;5;6.5', gg.TYPE_FLOAT)
            gg.toast("Searching for 200;5;6.5...")

            -- Step 2: Get the results after searching
            local results = gg.getResults(10) -- Get up to 10 results

            if #results == 0 then
                gg.toast("No results found for Blink values.")
                return
            end

            local found = false
            for i, result in ipairs(results) do
                -- Step 3: Focus on the value 6.5
                if result.value == 6.5 then
                    -- Step 4: Add the 6.5 value to the saved list
                    gg.addListItems({ result })
                    gg.toast("6.5 value saved to the list.")

                    -- Step 5: Calculate the offset (-656, in decimal) from the address of 6.5
                    local baseAddress = result.address
                    local finalAddress = baseAddress + (-656) -- Offset calculation

                    -- Step 6: Go to the offset and search value at that address (in DWord)
                    local offsetValue = { address = finalAddress, flags = gg.TYPE_DWORD }
                    local offsetResult = gg.getValues({ offsetValue })

                    -- Step 7: Check if the value is 0 at the offset and edit it to 1
                    if offsetResult[1].value == 0 then
                        offsetResult[1].value = 1  -- Change 0 to 1
                        gg.setValues(offsetResult) -- Apply the change

                        gg.toast("Blink deactivated! Offset value changed to 1.")
                        found = true
                        break
                    else
                        gg.toast("Expected value 0 not found at offset.")
                    end
                end
            end

            if not found then
                gg.toast("No matching Blink value found.")
            end
        end

        -- Call the function to test it
        deactivateBlink()
    end

    if selected[9] then
        mainMenu() -- Return to the main menu
    end
end

-- Function to handle Combat Hacks Off Menu
function combatOffMenu()
    local combatOffMenuChoice = gg.choice({
        "Random Games 💀 ❌",
        "Skyblock 🟩 ❌",
        "Bedwars 🛏️ ❌",
        "Best for Legit 1v1 🔥 ❌",
        "Best for Legit HB 1v1 💥 ❌",
        "Go Back to Main Menu"
    }, nil, "Combat Hacks Off Menu")

    if combatOffMenuChoice == 1 then
        randomGamesOffMenu() -- Call the Random Games Off menu with checkboxes
    elseif combatOffMenuChoice == 2 then
        -- Code to deactivate Skyblock hacks
    elseif combatOffMenuChoice == 3 then
        -- Code to deactivate Bedwars hacks
    elseif combatOffMenuChoice == 4 then
        -- Code to deactivate Best for Legit 1v1 hacks
    elseif combatOffMenuChoice == 5 then
        -- Code to deactivate Best for Legit HB 1v1 hacks
    elseif combatOffMenuChoice == 6 then
        mainMenu() -- Return to the main menu
    end
end

-- Updated Combat Hacks Menu function to call the new Combat Off Menu
function combatMenu()
    local combatMenuChoice = gg.choice({
        "Combat On 😈",
        "Combat Off ❌",
        "Go Back to Main Menu"
    }, nil, "Combat Hacks Menu")

    if combatMenuChoice == 1 then
        combatOnMenu()  -- Show Combat Hacks On menu
    elseif combatMenuChoice == 2 then
        combatOffMenu() -- Show Combat Hacks Off menu
    elseif combatMenuChoice == 3 then
        mainMenu()      -- Return to the main menu
    end
end

-- Main Menu function
function mainMenu()
    local menuChoice = gg.choice({
        "Credits 📜",
        "Bypass 🛡️",
        "Combat Hacks 😈",
        "Movement Hacks 🏃",
        "Visuals 🎨",
        "Close Menu 😊",
        "Exit Menu 💤"
    }, nil, "Main Menu")
    if menuChoice == 1 then
        showCredits()
    elseif menuChoice == 2 then
        bypassMenu()
    elseif menuChoice == 3 then
        combatMenu() -- Show Combat Hacks menu
    elseif menuChoice == 4 then
        movementMenu()
    elseif menuChoice == 5 then
        visualsMenu()
    elseif menuChoice == 6 then
        closeMenu()  -- Hide the menu, but keep script running
    elseif menuChoice == 7 then
        exitScript() -- Call the exitScript function to exit
    end
end

-- Credits function
function showCredits()
    gg.alert("Created by MercuryXStormi ExE.lua 💀")
    mainMenu() -- Return to the main menu after showing credits
end

-- Movement Hacks Menu
function movementMenu()
    local movementMenuChoice = gg.choice({
        "Movement On 🟢",
        "Movement Off ❌",
        "Go Back to Main Menu"
    }, nil, "Movement Hacks Menu")
    if movementMenuChoice == 1 then
        movementOnMenu()
    elseif movementMenuChoice == 2 then
        movementOffMenu()
    elseif movementMenuChoice == 3 then
        mainMenu() -- Return to the main menu
    end
end

-- Movement On Menu
function movementOnMenu()
    local movementOnMenuChoice = gg.choice({
        "Random Games 💀 🏃",
        "Skyblock 🟩 🏃",
        "Bedwars 🛏️ 🏃",
        "Unnoticeable Movement Hacks 😈 🏃",
        "Go Back to Main Menu"
    }, nil, "Movement On Menu")

    if movementOnMenuChoice == 5 then
        mainMenu() -- Return to the main menu
    end
end

-- Movement Off Menu
function movementOffMenu()
    local movementOffMenuChoice = gg.choice({
        "Random Games 💀 🏃 ❌",
        "Skyblock 🟩 🏃 ❌",
        "Bedwars 🛏️ 🏃 ❌",
        "Unnoticeable Movement Hacks 😈 🏃 ❌",
        "Go Back to Main Menu"
    }, nil, "Movement Off Menu")

    if movementOffMenuChoice == 5 then
        mainMenu() -- Return to the main menu
    end
end

-- Bypass Menu
function bypassMenu()
    local bypassMenuChoice = gg.choice({
        "Bypass 1 🛡️",
        "Bypass 2 🛡️",
        "Bypass 3 🛡️",
        "Go Back to Main Menu"
    }, nil, "Bypass Menu")

    if bypassMenuChoice == 4 then
        mainMenu() -- Return to the main menu
    end
end

-- Visuals Menu
function visualsMenu()
    local visualsMenuChoice = gg.choice({
        "Visuals On 🟢",
        "Visuals Off ❌",
        "Go Back to Main Menu"
    }, nil, "Visuals Menu")

    if visualsMenuChoice == 3 then
        mainMenu() -- Return to the main menu
    end
end

-- Keeping the script running and showing the menu when GG icon is clicked
while true do
    if gg.isVisible(true) then
        gg.setVisible(false)
        passwordPrompt() -- Prompt for password if necessary
    end
    gg.sleep(100)        -- Sleep for 1 second to reduce CPU usage
end
