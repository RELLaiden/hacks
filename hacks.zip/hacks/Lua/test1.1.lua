gg.setRanges(gg.REGION_CODE_APP)
gg.setVisible(false)
gg.searchNumber(
"h63 65 5F 63 73 33 00 48 42 43 68 65 63 6B 00 63 73 63 21 25 73 00 63 73 66 21 25 73 00 63 73 5F 38 30 5F 70 6F 72 74 00 30 5F 30 5F 25 7A 75 00 43 53 33 2C 20 4F 6E 54 69 63 6B 65 74 4F 4B 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 68 65 6C 6C 6F 2C 20 77 6F 72 6C 64 00 00 72 6F 6C 65 5F 69 64 3A 25 73 3B 69 6E 63 5F 69 64 3A 25 64 00 67 65 74 5F 31 5F 25 64 3A 25 70 2C 20 6E 6F 64 65 5F 63 6E 74 3A 25 64 2C 20 72 65 6D 61 69 6E 3A 25 64 2C 20 63 73 33 00 64 65 6C 5F 31 5F 25 64 3A 25 70 2C 20 72 65 6D 61 69 6E 3A 25 64 2C 20 63 73 33 00 63 32 67 5F 72 65 64 69 65 63 74 00 00 04 08 18 0E 61 74 65 5F 62 69 00 63 68 65 63 6B 5F 65 78 74 5F 65 6D 75 5F 66 65 61 74 75 72 65 00 25 63 25 63 3A 25 64 2C 00 65 6D 75 5F 61 6C 65 72 74 3A 25 73 00 65 6D 75 5F 61 6C 65 72 74 00 65 5F 63 5F 6D 21 00 49 43 4F 4E 3A 25 73 3A 00 25 73 57 61 72 6E 69 6E 67 00 49 74 20 69 73 20 66 6F 75 6E 64 20 74 68 61 74 20 79 6F 75 20 61 72 65 20 72 75 6E 6E 69 6E 67 20 69 6E 20 61 6E 20 41 6E 64 72 6F 69 64 20 65 6D 75 6C 61 74 6F 72 2E 20 50 6C 65 61 73 65 20 72 65 73 75 6D 65 20 74 68 65 20 67 61 6D 65 20 61 66 74 65 72 20 72 65 74 75 72 6E 69 6E 67 20 74 6F 20 70 68 79 73 69 63 61 6C 20 64 65 76 69 63 65 73 2E 00 45 78 69 74 00 02 00 04 06 00 66 6F 6F 00 73 74 61 74 5F 72 70 74 00 61 63 65 5F 77 6F 72 6B 65 72 00 61 63 65 5F 77 6F 72 6B 65 72 25 64 00 73 63 5F 69 64 6C 65 00 00 00 00 00 00 00 00 80 84 2E 41 CD CC CC CC CC CC FC 3F 66 66 66 66 66 66 FE 3F 00 00 00 00 00 00 00 00 00 00 00 00 2C 01 00 00 00 00 00 00 84 03 00 00 96 00 00 00 08 00 00 00 3C 00 00 00 00 00 00 00 61 63 65 5F 73 63 68 65 64 75 6C 65 33 00 73 63 5F 64 6C 70 00 2B 20 72 65 70 6F 72 74 5F 62 6B 00 68 62 5F 6C 6F 6F 70 00 71 6F 73 5F 6C 6F 6F 70 00 69 6E 74 65 72 66 61 63 65 5F 74 65 73 74 00 73 63 00 25 64 3A 25 64 3A 25 64 3A 25 64 00 72 32 72 33 5F 65 72 72 00 6E 61 6D 65 3A 25 73 2C 20 63 61 73 74 3A 25 6C 64 00 6F 6E 73 65 6C 65 63 74 5F 61 6C 65 72 74 00 66 63 63 31 2E 64 00 21 64 6C 20 25 64 00 63 64 6E 3A 25 73 00 63 6F 6E 66 69 67 32 2E 78 6D 6C 00 21 64 63 66 00 21 70 63 66 00 21 64 73 66 00 64 6C 20 25 73 2C 20 72 65 74 76 61 6C 3A 25 64 2C 20 73 69 7A 65 3A 25 64 2C 20 63 61 63 68 65 3A 25 64 2C 20 6A 64 3A 25 64 00 63 6F 6D 6D 5F 66 69 72 73 74 00 73 69 67 20 63 75 73 74 6F 6D 2C 20 6E 61 6D 65 3A 25 73 2C 20 6C 65 6E 3A 25 64 2C 20 63 72 63 3A 25 30 38 78 00 63 6F 6E 66 69 67 33 2E 78 6D 6C 00 6D 65 6D 73 61 66 65 00 76 65 72 3A 25 73 20 61 70 70 5F 76 65 72 3A 25 73 20 63 6F 64 65 5F 73 69 7A 65 3A 25 73 20 63 72 63 3A 25 73 00 72 62 00 00 00 00 00 00 00 00 00 00 00 00 00 00 05 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 72 65 73 75 6C 74 3D 65 72 72 6F 72 00 00 00 00 38 DE 00 00 01 00 00 00 39 DE 00 00 01 00 00 00 3A DE 00 00 01 00 00 00 00 64 FD 82 FD FD FD A1 00 16 35 20 35 35 35 2A 00 00 00 00 00 00 00 00 01 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 77 73 61 5F 70 6F 70 65 6E 5F 69 70 00 77 73 61 5F 6E 65 74 6C 69 6E 6B 5F 69 70 00 77 73 61 5F 75 64 70 5F 69 70 00 25 75 3A 73 3B 70 3A 25 73 00 00 00 00 3A 8F 00 00 91 93 00 00 E8 97 00 00 00 61 22 3D 61 61 61 61 61 28 00 72 39 72 5A 72 72 63 72 6C 72 63 76 5F 25 64 2C 6C 65 6E 3A 25 64 2C 63 73 3A 25 64 00 67 5F 64 6C 5F 63 68 61 6E 6E 65 6C 00 70 5F 69 37 2E 64 61 74 00 72 5F 69 37 2E 64 61 74 00 72 65 63 6F 72 64 00 66 69 6C 65 73 2D 64 69 72 3A 25 73 2C 20 69 6E 69 74 65 64 3A 31 00 66 6C 61 67 73 3A 00 72 61 74 65 3A 25 64 00 67 61 6D 65 5F 76 65 72 3A 25 73 20 73 64 6B 5F 76 65 72 3A 25 73 00 33 2E 31 00 6A 61 72 5F 76 65 72 3A 25 73 2C 63 65 72 74 5F 65 6E 76 3A 25 73 00 6D 69 6E 5F 61 70 69 3A 25 64 2C 74 61 72 67 65 74 5F 61 70 69 3A 25 64 00 6D 61 78 5F 75 73 65 72 5F 77 61 74 63 68 65 73 3A 25 73 00 72 6F 6F 74 5F 61 6C 65 72 74 3A 25 73 00 72 6F 6F 74 5F 61 6C 65 72 74 00 72 70 64 61 74 61 32 00 63 73 3A 25 73 00 25 30 38 78 25 30 38 78 25 30 38 78 00 00 30 75 00 00 40 00 00 00 03 00 00 00 00 00 00 00 63 6C 6B 5F 61 64 62 00 41 75 74 6F 43 6C 69 63 6B 65 72 20 66 6F 75 6E 64 20 6F 6E 20 79 6F 75 72 20 70 68 6F 6E 65 2E 20 54 6F 20 63 6F 6E 74 69 6E 75 65 2C 20 64 72 61 67 20 74 68 65 20 73 63 72 6F 6C 6C 20 62 61 72 20 74 6F 20 74 68 65 20 6E 75 6D 62 65 72 20 25 64 2E 00 43 75 72 72 65 6E 74 20 6E 75 6D 62 65 72 20 69 73 3A 20 3B 25 64 3B 25 64 00 63 6C 6B 5F 72 70 74 00 25 73 2F 25 73 00 63 6F 6D 2F 63 6F 63 6F 73 2F 6C 69 62 2F 43 6F 63 6F 73 41 63 74 69 76 69 74 79 00 64 74 00 6D 53 75 72 66 61 63 65 56 69 65 77 00 4C 63 6F 6D 2F 63 6F 63 6F 73 2F 6C 69 62 2F 43 6F 63 6F 73 53 75 72 66 61 63 65 56 69 65 77 3B 00 73 65 74 4F 6E 74 6F 75 63 68 52 65 74 56 61 6C 00 28 5A 29 56 00 00 00 01 02 03 04 05 06 07 08 09 0A 0B 0C 0D 0E 0F 9A 99 99 99 99 99 C9 3F 71 3D 0A D7 A3 70 E5 3F 61 6E 6F 2C 64 72 6F 70 3A 25 73 3A 25 73 00 61 6E 6F 5F 74 69 70 5F 70 6B 67 00 6D 73 67 62 6F 78 5F 62 75 74 74 6F 6E 5F 31 30 30 30 31 00 61 6E 6F 5F 69 63 6F 6E 00 6D 73 67 62 6F 78 5F 63 6F 6E 74 65 6E 74 5F 31 30 30 30 31 00 4D 61 6C 77 61 72 65 20 66 6F 75 6E 64 20 6F 6E 20 79 6F 75 72 20 70 68 6F 6E 65 2E 20 50 6C 65 61 73 65 20 75 6E 69 6E 73 74 61 6C 6C 20 69 74 20 62 65 66 6F 72 65 20 65 6E 74 65 72 69 6E 67 20 74 68 65 20 67 61 6D 65 2E 28 00 61 6E 6F 5F 74 69 6D 65 00 21 66 6F 72 63 65 3A 6D 73 67 5F 62 6F 78 3A 74 69 6D 65 6F 75 74 00 77 68 6F 61 72 65 79 6F 75 3F 00 61 6E 6F 5F 66 63 00 61 6E 6F 5F 63 65 72 74 5F 6D 64 35 00 47 47 00 67 67 00 63 6F 6D 2E 00 61 6E 6F 5F 69 67 6E 6F 72 65 5F 64 65 74 65 63 74 00 61 6E 6F 5F 73 79 73 00 61 6E 6F 5F 63 66 69 6C 74 00 25 75 2E 25 75 2E 25 73 00 44 65 78 53 63 61 6E 00 63 6F 6D 2E 64 74 73 2E 66 72 65 65 66 69 72 65 74 68",
    gg.TYPE_BYTE, false, gg.SIGN_EQUAL, 0, -1, 0)
revert = gg.getResults(100000, nil, nil, nil, nil, nil, nil, nil, nil)
gg.editAll("0", gg.TYPE_BYTE)
revert = gg.getResults(100000, nil, nil, nil, nil, nil, nil, nil, nil)
gg.editAll("0", gg.TYPE_BYTE)
gg.setVisible(true)
gg.clearResults()
gg.setRanges(gg.REGION_CODE_APP)
gg.searchNumber("28 548 151 168 164 723", gg.TYPE_QWORD)
local b = gg.getResults(99999)
gg.addListItems(b)
b = nil
local a = false
local b = gg.getListItems()
if not a then gg.removeListItems(b) end
for i, v in ipairs(b) do
    v.address = v.address + 0x13
    if a then v.name = v.name .. ' #2' end
end
gg.addListItems(b)
b = nil
a = nil
revert = gg.getListItems()
local b = gg.getListItems()
for i, v in ipairs(b) do
    v.flags = gg.TYPE_BYTE
    v.value = "0"
    v.freeze = true
    v.freezeType = gg.FREEZE_IN_RANGE
    v.freezeFrom = "0"
    v.freezeTo = "1"
end
gg.addListItems(b)
b = nil
gg.clearResults()
gg.clearList()
gg.toast('Bypass by U+00A U+00A')

-- Global variable to track menu visibility state


local menuVisible = true





-- Function to modify values based on user choice


function modifyValues(search_value, new_value, search_type)
    gg.setRanges(gg.REGION_CODE_APP | gg.REGION_C_ALLOC)


    gg.searchNumber(search_value, search_type)


    local results = gg.getResults(10)





    if #results > 0 then
        for i, v in ipairs(results) do
            v.value = new_value


            v.freeze = true
        end


        gg.addListItems(results)


        gg.toast("Modification applied successfully!")
    else
        gg.toast("No results found. Try refining the search.")
    end
end

-- Function to show a confirmation dialog


function confirmChoice(choice)
    local confirm = gg.alert("You have selected: " .. choice .. "\nClick OK to apply.", "OK", "Cancel")


    return confirm == 1         -- 1 means OK was clicked
end

-- Function to display the mod menu and handle user choices

-- Password defined by the creator
local correct_password = "1850"

-- Function to ask for the password
function requestPassword()
    local input = gg.prompt({ 'Enter the password:' }, { '' }, { 'text' })
    if input == nil then
        gg.toast("No password entered. Exiting...")
        os.exit()     -- Exit the script if the user cancels the prompt
    elseif input[1] == correct_password then
        gg.toast("Correct password. Welcome!")
        -- You can place the rest of your script here
    else
        gg.alert("Incorrect password. Exiting...")
        os.exit()     -- Exit the script if the password is incorrect
    end
end

-- Call the password request function when the script starts
requestPassword()

-- Rest of the script...


gg.alert("Luarc Team\nMercury\nStormii\nU+00A U+00A\nDAM-U-TRIPPING");


local menuVisible = false

-- Función para mostrar el menú de modificaciones y manejar las elecciones del usuario
function showMenu()
    menuVisible = true      -- Establece el menú como visible
    gg.setVisible(true)     -- Asegura que el menú esté visible

    while menuVisible do
        -- Mostrar el botón "Cerrar Menú" siempre en la parte superior
        local closeMenu = gg.choice({ "Open Menu" }, nil, "Opciones de Modificación")

        if closeMenu == 1 then
            menuVisible = false      -- Cambia a falso para cerrar el menú
            gg.setVisible(false)     -- Cierra el menú visualmente
            gg.toast("Menú cerrado. Puedes seguir jugando.")
        end



        local menu = gg.choice({

            "Fly Mode",              --1--

            "No Delay",              --2

            "Airspeed Mode",         --3--


            "Speed Mode",         --4--


            "Gravity Mode",         --5--


            "HB x5",         --6--


            "Game Speed",         --7--


            "Fly Off",         --8--


            "Speed Off",         --9--


            "Airspeed Off",         --10--


            "Gravity Off",         --11--


            "Exit",         --12--



        }, nil, "Select an Option")


        if menu == 1 then
            if confirmChoice("Fly Mode") then
                modifyValues(0.0001, -3, gg.TYPE_FLOAT)
                gg.clearResults()
            end
        elseif menu == 3 then
            if confirmChoice("Airspeed Mode") then
                modifyValues(0.02, 0.5601, gg.TYPE_FLOAT)
                gg.clearResults()
            end
        elseif menu == 4 then
            if confirmChoice("Speed Mode") then
                modifyValues(0.16277135909, 0.65, gg.TYPE_FLOAT)
                gg.clearResults()
            end
        elseif menu == 5 then
            if confirmChoice("Gravity Mode") then
                -- Configuración del centro de la pantalla
                local centroX = 960 -- Ajusta si es necesario
                local centroY = 540 -- Ajusta si es necesario

                function fijarAim()
                    -- Define la región de memoria (ajusta si es necesario)
                    gg.setRanges(gg.REGION_C_ALLOC | gg.REGION_ANONYMOUS | gg.REGION_OTHER)

                    -- Busca el valor de la coordenada X del aim
                    gg.searchNumber("960", gg.TYPE_DWORD)
                    local resultadosX = gg.getResults(1)

                    -- Busca el valor de la coordenada Y del aim
                    gg.searchNumber("540", gg.TYPE_DWORD)
                    local resultadosY = gg.getResults(1)

                    -- Si se encuentran los resultados, los fija
                    if #resultadosX > 0 then
                        resultadosX[1].value = centroX
                        resultadosX[1].freeze = true -- Congela el valor
                        gg.setValues(resultadosX) -- Aplica el cambio
                    end

                    if #resultadosY > 0 then
                        resultadosY[1].value = centroY
                        resultadosY[1].freeze = true -- Congela el valor
                        gg.setValues(resultadosY) -- Aplica el cambio
                    end
                end

                -- Bucle para fijar el aim en el centro continuamente
                while true do
                    fijarAim()
                    gg.sleep(100) -- Ajusta la frecuencia de fijación según sea necesario
                end
            end
        elseif menu == 6 then
            if confirmChoice("HB x5") then
                gg.setRanges(gg.REGION_C_ALLOC)
                gg.searchNumber("1.62;1058642330D:256", gg.TYPE_FLOAT)
                gg.getResults(100)
                gg.refineNumber("1058642330", gg.TYPE_DWORD)
                gg.getResults(100)
                gg.editAll("1058474557", gg.TYPE_DWORD)
                gg.clearResults()

                gg.setRanges(gg.REGION_C_ALLOC)
                gg.searchNumber("1058642330D;180", gg.TYPE_FLOAT)
                gg.getResults(999)
                gg.refineNumber("1058642330", gg.TYPE_DWORD)
                gg.getResults(999)
                gg.editAll("1092732699", gg.TYPE_DWORD)
                gg.clearResults()
            end
        elseif menu == 7 then
            if confirmChoice("Game Speed") then
                modifyValues(-0.05000000075, -0.02520000003, gg.TYPE_FLOAT)
                gg.clearResults()
            end
        elseif menu == 8 then
            if confirmChoice("Fly Off") then
                modifyValues(-3, 0.0001, gg.TYPE_FLOAT)
                gg.clearResults()
            end
        elseif menu == 9 then
            if confirmChoice("Speed Off") then
                modifyValues(0.65, 0.16277135909, gg.TYPE_FLOAT)
                gg.clearResults()
            end
        elseif menu == 10 then
            if confirmChoice("Airspeed Off") then
                modifyValues(0.5601, 0.02, gg.TYPE_FLOAT)
                gg.clearResults()
            end
        elseif menu == 11 then
            if confirmChoice("Gravity Off") then
                modifyValues(0.02, 0.08, gg.TYPE_FLOAT)
                gg.clearResults()
            end




            menuVisible = false
            return         -- Exit the loop
        elseif menu == 12 then
            gg.toast("Exiting...")
            os.exit()
        else
            gg.toast("Invalid choice or menu canceled.")
        end
    end
end

-- Verificar si el menú está visible y el usuario ha hecho clic fuera de él
if not gg.isVisible() then
    menuVisible = false         -- Cierra el menú si se hace clic fuera
end

gg.setVisible(false)




-- Función para verificar y mostrar el menú si es necesario
function checkMenu()
    while true do
        if not menuVisible and gg.isVisible() then
            showMenu() -- Muestra el menú cuando se hace clic en el ícono de GG
        end
        gg.sleep(500)  -- Verifica cada 500 ms
    end
end

-- Función para iniciar el script
function startScript()
    gg.setVisible(true) -- Asegura que el menú esté visible al inicio
    checkMenu()         -- Comienza a verificar clics en el ícono de GG
end

-- Ejecutar el script
startScript()
