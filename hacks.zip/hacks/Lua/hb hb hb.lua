-- Function to activate hb
function activateHB()
    gg.clearResults()  -- Clear any previous search results

    -- Search for values 0.6;1.8;180
    gg.searchNumber("0.6;1.8;180", gg.TYPE_FLOAT)
    gg.toast("Searching for hb activation...")

    -- Refine search for 0.6;1.8
    gg.refineNumber("0.6;1.8", gg.TYPE_FLOAT)

    -- Edit all results to 5
    local results = gg.getResults(100)
    for _, result in ipairs(results) do
        result.value = 3.5
    end
    gg.setValues(results)
    gg.clearResults()  -- Remove all results

    -- Search for 1.62 in float
    gg.searchNumber("1.62", gg.TYPE_FLOAT)
    local hbResults = gg.getResults(10)

    if #hbResults > 0 then
        -- Save 1.62 to save list
        gg.addListItems({{address = hbResults[1].address, flags = gg.TYPE_FLOAT, value = 1.62}})
        gg.toast("1.62 saved to list")

        -- Go offset -34 hex value in float and edit to 0.6
        local offsetAddress1 = hbResults[1].address - 0x22  -- -34 hex
        local offsetResult1 = gg.getValues({{address = offsetAddress1, flags = gg.TYPE_FLOAT}})

        if #offsetResult1 > 0 then
            offsetResult1[1].value = 0.6  -- Set the value at the offset to 0.6
            gg.setValues(offsetResult1)
            gg.toast("Value at offset -34 (hex) changed to 0.6!")
        else
            gg.toast("No value found at offset -34 (hex).")
        end

        -- Search for 1.62 again in float
        gg.searchNumber("1.62", gg.TYPE_FLOAT)
        hbResults = gg.getResults(10)

        if #hbResults > 0 then
            -- Save 1.62 to save list again
            gg.addListItems({{address = hbResults[1].address, flags = gg.TYPE_FLOAT, value = 1.62}})
            gg.toast("1.62 saved to list again")
-- Go offset -74 hex value in float and edit to 1.8
            local offsetAddress2 = hbResults[1].address - 0x4A  -- -74 hex
            local offsetResult2 = gg.getValues({{address = offsetAddress2, flags = gg.TYPE_FLOAT}})

            if #offsetResult2 > 0 then
                offsetResult2[1].value = 1.8  -- Set the value at the offset to 1.8
                gg.setValues(offsetResult2)
                gg.toast("Value at offset -74 (hex) changed to 1.8!")
            else
                gg.toast("No value found at offset -74 (hex).")
            end
        else
            gg.toast("1.62 not found in results.")
        end
    else
        gg.toast("1.62 not found in results.")
    end
end

-- Call the function to test it
activateHB()
