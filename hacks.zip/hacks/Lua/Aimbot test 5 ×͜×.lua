function Sv(v, rg, fg)
    rt = {}
    gg.setRanges(rg)
    gg.searchNumber(v[1], fg)
    local r = gg.getResults(999999)
    if #r == 0 then gg.toast("NOT VALUE 1") return rt end
    for iv = 2, #v do
        for i = 1, #r do
            r[i].address = r[i].address + v[iv][2]
        end
        local rr = gg.getValues(r)
        tt = {}
        for i = 1, #rr do
            if rr[i].value == v[iv][1] then
                ii = #tt + 1
                tt[ii] = {}
                tt[ii].address = rr[i].address - v[iv][2]
                tt[ii].flags = fg
            end
        end
        if #tt == 0 then gg.clearResults() gg.toast("NOT VALUE 2") return rt end
        r = gg.getValues(tt)
        if iv == #v then rt = r return rt end
    end
    gg.clearResults()
    return rt
end

gg.sleep(1000)

function F()
    gg.clearList()
    gg.clearResults()
    v = 1
    gg.setVisible(false)
    rr = Sv({1127481344, {300, -71 * 4}, {0, -75 * 4}}, 4, 4)
    if #rr == 0 then gg.clearResults() gg.toast("NOT VALUE 1") return else
        gg.clearResults() gg.toast(#rr .. " PLAYER")
        r = Sv({1070554153, {1070554153, 0}}, 4, 4)
        if #r == 0 then gg.clearResults() gg.toast("NOT VALUE 2") return else
            gg.clearResults() gg.toast("AIMBOT Is ON")
        end
    end
 gg.setVisible(false)

   
    local smoothFactor = 0.2 
    local currentYaw = 0
    local currentPitch = 0

    while true do
        if gg.isVisible(true) then
            gg.setVisible(false) gg.clearList() gg.clearResults()
            gg.toast("AIMBOT OFF") return
        end
        if v == #rr + 1 then v = 1 end
        if rr[v].value ~= 1127481344 then
            v = v + 1
        else
            u = v
            for i, v in ipairs(r) do
                local address = v.address
                xA = gg.getValues({{address = address - 40 * 4, flags = 16}})[1].value
                yA = gg.getValues({{address = address - 41 * 4, flags = 16}})[1].value
                zA = gg.getValues({{address = address - 42 * 4, flags = 16}})[1].value
                myHP = gg.getValues({{address = address + 28 * 4, flags = 64}})[1].value
            end
            
            local xx = {}
            xx[u] = {}
            xx[u].flags = 16
            xx[u].address = rr[u].address + -115 * 4
            xB = gg.getValues(xx)[u].value
            xx[u].address = rr[u].address + -116 * 4
            yB = gg.getValues(xx)[u].value
            xx[u].address = rr[u].address + -117 * 4
            zB = gg.getValues(xx)[u].value
            
            local hp = {}
            hp[u] = {}
            hp[u].flags = 64
            hp[u].address = rr[u].address + -47 * 4
            HP = gg.getValues(hp)[u].value    
 if myHP < 0.123 then
                gg.toast("AIMBOT Is OFF") gg.clearList() return
            end
            if HP < 0.123 then v = v + 1 else
                local kc = math.sqrt((xB - xA)^2 + (zB - zA)^2)
                local ha = yB - yA
                local hh = math.abs(ha)
                local ka = math.abs(kc)
                if kc > 7 then v = v + 1 else
                    if hh > 7 then v = v + 1 else
                        local targetPitch = math.atan2(hh, ka) * 180 / math.pi
                        if ha > 0 then targetPitch = targetPitch * (-1) end
                        local targetYaw = math.atan2(xB - xA, zB - zA) * 180 / math.pi - 90
                        
                       
                        local adaptiveSmoothFactor = smoothFactor + (kc / 15) 
                        
                        
                        currentYaw = currentYaw + (targetYaw - currentYaw) * adaptiveSmoothFactor
                        currentPitch = currentPitch + (targetPitch - currentPitch) * adaptiveSmoothFactor

                        
                        tt = {}
                        for i = 1, #r do
                            ii = #tt + 1
                            tt[ii] = {}
                            tt[ii].flags = 16
                            tt[ii].address = r[i].address + -47 * 4
                            tt[ii].value = currentPitch
                            gg.setValues(tt)
                            tt[ii].address = r[i].address + -48 * 4
                            tt[ii].value = currentYaw
                            gg.setValues(tt)
                        end
                    end
                end    
    
            end
        end
        gg.sleep(5) 
    end
end

F()