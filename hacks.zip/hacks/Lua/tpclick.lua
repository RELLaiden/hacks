function N()
gg.toast("@LuaDever")
gg.setRanges(gg.REGION_C_ALLOC)
gg.searchNumber("4 575 657 222 549 274 624", gg.TYPE_QWORD, false, gg.SIGN_EQUAL, 0, -1, 0)
r = gg.getResults(1, nil, nil, nil, nil, nil, nil, nil, nil)
local Xb = {}
Xb[1] = {}
Xb[1].address = r[1].address - 1260
Xb[1].flags = gg.TYPE_FLOAT
Xb[1].name = "X block"
gg.clearList()
local Yb = {}
Yb[1] = {}
Yb[1].address = r[1].address - 1264
Yb[1].flags = gg.TYPE_FLOAT
Yb[1].name = "Y block"
gg.clearList()
local Zb = {}
Zb[1] = {}
Zb[1].address = r[1].address - 1268
Zb[1].flags = gg.TYPE_FLOAT
Zb[1].name = "Z block"
gg.clearList()
gg.clearResults()
gg.searchNumber("1.62", gg.TYPE_FLOAT, false, gg.SIGN_EQUAL, 0, -1, 0)
b = gg.getResults(1, nil, nil, nil, nil, nil, nil, nil, nil)
local Xme = {}
Xme[1] = {}
Xme[1].address = b[1].address - 160
Xme[1].flags = gg.TYPE_FLOAT
Xme[1].name = "X me"
gg.clearList()
local Yme = {}
Yme[1] = {}
Yme[1].address = b[1].address - 164
Yme[1].flags = gg.TYPE_FLOAT
Yme[1].name = "Y me"
gg.clearList()
local Zme = {}
Zme[1] = {}
Zme[1].address = b[1].address - 156
Zme[1].flags = gg.TYPE_FLOAT
Zme[1].name = "Z me"
gg.clearList()
gg.addListItems(Xb)
gg.addListItems(Yb)
gg.addListItems(Zb)
gg.addListItems(Xme)
gg.addListItems(Yme)
gg.addListItems(Zme)
gg.clearResults()
gg.setRanges(gg.REGION_C_ALLOC)
gg.searchNumber("7 507 219 104 906 870 784", gg.TYPE_QWORD, false, gg.SIGN_EQUAL, 0, -1, 0)
r = gg.getResults(1, nil, nil, nil, nil, nil, nil, nil, nil)
local t = {}
t[1] = {}
t[1].address = r[1].address + 8
t[1].flags = gg.TYPE_DWORD
t[1].freeze = false
gg.addListItems(t)
gg.clearResults()
gg.setRanges(gg.REGION_C_ALLOC)
gg.searchNumber("4 575 657 222 549 274 624", gg.TYPE_QWORD, false, gg.SIGN_EQUAL, 0, -1, 0)
r = gg.getResults(1, nil, nil, nil, nil, nil, nil, nil, nil)
lists = gg.getListItems()
local c = {}
c[1] = {}
c[1].address = lists[7].address
c[1].flags = gg.TYPE_DWORD
c[1].freeze = false
gg.addListItems(c)
local l = {}
l[1] = {}
l[1].address = lists[1].address
l[1].flags = gg.TYPE_FLOAT
l[1].value = lists[5].value + 1
l[1].freeze = false
local k = {}
k[1] = {}
k[1].address = lists[2].address
k[1].flags = gg.TYPE_FLOAT
k[1].value = lists[6].value
k[1].freeze = false
local n = {}
n[1] = {}
n[1].address = lists[3].address
n[1].flags = gg.TYPE_FLOAT
n[1].value = lists[4].value
n[1].freeze = false
for i = 1, 99999996 do
lists = gg.getListItems()
gg.addListItems(c)
l[1].value = lists[5].value + 1
k[1].value = lists[6].value
n[1].value = lists[4].value
if lists[7].value == 1 then
if lists[5].value == 0 then
else
gg.setValues(l)
gg.sleep(20)
gg.setValues(k)
gg.setValues(n)
end
end
end
end
