-- filename: @/compiler_apk_so/branch/pro_res_game_upload/engine2_game_config_release/game_config/g2038/lua/gm_client.lua
-- version: lua53
-- line: [0, 0] id: 0
local r0_0 = GM:createGMItem()
local r1_0 = require("script_client.pokemon.pokemon_manager")
r0_0["引导/关闭遮罩"] = function(r0_1)
  -- line: [5, 9] id: 1
  UI:getWnd("pokemonBlockInputEvents"):onHide()
  UI:getWnd("pokemonGuide"):onShow(false)
end
local r2_0 = false
r0_0["template/飞行模式"] = function(r0_2)
  -- line: [13, 16] id: 2
  r2_0 = not r2_0
  local r1_2 = Me
  local r3_2 = r2_0
  if r3_2 then
    r3_2 = 1 or 0
  else
    goto label_11	-- block#2 is visited secondly
  end
  r1_2:setFlyMode(r3_2)
end
r0_0["template/播放音乐文件"] = GM:inputStr(function(r0_3, r1_3)
  -- line: [18, 26] id: 3
  Me:playSound({
    id = 999,
    key = "test",
    sound = "/sound/" .. r1_3 .. ".mp3",
    loop = false,
    volume = 5,
  })
end, "文件名")
r0_0["工具/镜头编辑器"] = function(r0_4)
  -- line: [28, 31] id: 4
  r0_4.disableControl = false
  UI:getWnd("cameraEdit"):onShow(true)
end
r0_0["测试/disableReplaceAuto"] = function(r0_5)
  -- line: [33, 35] id: 5
  r0_5.disableReplaceAuto = not r0_5.disableReplaceAuto
end
r0_0["战斗/C StateReady"] = function(r0_6)
  -- line: [37, 39] id: 6
  r0_6.debugStateReady = not r0_6.debugStateReady
end
r0_0["测试/grass memory"] = function(r0_7)
  -- line: [41, 45] id: 7
  Lib.logInfo("grassMoveTable", Lib.getTableSize(require("script_client.main"):getGrassMoveTable()))
end
r0_0["战斗/播放过场动画"] = function(r0_8)
  -- line: [71, 72] id: 8
end
r0_0["战斗/停止过场动画"] = function(r0_9)
  -- line: [74, 76] id: 9
  Lib.emitEvent(Event.EVENT_SKIP_CUTSCENE)
end
r0_0["宠物client/战斗列表"] = function(r0_10)
  -- line: [78, 93] id: 10
  print("战斗列表")
  r0_10:getBattlePokemon(function(r0_11)
    -- line: [81, 92] id: 11
    for r4_11, r5_11 in pairs(r0_11) do
      print("---------" .. r4_11 .. "-----------")
      print("等级 " .. r5_11:getLevel())
      print("当前经验 " .. r5_11:getCurExp())
      print("升级经验 " .. r5_11:getMaxExp())
      print("性别 " .. r5_11:getSex())
      print("种族 " .. r5_11:getRace())
      print("最大血量 " .. r5_11:getMaxHp())
      print("当前血量 " .. r5_11:getCurHp())
    end
  end)
end
r0_0["宠物client/背包列表"] = function(r0_12)
  -- line: [95, 110] id: 12
  print("背包列表")
  r0_12:getPacketPokemon(function(r0_13)
    -- line: [98, 109] id: 13
    for r4_13, r5_13 in pairs(r0_13) do
      print("---------" .. r4_13 .. "-----------")
      print("等级 " .. r5_13:getLevel())
      print("当前经验 " .. r5_13:getCurExp())
      print("升级经验 " .. r5_13:getMaxExp())
      print("性别 " .. r5_13:getSex())
      print("种族 " .. r5_13:getRace())
      print("最大血量 " .. r5_13:getMaxHp())
      print("当前血量 " .. r5_13:getCurHp())
    end
  end)
end
r0_0["宠物client/取消背包订阅"] = function(r0_14)
  -- line: [112, 117] id: 14
  print("取消背包订阅")
  r0_14:clearPokemonList(r0_14:getValue("packetPetList"))
end
r0_0["宠物/C所有宝可梦数量"] = function(r0_15)
  -- line: [119, 122] id: 15
  Lib.logInfo("allPokemon size", Lib.getTableSize(r1_0:getAllPokemon()))
end
return r0_0
